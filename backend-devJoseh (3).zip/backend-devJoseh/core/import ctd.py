import ctd
import matplotlib.pyplot as plt
 
# Leer el archivo .cnv
file_path = r"E:\045-Diego Rengifo 2024\01-PROYECTOS 2024\datos de prueba estacion 5\SBE19plus_01907890_2024_08_01.cnv"
cast = ctd.from_cnv(file_path)
 
print(cast)
# Acceder a datos específicos
temperature = cast.get('tv290C')
time = cast.get('timeM')
salinity = cast.get('sal00')
conductivity = cast.get('c0mS/cm')
oxygen = cast.get('sbeox0Mg/L')
fluorescence = cast.get('flSP')
nitrogen_saturation = cast.get('n2satMg/L')
density = cast.get('density00')
descent_rate = cast.get('dz/dtM')
sound_velocity = cast.get('svCM')
flag = cast.get('flag')
pressure = cast.index
pressure = -pressure
 
# Crear subplots
fig, axs = plt.subplots(6, 2, figsize=(15, 20))  # Ajusta el tamaño y la disposición según sea necesario
axs = axs.flatten()  # Hacer que axs sea un array plano
 
# Graficar cada variable en su subplot correspondiente
if temperature is not None:
    axs[0].plot(temperature, pressure, label='Temperatura')
    axs[0].set_xlabel('Temperatura (°C)')
    axs[0].set_ylabel('Presión (dbar)')
    axs[0].set_title('Temperatura vs Presión')
    axs[0].grid(True)
 
if salinity is not None:
    axs[1].plot(salinity, pressure, label='Salinidad')
    axs[1].set_xlabel('Salinidad (PSU)')
    axs[1].set_ylabel('Presión (dbar)')
    axs[1].set_title('Salinidad vs Presión')
    axs[1].grid(True)
 
if conductivity is not None:
    axs[2].plot(conductivity, pressure, label='Conductividad')
    axs[2].set_xlabel('Conductividad (mS/cm)')
    axs[2].set_ylabel('Presión (dbar)')
    axs[2].set_title('Conductividad vs Presión')
    axs[2].grid(True)
 
if oxygen is not None:
    axs[3].plot(oxygen, pressure, label='Oxígeno')
    axs[3].set_xlabel('Oxígeno (mg/l)')
    axs[3].set_ylabel('Presión (dbar)')
    axs[3].set_title('Oxígeno vs Presión')
    axs[3].grid(True)
 
if fluorescence is not None:
    axs[4].plot(fluorescence, pressure, label='Fluorescencia')
    axs[4].set_xlabel('Fluorescencia')
    axs[4].set_ylabel('Presión (dbar)')
    axs[4].set_title('Fluorescencia vs Presión')
    axs[4].grid(True)
 
if nitrogen_saturation is not None:
    axs[5].plot(nitrogen_saturation, pressure, label='Saturación de Nitrógeno')
    axs[5].set_xlabel('Saturación de Nitrógeno (mg/l)')
    axs[5].set_ylabel('Presión (dbar)')
    axs[5].set_title('Saturación de Nitrógeno vs Presión')
    axs[5].grid(True)
 
if density is not None:
    axs[6].plot(density, pressure, label='Densidad')
    axs[6].set_xlabel('Densidad (kg/m³)')
    axs[6].set_ylabel('Presión (dbar)')
    axs[6].set_title('Densidad vs Presión')
    axs[6].grid(True)
 
if descent_rate is not None:
    axs[7].plot(descent_rate, pressure, label='Tasa de Descenso')
    axs[7].set_xlabel('Tasa de Descenso')
    axs[7].set_ylabel('Presión (dbar)')
    axs[7].set_title('Tasa de Descenso vs Presión')
    axs[7].grid(True)
 
if sound_velocity is not None:
    axs[8].plot(sound_velocity, pressure, label='Velocidad del Sonido')
    axs[8].set_xlabel('Velocidad del Sonido (m/s)')
    axs[8].set_ylabel('Presión (dbar)')
    axs[8].set_title('Velocidad del Sonido vs Presión')
    axs[8].grid(True)
 
if flag is not None:
    axs[9].plot(flag, pressure, label='Flag')
    axs[9].set_xlabel('Flag')
    axs[9].set_ylabel('Presión (dbar)')
    axs[9].set_title('Flag vs Presión')
    axs[9].grid(True)
 
# Ajustar el espacio entre subplots
plt.tight_layout()
plt.show()