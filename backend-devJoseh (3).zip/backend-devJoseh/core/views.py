import json
import os
import re
import tempfile
from datetime import datetime

import ctd  # Asegúrate de que 'ctd' esté importado correctamente
import pandas as pd
from django.db import IntegrityError, transaction
from django.db.models import OuterRef, Subquery
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from numpy import save
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import ParseError
from rest_framework.response import Response
from rest_framework.views import APIView

from .formsd import ProfileDataForm
from .models import Coasts, Disciplines, ProfileData, QualityFactors
from .serializers import (CombinedDataSerializer, ProfileDataSerializer,
                          QualityFactorsSerializer, VariableNameList, VariableUnitSerializer)


class ProfileDataViewSet(viewsets.ViewSet):

    @action(detail=False, methods=['post'], url_path='filter-by-variable')
    def filter_by_variable(self, request):
        try:
            data = request.data
            variable_name = data.get('variable_name')
            date_str = data.get('date')
            station_name = data.get('station_name')

            if not variable_name or not date_str or not station_name:
                return Response({'error': 'Missing required fields'}, status=status.HTTP_400_BAD_REQUEST)

            try:
                date = datetime.strptime(date_str, "%Y-%m-%d")
            except ValueError:
                return Response({'error': 'Invalid date format, should be YYYY-MM-DD'}, status=status.HTTP_400_BAD_REQUEST)

            variable = Variables.objects.filter(name=variable_name, sensor__measurement__name=station_name).first()
            if not variable:
                return Response({'error': 'Variable does not exist'}, status=status.HTTP_404_NOT_FOUND)

            profile_data = ProfileData.objects.filter(variable=variable, timestamp__date=date.date()).values('depth_marker', 'variable_value')
            serializer = ProfileDataSerializer(profile_data, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Exception as e:
            print(f'Unexpected error: {e}')
            return Response({'error': 'Internal server error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        

class VariableFilterViewSet(viewsets.ViewSet):

    @action(detail=False, methods=['post'], url_path='filter_names')
    def filter_variable(self, request):
        variable_names = request.data.get('variable_names')  # Recibir múltiples nombres de variables
        date_str = request.data.get('date')
        station_name = request.data.get('station_name')

        # Verificar que los parámetros necesarios estén presentes
        if not variable_names or not station_name or not date_str:
            return Response({'error': 'Falta una o más variables necesarias'}, status=400)

        # Convertir la cadena de fecha a un objeto datetime
        try:
            date = datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            return Response({'error': 'Invalid date format, should be YYYY-MM-DD'}, status=status.HTTP_400_BAD_REQUEST)

        # Filtrar las variables proporcionadas
        variables = Variables.objects.filter(
            name__in=variable_names,
            sensor__measurement__name=station_name
        )

        # Verificar que se encontraron todas las variables solicitadas
        if variables.count() < len(variable_names):
            return Response({'error': 'No se encontraron todas las variables con los nombres y estación proporcionados'}, status=404)

        # Inicializar una lista para los datos combinados
        combined_data = []

        # Almacenar los datos de todas las variables
        variable_data = {name: [] for name in variable_names}
        
        print(variable_data)

        # Recorrer las variables en el orden proporcionado
        for variable_name in variable_names:
            variable = variables.filter(name=variable_name).first()
            
            if variable:
                # Obtener los datos de ProfileData
                profile_data = ProfileData.objects.filter(
                    variable=variable,
                    timestamp__date=date.date()
                ).values('depth_marker', 'variable_value')

                # Almacenar los datos de esta variable
                for entry in profile_data:
                    depth = entry['depth_marker']
                    value = entry['variable_value']
                    variable_data[variable_name].append({'depth_marker': depth, 'value': value})
        #print(variable_data)            

        #a
        for i in range(len(variable_data[variable_names[0]])):
            depth_entry = {'depth': variable_data[variable_names[0]][i]['depth_marker']}
            print(depth_entry)
            for variable_name in variable_names:
                # Añadir el valor de cada variable
                depth_entry[variable_name] = variable_data[variable_name][i]['value'] if i < len(variable_data[variable_name]) else None
                print(depth_entry)
            combined_data.append(depth_entry)

        # Serializar y devolver la respuesta
        serializer = CombinedDataSerializer(combined_data, many=True)
        return Response(serializer.data)




class VariableUnitsViewSet(viewsets.ViewSet):

    @action(detail=False, methods=['post'], url_path='variable_units')
    def get_variable_units(self, request):
        variable_names = request.data.get('variable_names')  # Multiple variable names
        station_name = request.data.get('station_name')

        # Ensure required parameters are present
        if not variable_names or not station_name:
            return Response({'error': 'Falta una o más variables necesarias'}, status=400)

        # Filter the provided variables
        variables = Variables.objects.filter(
            name__in=variable_names,
            sensor__measurement__name=station_name
        )

        # Check if all requested variables were found
        if variables.count() < len(variable_names):
            return Response({'error': 'No se encontraron todas las variables con los nombres y estación proporcionados'}, status=404)

        # Initialize a list for units data
        units_data = []

        # Collect the unit for each variable
        for variable_name in variable_names:
            variable = variables.filter(name=variable_name).first()
            if variable:
                units_data.append({
                    'variable_name': variable.name,
                    'unit': variable.measurement_unit.symbol  # Assuming 'unit_name' field in MeasurementUnits model
                })

        # Serialize the units data
        serializer = VariableUnitSerializer(units_data, many=True)

        # Return the serialized response
        return Response(serializer.data)
    
    
class VariableName(viewsets.ViewSet):
    @action(detail=False, methods=['get'],url_path='name')  
    
    def get_variable_name(self, request):
        variable_name= Variables.objects.all()
        print(variable_name)
        serializer=VariableNameList(variable_name,many=True)
        print(serializer)
        return Response(serializer.data)

def get_temperature_and_depth_marker(request):
    if request.method == 'POST':
        form = ProfileDataForm(request.POST)
        if form.is_valid():
            temperature = form.cleaned_data['temperature']
            depth_marker = form.cleaned_data['depth_marker']
            try:
                profile_data = ProfileData.objects.get(variable__name='temperature', depth_marker=depth_marker, variable_value=temperature)
                response = {
                    'temperature': profile_data.variable_value,
                    'depth_marker': profile_data.depth_marker
                }
            except ProfileData.DoesNotExist:
                response = {'error': 'Data not found'}
            return JsonResponse(response)
        else:
            return JsonResponse({'error': 'Invalid form data'}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)


def extract_information(file_path):
    info = {
        'station_name': '',
        'cruise_name': '',
        'vessel_name': '',
        'station_number': '',
        'launch_date_time': '',
        'latitude': '',
        'longitude': '',
        'depth': '',
        'operator_name': '',
        'chief_of_departure': '',
        'system_upload_time': ''
    }

    with open(file_path, 'r') as file:
        content = file.read()

        # Regex patterns for each piece of information
        patterns = {
            #'station_name': r"Nombre del archivo:\s*(.*)",
            #'cruise_name': r"\*\* Nombre del crucero:\s*(.*)",
            #'vessel_name': r"\*\* Nombre de la embarcación y su indicativo:\s*(.*)",
            #'station_number': r"\*\* Estacion:\s*(.*)",
            'station_number': r"\*\* Número de estación:\s*(.*)",
            'launch_date_time': r"\*\* Fecha y hora de lanzamiento:\s*(.*)",
            #'latitude': r"\*\* Latitud:\s*([0-9\.\-]+)",
            #'longitude': r"\*\* Longitud:\s*([0-9\.\-]+)",
            #'depth': r"\*\* Profundidad de la zona \[ m\] :\s*(.*)",
            #'operator_name': r"\*\* Nombre del operador:\s*(.*)",
            #'chief_of_departure': r"\*\* Jefe de salida:\s*(.*)",
            'system_upload_time': r"System UpLoad Time = ([\w\s:]+)"
        }

        # Extract data using regex
        for key, pattern in patterns.items():
            match = re.search(pattern, content)
            if match:
                info[key] = match.group(1).strip()

        
        # Convert launch date and time to specific format
        if info['launch_date_time']:
            try:
                launch_dt = datetime.strptime(info['launch_date_time'], "%d %b %Y, %H:%M:%S")
                info['launch_date_time'] = launch_dt.strftime("%Y-%m-%d %H:%M:%S.%f%z")
            except ValueError:
                print("Error al convertir la fecha y hora de lanzamiento.")
        # Optionally process the system upload time
        if info['system_upload_time']:
            try:
                upload_dt = datetime.strptime(info['system_upload_time'], "%b %d %Y %H:%M:%S")
                info['system_upload_time'] = upload_dt.strftime("%Y-%m-%d %H:%M:%S")
            except ValueError:
                print("Error al convertir la fecha y hora de subida del sistema.")
                
    return info

class UploadView(viewsets.ViewSet):
    @action(detail=False, methods=['post'], url_path='upload_cnv')
    def post(self, request):
        file = request.FILES.get('file')
        
        if not file or not file.name.endswith('.cnv'):
            return Response({"error": "Este no es un archivo CNV"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            
            with tempfile.NamedTemporaryFile(delete=False, suffix='.cnv') as temp_file:
                for chunk in file.chunks():
                    temp_file.write(chunk)
                temp_file.seek(0)
                temp_file_path = temp_file.name
            
            print("Iniciando el proceso de carga del CNV...")
            data = extract_information(temp_file_path)
            cast = ctd.from_cnv(temp_file_path)
            dataTime = data['system_upload_time']
            station_name=data['station_number']
            print(dataTime)
            print(station_name)
            temperature = cast.get('tv290C')
            print(temperature.head())
            time = cast.get('timeM')
            salinity = cast.get('sal00')
            conductivity = cast.get('c0mS/cm')
            #oxygen = cast.get('sbeox0Mg/L')
            oxygen = cast.get('sbeox0ML/L')
            pH=cast.get('ph')
            
            #fluorescence = cast.get('flSP')flECO-AFL
            fluorescence = cast.get('flECO-AFL')
            nitrogen_saturation = cast.get('n2satMg/L')
            density = cast.get('density00')
            descent_rate = cast.get('dz/dtM')
            sound_velocity = cast.get('svCM')
            flag = cast.get('flag')
            pressure = cast.index
            pressure = -pressure
          

            #print(f"Datos extraídos del CNV: Temperature: {len(temperature)}, Time: {len(time)}, Salinity: {len(salinity)}, Conductivity: {len(conductivity)}, Oxygen: {len(oxygen)}, Fluorescence: {len(fluorescence)}, Nitrogen Saturation: {len(nitrogen_saturation)}, Density: {len(density)}, Descent Rate: {len(descent_rate)}, Sound Velocity: {len(sound_velocity)}, Flag: {len(flag)}, Pressure: {len(pressure)}")

            variables_dict = {
                'Temperature': temperature,
                'Salinity': salinity,
                'Conductivity': conductivity,
                'Oxygen': oxygen,
                'pH':pH,
                'Fluorescence': fluorescence,
                'Nitrogen Saturation': nitrogen_saturation,
                'Density': density,
                'Descent Rate': descent_rate,
                'Sound Velocity': sound_velocity,
                'Flag': flag
            }

            try:
                quality_factor = QualityFactors.objects.get(id=1)  # Ajusta según sea necesario
            except QualityFactors.DoesNotExist:
                return Response({"error": "El factor de calidad con ID 1 no existe."}, status=status.HTTP_400_BAD_REQUEST)

            for variable_name, data in variables_dict.items():
                try:
                    variable = Variables.objects.get(sensor__measurement__name=station_name, name=variable_name)
                    
                    for i, value in enumerate(data):
                        if pd.isna(value):
                            print(f"El valor en la fila {i} para {variable_name} es NaN o None")
                            continue
                        
                        try:
                            timestamp = datetime.fromtimestamp(time[i] / 1000) if i < len(time) else datetime.now()
                        except Exception as e:
                            print(f"Error al convertir timestamp: {str(e)}")
                            timestamp = datetime.now()  # Valor por defecto

                        print(f"Creando ProfileData con: process_descriptor=0.0, quality_factor={quality_factor}, depth_marker={pressure[i] if i < len(pressure) else 0.0}, variable={variable}, variable_value={float(value)}, timestamp={timestamp}")
                        
                        try:
                            profile_data = ProfileData(
                                process_descriptor=0.0,
                                quality_factor=quality_factor,
                                depth_marker=pressure[i] if i < len(pressure) else 0.0,
                                variable=variable,
                                variable_value=float(value),
                                timestamp=dataTime
                            )
                            profile_data.full_clean()  # Valida el objeto antes de guardarlo
                            profile_data.save()
                            print(f"ProfileData para la variable '{variable_name}' guardado exitosamente.")
                        except Exception as e:
                            print(f"Error al guardar ProfileData para la variable '{variable_name}': {str(e)}")
                except Variables.DoesNotExist:
                    print(f"Variable '{variable_name}' no existe.")
                except Exception as e:
                    print(f"Error al procesar variable '{variable_name}': {str(e)}")
            
            return Response({"status": "Archivo procesado exitosamente."}, status=status.HTTP_200_OK)
        
        except Exception as e:
            print(f"Error al procesar el archivo: {str(e)}")
            return Response({"error": f"Ocurrió un error al procesar el archivo: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class UploadCSVView(APIView):
    def post(self, request, *args, **kwargs):
        # Obtén el archivo del request
        file = request.FILES.get('file')
        
        # Verifica si el archivo existe y es del tipo esperado
        if not file or not file.name.endswith('.cnv'):
            return Response({"error": "This is not a CNV file"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Guarda el archivo en un archivo temporal
            with tempfile.NamedTemporaryFile(delete=False, suffix='.cnv') as temp_file:
                for chunk in file.chunks():
                    temp_file.write(chunk)
                temp_file.seek(0)
                temp_file_path = temp_file.name
            
            print("Iniciando el proceso de carga del CNV...")
            # Procesa el archivo temporal
            cast = ctd.from_cnv(temp_file_path)
            
            # Acceder a datos específicos
            temperature = cast.get('tv290C')
            time = cast.get('timeM')
            salinity = cast.get('sal00')
            conductivity = cast.get('c0mS/cm')
            oxygen = cast.get('sbeox0Mg/L')
            fluorescence = cast.get('flSP')
            nitrogen_saturation = cast.get('n2satMg/L')
            density = cast.get('density00')
            descent_rate = cast.get('dz/dtM')
            sound_velocity = cast.get('svCM')
            flag = cast.get('flag')
            pressure = cast.index
            pressure = -pressure
            
            
            print(f"Variables extraídas del CNV exitosamente: Temperature: {len(temperature)} Time: {len(time)} Salinity: {len(salinity)} Conductivity: {len(conductivity)}, Oxygen: {len(oxygen)}, Fluorescence: {len(fluorescence)}, Nitrogen Saturation: {len(nitrogen_saturation)}, Density: {len(density)}, Descent Rate: {len(descent_rate)}, Sound Velocity: {len(sound_velocity)}, Flag: {len(flag)}, Pressure: {len(pressure)}")


            # Opcionalmente, guarda 'cast' en la base de datos o realiza otras acciones aquí

            return Response({"status": "File processed successfully."}, status=status.HTTP_200_OK)
        
        except Exception as e:
            # Maneja cualquier excepción que ocurra durante el procesamiento
            print(f"Error processing file: {e}")
            return Response({"error": "An error occurred while processing the file."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class QualityFactorsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                quality_factor = QualityFactors.objects.get(pk=pk)
                serializer = QualityFactorsSerializer(quality_factor)
                return Response(serializer.data)
            except QualityFactors.DoesNotExist:
                return Response({"error": "Quality Factor not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            quality_factors = QualityFactors.objects.all()
            serializer = QualityFactorsSerializer(quality_factors, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = QualityFactorsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            quality_factor = QualityFactors.objects.get(pk=pk)
        except QualityFactors.DoesNotExist:
            return Response({"error": "Quality Factor not found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = QualityFactorsSerializer(quality_factor, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            quality_factor = QualityFactors.objects.get(pk=pk)
        except QualityFactors.DoesNotExist:
            return Response({"error": "Quality Factor not found"}, status=status.HTTP_404_NOT_FOUND)
        
        quality_factor.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    

from .models import Disciplines
from .serializers import DisciplinesSerializer


class DisciplinesView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                discipline = Disciplines.objects.get(pk=pk)
                serializer = DisciplinesSerializer(discipline)
                return Response(serializer.data)
            except Disciplines.DoesNotExist:
                return Response({"error": "Discipline not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            disciplines = Disciplines.objects.all()
            serializer = DisciplinesSerializer(disciplines, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = DisciplinesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    from .models import Coasts

from .serializers import CoastsSerializer


class CoastsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                coast = Coasts.objects.get(pk=pk)
                serializer = CoastsSerializer(coast)
                return Response(serializer.data)
            except Coasts.DoesNotExist:
                return Response({"error": "Coast not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            coasts = Coasts.objects.all()
            serializer = CoastsSerializer(coasts, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = CoastsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
from .models import SamplingRates
from .serializers import SamplingRatesSerializer


class SamplingRatesView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                sampling_rate = SamplingRates.objects.get(pk=pk)
                serializer = SamplingRatesSerializer(sampling_rate)
                return Response(serializer.data)
            except SamplingRates.DoesNotExist:
                return Response({"error": "Sampling Rate not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            sampling_rates = SamplingRates.objects.all()
            serializer = SamplingRatesSerializer(sampling_rates, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = SamplingRatesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            sampling_rate = SamplingRates.objects.get(pk=pk)
        except SamplingRates.DoesNotExist:
            return Response({"error": "Sampling Rate not found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = SamplingRatesSerializer(sampling_rate, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            sampling_rate = SamplingRates.objects.get(pk=pk)
        except SamplingRates.DoesNotExist:
            return Response({"error": "Sampling Rate not found"}, status=status.HTTP_404_NOT_FOUND)
        
        sampling_rate.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    
from .models import CecoldoCodes
from .serializers import CecoldoCodesSerializer


class CecoldoCodesView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                sampling_rate = CecoldoCodes.objects.get(pk=pk)
                serializer = CecoldoCodesSerializer(sampling_rate)
                return Response(serializer.data)
            except CecoldoCodes.DoesNotExist:
                return Response({"error": "Sampling Rate not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            sampling_rates = SamplingRates.objects.all()
            serializer = SamplingRatesSerializer(sampling_rates, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = CecoldoCodesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)    

from .models import Departments
from .serializers import DepartmentsSerializer


class DepartmentsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                department = Departments.objects.get(pk=pk)
                serializer = DepartmentsSerializer(department)
                return Response(serializer.data)
            except Departments.DoesNotExist:
                return Response({"error": "Department not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            departments = Departments.objects.all()
            serializer = DepartmentsSerializer(departments, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = DepartmentsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from .models import ProcessingLevels
from .serializers import ProcessingLevelsSerializer


class ProcessingLevelsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                processing_level = ProcessingLevels.objects.get(pk=pk)
                serializer = ProcessingLevelsSerializer(processing_level)
                return Response(serializer.data)
            except ProcessingLevels.DoesNotExist:
                return Response({"error": "Processing Level not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            processing_levels = ProcessingLevels.objects.all()
            serializer = ProcessingLevelsSerializer(processing_levels, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = ProcessingLevelsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            processing_level = ProcessingLevels.objects.get(pk=pk)
        except ProcessingLevels.DoesNotExist:
            return Response({"error": "Processing Level not found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = ProcessingLevelsSerializer(processing_level, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            processing_level = ProcessingLevels.objects.get(pk=pk)
        except ProcessingLevels.DoesNotExist:
            return Response({"error": "Processing Level not found"}, status=status.HTTP_404_NOT_FOUND)
        
        processing_level.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

# views.py
from .models import MeasurementUnits
from .serializers import MeasurementUnitsSerializer


class MeasurementUnitsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                measurement_unit = MeasurementUnits.objects.get(pk=pk)
                serializer = MeasurementUnitsSerializer(measurement_unit)
                return Response(serializer.data)
            except MeasurementUnits.DoesNotExist:
                return Response({"error": "Measurement Unit not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            measurement_units = MeasurementUnits.objects.all()
            serializer = MeasurementUnitsSerializer(measurement_units, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = MeasurementUnitsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)    
from .models import Measurements
from .serializers import MeasurementsSerializer


class MeasurementsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                measurement = Measurements.objects.get(pk=pk)
                serializer = MeasurementsSerializer(measurement)
                return Response(serializer.data)
            except Measurements.DoesNotExist:
                return Response({"error": "Measurement not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            measurements = Measurements.objects.all()
            serializer = MeasurementsSerializer(measurements, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = MeasurementsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from .models import Measurements
from .serializers import MeasurementsSerializer


class MeasurementsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                measurement = Measurements.objects.get(pk=pk)
                serializer = MeasurementsSerializer(measurement)
                return Response(serializer.data)
            except Measurements.DoesNotExist:
                return Response({"error": "Measurement not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            measurements = Measurements.objects.all()
            serializer = MeasurementsSerializer(measurements, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = MeasurementsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from .models import Equipments
from .serializers import EquipmentsSerializer


class EquipmentsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                equipment = Equipments.objects.get(pk=pk)
                serializer = EquipmentsSerializer(equipment)
                return Response(serializer.data)
            except Equipments.DoesNotExist:
                return Response({"error": "Equipment not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            equipments = Equipments.objects.all()
            serializer = EquipmentsSerializer(equipments, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = EquipmentsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            equipment = Equipments.objects.get(pk=pk)
        except Equipments.DoesNotExist:
            return Response({"error": "Equipment not found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = EquipmentsSerializer(equipment, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            equipment = Equipments.objects.get(pk=pk)
        except Equipments.DoesNotExist:
            return Response({"error": "Equipment not found"}, status=status.HTTP_404_NOT_FOUND)
        
        equipment.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

# views.py
from .models import MaintenancesDates
from .serializers import MaintenancesDatesSerializer


class MaintenancesDatesView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                maintenance_date = MaintenancesDates.objects.get(pk=pk)
                serializer = MaintenancesDatesSerializer(maintenance_date)
                return Response(serializer.data)
            except MaintenancesDates.DoesNotExist:
                return Response({"error": "Maintenance Date not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            maintenance_dates = MaintenancesDates.objects.all()
            serializer = MaintenancesDatesSerializer(maintenance_dates, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = MaintenancesDatesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from .models import Settings
from .serializers import SettingsSerializer


class SettingsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                setting = Settings.objects.get(pk=pk)
                serializer = SettingsSerializer(setting)
                return Response(serializer.data)
            except Settings.DoesNotExist:
                return Response({"error": "Setting not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            settings = Settings.objects.all()
            serializer = SettingsSerializer(settings, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = SettingsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

from .models import Variables
from .serializers import VariablesSerializer


class VariablesView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                variable = Variables.objects.get(pk=pk)
                serializer = VariablesSerializer(variable)
                return Response(serializer.data)
            except Variables.DoesNotExist:
                return Response({"error": "Variable not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            variables = Variables.objects.all()
            serializer = VariablesSerializer(variables, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = VariablesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from .models import ProfileData
from .serializers import ProfileDataSerializer


class ProfileDataView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                profile_data = ProfileData.objects.get(pk=pk)
                serializer = ProfileDataSerializer(profile_data)
                return Response(serializer.data)
            except ProfileData.DoesNotExist:
                return Response({"error": "Profile Data not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            profile_data = ProfileData.objects.all()
            serializer = ProfileDataSerializer(profile_data, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = ProfileDataSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)                   
