from django.db import IntegrityError, transaction


class TimeSeriesViewSets(viewsets.ModelViewSet):
    queryset = TimeSeries.objects.all()
    serializer_class = TimeseriesSerializer
 
    @action(detail=False, methods=['post'])
    def upload_csv(self, request):
        print("Iniciando el proceso de carga del CSV...")
 
        try:
            print("Cargando datos JSON del request...")
            json_data = json.loads(request.data['file'])
            fname = request.data.get('fname')
            print("Datos JSON cargados exitosamente.")
        except json.JSONDecodeError as e:
            print(f"Formato JSON inválido: {str(e)}")
            return Response({"error": f"Formato JSON inválido: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)
        except KeyError:
            print("No se proporcionaron datos JSON en el request.")
            return Response({"error": "No se proporcionaron datos JSON"}, status=status.HTTP_400_BAD_REQUEST)
 
        try:
            print("Procesando el nombre del archivo CSV...")
            parts = self.process_csv_name(fname)
            if 'error' in parts:
                print(f"Error en el nombre del archivo CSV: {parts['error']}")
                return Response(parts, status=status.HTTP_400_BAD_REQUEST)
 
            station_abbreviation, variable_abbreviation, processing_level_abbreviation = parts['parts']
            print(f"Nombre del archivo CSV procesado exitosamente. {station_abbreviation}, {variable_abbreviation}, {processing_level_abbreviation}")
 
            print("Buscando instancia del sensor...")
            used_sensor_instance = Sensors.objects.filter(
                variable__abbreviation__iexact=variable_abbreviation,
                variable__processing_level__abbreviation__iexact=processing_level_abbreviation,
                station__abbreviation__iexact=station_abbreviation
            ).first()
            if not used_sensor_instance:
                print(f"Sensor no encontrado para la estación '{station_abbreviation}' y el sensor '{variable_abbreviation}'.")
                return Response({"error": f"Estación '{station_abbreviation}' y/o sensor '{variable_abbreviation}' no encontrado"}, status=status.HTTP_400_BAD_REQUEST)
            print(f"Instancia del sensor encontrada{used_sensor_instance}.")
 
            print("Recuperando la última fecha y hora de la base de datos...")
            last_record = TimeSeries.objects.filter(used_sensor=used_sensor_instance).order_by('-date_time').first()
            last_date_time = last_record.date_time if last_record else None
            print(f"Última fecha y hora encontrada: {last_date_time}")
 
            print("Creando mapeo de factores de calidad...")
            quality_factors = QualityFactors.objects.all()
            quality_factor_mapping = {str(qf.quality_flag): qf for qf in quality_factors}
            print("Mapeo de factores de calidad creado.")
 
            errors = []
            valid_data = []
 
            print("Filtrando y procesando registros nuevos...")
 
            batch_size = 10000  # Tamaño del lote para procesamiento
            for idx, time_series_data in enumerate(json_data):
                fecha_hora_str = time_series_data.get('Fecha') + ' ' + time_series_data.get('Hora')
                fecha_hora = timezone.make_aware(datetime.strptime(fecha_hora_str, "%Y-%m-%d %H:%M:%S"))
 
                if last_date_time and fecha_hora <= last_date_time:
                    print("evaluando fechas para registros nuevos...")
                    continue
 
                if 'QF' not in time_series_data:
                    quality_factor_obj = None
                else:
                    qf_value = time_series_data.get('QF')
                    quality_factor_obj = quality_factor_mapping.get(str(qf_value))
 
 
                sensor_data_json = time_series_data.get('RLS', -99999)
                if sensor_data_json is None:
                    sensor_data_json = -99999
 
                valid_data.append(TimeSeries(
                    used_sensor=used_sensor_instance,
                    quality_factor=quality_factor_obj,
                    date_time=fecha_hora,
                    sensor_data=sensor_data_json,
                    proces_descriptor=time_series_data.get('PD', '')  
                ))
 
                # Guardar en la base de datos en lotes para manejar la memoria
                if len(valid_data) >= batch_size:
                    print(f"Guardando un lote de {batch_size} registros válidos en la base de datos...")
                    try:
                        with transaction.atomic():
                            TimeSeries.objects.bulk_create(valid_data)
                        print(f"Lote de {batch_size} registros guardados exitosamente.")
                        valid_data.clear()
                    except IntegrityError as e:
                        print(f"Error en la base de datos: {str(e)}")
                        return Response({"error": f"Error en la base de datos: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
 
            # Guardar los registros restantes
            if valid_data:
                print("Guardando los registros restantes en la base de datos...")
                try:
                    with transaction.atomic():
                        TimeSeries.objects.bulk_create(valid_data)
                    print("Todos los registros guardados exitosamente.")
                except IntegrityError as e:
                    print(f"Error en la base de datos: {str(e)}")
                    return Response({"error": f"Error en la base de datos: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
 
            if errors:
                print("Algunos registros fallaron en procesarse.")
                return Response({"status": "Algunos registros fallaron en procesarse", "errors": errors}, status=status.HTTP_207_MULTI_STATUS)
           
            print("El archivo CSV ha sido procesado exitosamente.")
            return Response({"status": "El archivo CSV ha sido procesado exitosamente"}, status=status.HTTP_201_CREATED)
        except Exception as e:
            print(f"Ocurrió un error durante el procesamiento: {str(e)}")
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
 
    def process_csv_name(self, fname):
        if not fname.endswith('.csv'):
            return {"error": "Este no es un archivo CSV"}
 
        parts = fname.split('.')
        if len(parts) != 2:
            raise ValueError("El nombre del archivo no está en el formato esperado.")
        aux = parts[0]
        parts = aux.split('_')
        if len(parts) != 3:
            raise ValueError("El nombre del archivo no está en el formato esperado.")
 
        return {"parts": parts}
   
    def validate_time_series(self, sensor_id):
        timeseries = TimeSeries.objects.filter(used_sensor_id=sensor_id).order_by('date_time')
        if timeseries.exists():
            final_date = timeseries.last().date_time
            print(final_date)
        else:
            final_date = None  # O puedes manejar el caso cuando no hay datos como prefieras
        return final_date
 