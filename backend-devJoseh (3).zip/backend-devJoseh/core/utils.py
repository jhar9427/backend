from django.db.models import F
from rest_framework.response import Response
import pandas as pd
from django.utils import timezone
from rest_framework import status
import pytz
from .models import TimeSeries
from ..database.serializers import TimeSeriesFilterSerializer, TimeSerieslistSerializer

import pandas as pd

def _metadata_time_series(self, request):
    # Validar los parámetros de filtro utilizando el serializador
    filter_response = TimeSeriesFilterSerializer(data=request.data)
    if filter_response.is_valid():
        station_name = filter_response.validated_data.get('station_name')
        variable_name = filter_response.validated_data.get('variable_name')
        processing_level_name = filter_response.validated_data.get('processing_level_name')
    else:
        return Response({"error": "Invalid parameters"}, status=status.HTTP_400_BAD_REQUEST)
    
    # Verificar si todos los parámetros necesarios están presentes
    if not all([station_name, variable_name, processing_level_name]):
        return Response({"error": "Missing required parameters"}, status=status.HTTP_400_BAD_REQUEST)
    
    # Construir la consulta con los parámetros proporcionados
    query_params = {
        'used_sensor__station__name': station_name,
        'used_sensor__variable__name': variable_name,
        'used_sensor__variable__processing_level__name': processing_level_name
    }
    
    # Obtener la primera entrada de la serie temporal que coincida con la consulta
    time_series_entry = TimeSeries.objects.filter(**query_params).select_related(
        'used_sensor__station', 'used_sensor__variable__processing_level'
    ).first()

    # Inicializar el diccionario de metadatos
    metadata = {}
    if time_series_entry:
        metadata = {
            'coast': time_series_entry.used_sensor.station.departament.coast.name,
            'departament': time_series_entry.used_sensor.station.departament.name,
            'install_date': time_series_entry.used_sensor.station.install_date,
            'station': time_series_entry.used_sensor.station.name,
            'station_type': time_series_entry.used_sensor.station.station_type.name,
            'variable': time_series_entry.used_sensor.variable.name,
            'processing_level': time_series_entry.used_sensor.variable.processing_level.name,
            'sensor_model': time_series_entry.used_sensor.sensor_model,
            'latitude': time_series_entry.used_sensor.station.latitude,
            'longitude': time_series_entry.used_sensor.station.longitude
            # 'last_maintenance': last_maintenance_date  # Descomentar si se incluyen fechas de mantenimiento
        }
    else:
        return Response({"error": "No time series data found matching the criteria"}, status=status.HTTP_404_NOT_FOUND)

    # Devolver los metadatos obtenidos
    return Response(metadata, status=status.HTTP_200_OK)

def _monthly_avg(self, request, use_date_range=True):
    # Validar los parámetros de filtro utilizando el serializador
    filter_response = TimeSeriesFilterSerializer(data=request.data)
    if filter_response.is_valid():
        df = pd.DataFrame(filter_response)
        df.set_index('date_time', inplace=True)
    else:
        return Response({"error": "Invalid serie"}, status=status.HTTP_400_BAD_REQUEST)
    print(f'Extrayendo serie cache...')
    # Calculate monthly average
    monthly_avg = df['sensor_data'].resample('M').mean().reset_index()
    monthly_avg['date'] = monthly_avg['date_time'].dt.to_period('M').dt.to_timestamp().dt.date
    monthly_avg = monthly_avg[['date', 'sensor_data']]
    monthly_avg_data = monthly_avg.rename(columns={'sensor_data': 'value'}).to_dict(orient='records')

    return list(monthly_avg_data)

def _reshample_time_serie(self, request, *args, **kwargs):
    print('Remuestreo de series...')

    # Obtiene los datos del request
    serie_data = request.data.get('serie')
    factor = request.data.get('factor')

    if not serie_data or not factor:
        return Response({'error': 'Serie data and factor are required.'}, status=status.HTTP_400_BAD_REQUEST)
    
    try:
        # Convierte la serie de datos en un DataFrame de pandas
        serie_df = pd.DataFrame(serie_data)

        # Asegúrate de que la serie tiene un índice de fecha adecuado
        if 'date_time' not in serie_df.columns:
            return Response({'error': 'The series must have a date_time column.'}, status=status.HTTP_400_BAD_REQUEST)
        
        serie_df['date_time'] = pd.to_datetime(serie_df['date_time'])
        serie_df.set_index('date_time', inplace=True)

        # Realiza el remuestreo de la serie
        serie_out = serie_df.resample(factor).mean()  # Usando la media como ejemplo

        # Convierte el resultado a una lista de diccionarios
        data = serie_out.reset_index().to_dict(orient='records')

        print('Series remuestreada con éxito...')
        return Response(data, status=status.HTTP_200_OK)
    
    except Exception as e:
        print(f'Error en el remuestreo: {e}')
        return Response({'error': 'Error en el remuestreo de la serie.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


def _filter_time_series(self, request, use_date_range=True):
        # Extract parameters from request data
        filter_responce = TimeSeriesFilterSerializer(data=request.data)
        if filter_responce.is_valid():
            station_name = filter_responce.validated_data.get('station_name')
            variable_name = filter_responce.validated_data.get('variable_name')
            processing_level_name = filter_responce.validated_data.get('processing_level_name')
            start_date = filter_responce.validated_data.get('start_date')
            end_date = filter_responce.validated_data.get('end_date')

        print(f'Extrayendo serie: {station_name}, {variable_name}, {processing_level_name}...')
        
        # Ensure the datetime objects are timezone-aware
        time_zone = pytz.timezone('America/Bogota')
        if start_date:
            start_date = timezone.make_aware(pd.to_datetime(start_date), timezone=time_zone)
        if end_date:
            end_date = timezone.make_aware(pd.to_datetime(end_date), timezone=time_zone)

        if not all([station_name, variable_name, processing_level_name]):
            return []

        # Build the query
        query_params = {
            'used_sensor__station__name': station_name,
            'used_sensor__variable__name': variable_name,
            'used_sensor__variable__processing_level__name': processing_level_name
        }
        if use_date_range and start_date and end_date:
            query_params['date_time__range'] = [start_date, end_date]

        time_series = TimeSeries.objects.filter(**query_params).values('date_time', 'sensor_data').order_by('date_time')

        """# Store the filter parameters and data in global cache
        request_id = request.query_params.get('request_id', 'default')
        time_series_cache['filters'][request_id] = {
            'station_name': station_name,
            'variable_name': variable_name,
            'processing_level_name': processing_level_name,
            'start_date': start_date.isoformat() if start_date else None,
            'end_date': end_date.isoformat() if end_date else None
        }
        time_series_cache['data'][request_id] = time_series"""
        
        print('Serie filtrada con exito...')

        return list(time_series)

def _filter_metadata_time_series(self, request):
        # Obtener los parámetros de filtro de la caché global
        filter_responce = TimeSeriesFilterSerializer(data=request.data)
        if filter_responce.is_valid():
            station_name = filter_responce.validated_data.get('station_name')
            variable_name = filter_responce.validated_data.get('variable_name')
            processing_level_name = filter_responce.validated_data.get('processing_level_name')
        
        if not all([station_name, variable_name, processing_level_name]):
            return Response({"error": "Missing required parameters"}, status=status.HTTP_400_BAD_REQUEST)
        
        # Construir la consulta
        query_params = {
            'used_sensor__station__name': station_name,
            'used_sensor__variable__name': variable_name,
            'used_sensor__variable__processing_level__name': processing_level_name
        }
        
        # Obtener la primera entrada de la serie temporal para extraer metadatos
        time_series_entry = TimeSeries.objects.filter(**query_params).select_related(
            'used_sensor__station', 'used_sensor__variable__processing_level'
        ).first()

        # Obtener fechas de mantenimiento
        """maintenance_dates = MaintenancesDates.objects.filter(station__name__iexact=station_name).order_by('date_time')

        if maintenance_dates.exists():
            last_maintenance_date = maintenance_dates.last().date
        else:
            last_maintenance_date = None
            # Mensaje en la terminal si no existen mantenimientos
            print(f"No maintenance records found for station: {station_name}")
        """
        metadata = {}
        if time_series_entry:
            metadata = {
                'coast': time_series_entry.used_sensor.station.departament.coast.name,
                'departament': time_series_entry.used_sensor.station.departament.name,
                'install_date': time_series_entry.used_sensor.station.install_date,
                'station': time_series_entry.used_sensor.station.name,
                'station_type': time_series_entry.used_sensor.station.station_type.name,
                'variable': time_series_entry.used_sensor.variable.name,
                'processing_level': time_series_entry.used_sensor.variable.processing_level.name,
                'sensor_model': time_series_entry.used_sensor.sensor_model,
                'latitude': time_series_entry.used_sensor.station.latitude,
                'longitude': time_series_entry.used_sensor.station.longitude
                #'last_maintenance': last_maintenance_date
            }

        return Response(metadata, status=status.HTTP_200_OK)


def _cecoldo_format(self, request, *args, **kwargs):
    time_series_data = _filter_time_series(request)
    if not time_series_data:
        return Response({"detail": "No data found for the given filters."}, status=status.HTTP_404_NOT_FOUND)
