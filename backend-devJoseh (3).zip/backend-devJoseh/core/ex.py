import os
import re
import ctd
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.interpolate import Rbf

# Ruta del directorio que contiene los archivos CNV
directorio_cnvs = r'C:\Users\jhurtado\Downloads\datos\datos 79'

# Listas para almacenar los datos de cada archivo
profundidades = []
oxigenos = []
latitudes = []

# Función para extraer información del archivo CNV
def extract_information(file_path):
    info = {
        'latitude': ''
    }

    with open(file_path, 'r') as file:
        content = file.read()

        # Regex para extraer latitud
        pattern = r"\*\* Latitud:\s*([0-9\.\-]+)"
        match = re.search(pattern, content)
        if match:
            info['latitude'] = match.group(1).strip()

    return info

# Extraer latitudes de los archivos y determinar el rango
lat = []
for archivo in os.listdir(directorio_cnvs):
    if archivo.endswith('.cnv'):
        ruta_archivo = os.path.join(directorio_cnvs, archivo)
        print(f"Cargando {ruta_archivo}...")

        info = extract_information(ruta_archivo)
        if info['latitude']:
            lat.append(float(info['latitude']))

# Verificar que se haya extraído al menos una latitud
if not lat:
    raise ValueError("No se encontraron latitudes en los archivos CNV.")

# Determinar los límites de latitudes
latmin = min(lat)
latmax = max(lat)

# Iterar sobre cada archivo CNV y extraer la profundidad y oxígeno
for i, archivo in enumerate(os.listdir(directorio_cnvs)):
    if archivo.endswith('.cnv'):
        ruta_archivo = os.path.join(directorio_cnvs, archivo)
        print(f"Cargando {ruta_archivo}...")

        # Leer el archivo CNV
        data = ctd.from_cnv(ruta_archivo)

        # Extraer profundidad
        profundidad = data.index.values

        # Buscar columnas de oxígeno en mg/L o mL/L
        if 'sbeox0Mg/L' in data.columns:
            oxigeno = data['sbeox0Mg/L'].values
        elif 'sbeox0ML/L' in data.columns:
            oxigeno = data['sbeox0ML/L'].values * 1.429  # Conversión de mL/L a mg/L
        else:
            print(f"No se encontró oxígeno en {archivo}")
            continue

        # Verificar que haya datos válidos
        if len(profundidad) == 0 or len(oxigeno) == 0:
            print(f"Datos vacíos en el archivo {archivo}.")
            continue

        mitad_len = len(profundidad) // 2
        profundidad = profundidad[:mitad_len]
        oxigeno = oxigeno[:mitad_len]

        # Ajustar latitudes fijas
        latitudes_fijas = np.linspace(latmax, latmin, len(lat))

        # Comprobar el tamaño de latitudes_fijas
        if i < len(latitudes_fijas):
            latitud_actual = latitudes_fijas[i]
            latitudes.extend([latitud_actual] * len(profundidad))
        else:
            print(f"Índice fuera de límites para latitudes_fijas en el archivo {archivo}.")
            continue

        # Agregar los datos a las listas
        profundidades.append(profundidad)
        oxigenos.append(oxigeno)

# Concatenar los datos
all_profundidades = np.concatenate(profundidades)
all_oxigenos = np.concatenate(oxigenos)
all_latitudes = np.array(latitudes)

# Verificar que los arrays concatenados no estén vacíos
if all_profundidades.size == 0 or all_oxigenos.size == 0:
    raise ValueError("No se encontraron datos para la interpolación.")

# Crear un DataFrame con los datos de oxígeno proporcionados
data_ajuste = {
    'Latitud': [3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4,
                5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6],
    'Longitud': [-79] * 28,
    'Profundidad': [1, 30, 50, 75, 100, 250, 500,
                    1, 30, 50, 75, 100, 250, 500,
                    1, 30, 50, 75, 100, 250, 500,
                    1, 30, 50, 75, 100, 250, 500],
    'Oxigeno': [6.37, 6.2, 2.18, 2.03, 1.48, 0.64, 0.47,
                 6.270259459, 6.238021622, 2.554848649, 2.006805405, 1.918151351, 0.604459459, 0.515805405,
                 6.450859459, 6.054754054, 3.265848649, 2.522140541, 1.778432432, 0.476943243, 0.404189189,
                 6.450859459, 6.054754054, 3.265848649, 2.522140541, 1.778432432, 0.476943243, 0.404189189]
}

# Convertir a DataFrame
df_ajuste = pd.DataFrame(data_ajuste)

# Función para ajustar los valores de oxígeno
def ajustar_oxigeno(row):
    # Filtrar los valores de referencia para la latitud y profundidad dadas
    matches = df_ajuste[(df_ajuste['Latitud'] == row['Latitud']) & (df_ajuste['Profundidad'] == row['Profundidad'])]
    if not matches.empty:
        return matches['Oxigeno'].values[0]  # Retornar el valor ajustado
    return row['Oxigeno']  # Si no hay coincidencia, devolver el original

# Crear un nuevo DataFrame con los datos extraídos
df_extraidos = pd.DataFrame({
    'Latitud': all_latitudes,
    'Profundidad': all_profundidades,
    'Oxigeno': all_oxigenos
})

# Aplicar la función a cada fila para ajustar los valores de oxígeno
df_extraidos['Oxigeno_Ajustado'] = df_extraidos.apply(ajustar_oxigeno, axis=1)

# Ajustar los valores de oxígeno en 1 metro si son inferiores a un umbral
def ajustar_valores(df):
    # Definir el umbral
    umbral = 6.5
    # Ajustar los valores de oxígeno a 1 metro
    df.loc[(df['Profundidad'] == 1) & (df['Oxigeno_Ajustado'] < umbral), 'Oxigeno_Ajustado'] = umbral
    return df

# Aplicar el ajuste de valores
df_extraidos = ajustar_valores(df_extraidos)

# Inspeccionar los valores ajustados a 1 metro
valores_1_metro_ajustados = df_extraidos[df_extraidos['Profundidad'] == 1]
print("Valores de oxígeno a 1 metro ajustados:", valores_1_metro_ajustados)

# Crear una cuadrícula extendida de latitud y profundidad
grid_latitudes_ext = np.linspace(min(latitudes) - 1, max(latitudes) + 1, 400)
grid_profundidades_ext = np.linspace(np.min(all_profundidades) - 100, np.max(all_profundidades) + 100, 2000)
grid_latitudes_ext, grid_profundidades_ext = np.meshgrid(grid_latitudes_ext, grid_profundidades_ext)

# Crear la función Rbf para oxígeno
rbf_oxigeno = Rbf(df_extraidos['Latitud'], df_extraidos['Profundidad'], df_extraidos['Oxigeno_Ajustado'], function='linear')

# Aplicar la función Rbf para extrapolar los valores de oxígeno
oxigeno_grid_ext = rbf_oxigeno(grid_latitudes_ext, grid_profundidades_ext)

# Determinar el rango para la barra de colores
vmin = np.nanmin(df_extraidos['Oxigeno_Ajustado'])
vmax = np.nanmax(df_extraidos['Oxigeno_Ajustado'])
print("Valor mínimo de oxígeno ajustado:", vmin)
print("Valor máximo de oxígeno ajustado:", vmax)

# Crear el gráfico con la cuadrícula extendida
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 6), sharex=True, gridspec_kw={'height_ratios': [1, 1]})

# Gráfico extendido de oxígeno con extrapolación
contour1 = ax1.contourf(grid_latitudes_ext, grid_profundidades_ext, oxigeno_grid_ext, cmap='plasma', levels=500, vmin=vmin, vmax=vmax)
ax1.set_ylim(ax1.get_ylim()[::-1])
ax1.set_title('Estructura vertical extrapolada de oxígeno disuelto en 79W')

# Añadir contornos de líneas para los valores extrapolados
contour_lines1 = ax1.contour(grid_latitudes_ext, grid_profundidades_ext, oxigeno_grid_ext, colors='white', linewidths=1, levels=5)
ax1.clabel(contour_lines1, inline=True, fontsize=8, fmt='%1.1f')

# Gráfico de oxígeno de 0 a 200 metros (extrapolado)
ax2.set_ylim(200, 0)
contour2 = ax2.contourf(grid_latitudes_ext, grid_profundidades_ext, oxigeno_grid_ext, cmap='plasma', levels=500, vmin=vmin, vmax=vmax)

contour_lines2 = ax2.contour(grid_latitudes_ext, grid_profundidades_ext, oxigeno_grid_ext, colors='white', linewidths=1, levels=5)
ax2.clabel(contour_lines2, inline=True, fontsize=9.5, fmt='%1.1f')

# Etiquetas de los ejes
ax1.set_ylabel('Profundidad [m]')
ax2.set_ylabel('Profundidad [m]')
ax2.set_xlabel('Latitud')

# Crear la barra de colores
cbar1 = fig.colorbar(contour1, ax=ax1, location='right', extend='both', pad=0.04, shrink=0.8, format='%.1f')
cbar1.set_label('Oxígeno [mg/L]')

cbar2 = fig.colorbar(contour2, ax=ax2, location='right', pad=0.04, shrink=0.8, format='%.1f')
cbar2.set_label('Oxígeno [mg/L]')

plt.tight_layout()
plt.show()
