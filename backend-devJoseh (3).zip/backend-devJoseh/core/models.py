# Create your models here.
from django.db import models


class CecoldoCodes(models.Model):
    """Model definition for CecoldoCodes."""
    parameter = models.CharField(max_length=50)
    code = models.CharField(max_length=50)
    title = models.CharField(max_length=250)  # Corregido: 'tittle' a 'title'

    class Meta:
        verbose_name = 'CecoldoCode'
        verbose_name_plural = 'CecoldoCodes'
        db_table = 'cecoldo_codes'

    def __str__(self):
        return self.parameter

class Disciplines(models.Model):
    """Model definition for Disciplines."""
    name = models.CharField(max_length=50)
    abbreviation = models.CharField(max_length=20)
    description = models.TextField()

    class Meta:
        verbose_name = 'Discipline'
        verbose_name_plural = 'Disciplines'
        db_table = 'disciplines'

    def __str__(self):
        return self.name

class QualityFactors(models.Model):
    """Model definition for QualityFactors."""
    name = models.CharField(max_length=50)
    quality_flag = models.CharField(max_length=50)
    description = models.CharField(max_length=250)

    class Meta:
        verbose_name = 'QualityFactor'
        verbose_name_plural = 'QualityFactors'
        db_table = 'quality_factors'

    def __str__(self):
        return self.name

class Coasts(models.Model):
    """Model definition for Coasts."""
    name = models.CharField(max_length=50)
    abbreviation = models.CharField(max_length=20)
    description = models.TextField()

    class Meta:
        verbose_name = 'Coast'
        verbose_name_plural = 'Coasts'
        db_table = 'coasts'

    def __str__(self):
        return self.name

class SamplingRates(models.Model):
    """Model definition for SamplingRates."""
    name = models.CharField(max_length=50)
    value = models.FloatField()
    description = models.TextField()

    class Meta:
        verbose_name = 'SamplingRate'
        verbose_name_plural = 'SamplingRates'
        db_table = 'sampling_rates'

    def __str__(self):
        return self.name

class Departments(models.Model): 
    """Model definition for Departments."""
    coast = models.ForeignKey(Coasts, on_delete=models.PROTECT)
    name = models.CharField(max_length=50)
    abbreviation = models.CharField(max_length=5)

    class Meta:
        verbose_name = 'Department'
        verbose_name_plural = 'Departments'
        db_table = 'departments'

    def __str__(self):
        return self.name

class ProcessingLevels(models.Model):
    """Model definition for ProcessingLevels."""
    name = models.CharField(max_length=50)
    abbreviation = models.CharField(max_length=5)
    level = models.SmallIntegerField()
    description = models.TextField()

    class Meta:
        verbose_name = 'ProcessingLevel'
        verbose_name_plural = 'ProcessingLevels'
        db_table = 'processing_levels'

    def __str__(self):
        return self.name

class MeasurementUnits(models.Model):
    """Model definition for MeasurementUnits."""
    discipline = models.ForeignKey(Disciplines, on_delete=models.PROTECT)
    name = models.CharField(max_length=50)
    abbreviation = models.CharField(max_length=5)
    symbol = models.CharField(max_length=20, null=True)
    description = models.TextField(null=True)

    class Meta:
        verbose_name = 'MeasurementUnit'
        verbose_name_plural = 'MeasurementUnits'
        db_table = 'measurement_units'

    def __str__(self):
        return str(self.name)

class Measurements(models.Model):
    """Model definition for Stations."""
    department = models.ForeignKey(Departments, on_delete=models.CASCADE)  # Corregido: 'Departament' a 'Department'
    cecoldo_codes = models.ManyToManyField(CecoldoCodes)
    date_time = models.DateField()
    name = models.CharField(max_length=50)  #para el modelo del erfen
    abbreviation = models.CharField(max_length=10)
    latitude = models.FloatField()
    longitude = models.FloatField()
    operator = models.CharField()
    description = models.TextField()
    #install_date = models.DateField(default=None)
    chief_maneuver = models.CharField(max_length=30)

    class Meta:
        verbose_name = 'measurement'
        verbose_name_plural = 'measurements'
        db_table = 'measurements'

    def __str__(self):
        return f'{self.name} ({self.date_time})'

class Equipments(models.Model):
    """Model definition for Sensors."""
    measurement = models.ForeignKey(Measurements, on_delete=models.PROTECT)
    name = models.CharField(max_length=30)   #para el modelo de est 5
    sensor_model = models.CharField(max_length=50)
    sensor_serial = models.CharField(max_length=50)
    description = models.TextField()

    class Meta:
        verbose_name = 'equipment'
        verbose_name_plural = 'equipments'
        db_table = 'equipments'

    def __str__(self):
        return f'{self.sensor_model} ({self.measurement.name})'
    
class MaintenancesDates(models.Model):
    """Model definition for MaintenancesDates."""
    sensor = models.ForeignKey(Equipments, on_delete=models.CASCADE)
    date = models.DateField()
    news = models.CharField(max_length=400)

    class Meta:
        verbose_name = 'MaintenanceDate'
        verbose_name_plural = 'MaintenanceDates'
        db_table = 'maintenances_dates'

    def __str__(self):
        return str(self.date)

class Settings(models.Model):
    """Model definition for TimeSeries."""
    sensor = models.ForeignKey(Equipments, on_delete=models.PROTECT)
    name = models.CharField(max_length=100)
    environment_state = models.TextField()  # Corregido: 'enviroment_state' a 'environment_state'
    configutation_filel =models.FileField(upload_to='configurations/', null=True, blank=True)
    alpha = models.FloatField()
    beta = models.FloatField()
    loop_edit_min_velocity = models.FloatField()
    bin_average_type = models.FloatField()
    bin_average_scans_to_skip_over =models.FloatField(default=0)
    bin_average_scans_to_omit =models.FloatField(default=0)
    bin_average_min_scans = models.FloatField(default=0)
    bin_average_max_scans = models.FloatField(default=0)
    cast_to_process = models.CharField(max_length=50)
    filter = models.CharField(max_length=30)
    low_pass_a = models.FloatField()
    low_pass_b = models.FloatField()
    derive = models.CharField()
    cell_thermal = models.FloatField()

    class Meta:
        verbose_name = 'setting'
        verbose_name_plural = 'settings'
        db_table = 'settings'

    def __str__(self):
        return f'{self.sensor.measurement.name}'
    
class Variables(models.Model):
    """Model definition for Variables."""
    sensor = models.ForeignKey(Equipments, on_delete=models.CASCADE)
    sampling_rate = models.ForeignKey(SamplingRates, on_delete=models.PROTECT)
    processing_level = models.ForeignKey(ProcessingLevels, on_delete=models.PROTECT)
    name = models.CharField(max_length=50)
    abbreviation = models.CharField(max_length=30)
    #min_value_filter = models.FloatField()
    #max_value_filter = models.FloatField()
    measurement_unit = models.ForeignKey(MeasurementUnits, on_delete=models.CASCADE)
    align_ctd = models.FloatField(default=0)
    description = models.TextField(null=True)

    class Meta:
        verbose_name = 'Variable'
        verbose_name_plural = 'Variables'
        db_table = 'variables'

    def __str__(self):
        return f"{self.name} ({self.sensor.measurement.name})"
    
    
class ProfileData(models.Model):
    process_descriptor = models.FloatField(null=True, default= 0000)  
    quality_factor = models.ForeignKey(QualityFactors, on_delete=models.PROTECT, null=True)
    depth_marker = models.FloatField()
    variable = models.ForeignKey(Variables, on_delete=models.PROTECT)
    variable_value = models.FloatField()
    timestamp = models.DateTimeField()
    

    class Meta:
        """Meta definition for TimeSeries."""

        verbose_name = 'ProfileData'
        verbose_name_plural = 'ProfileDatas'
        db_table = 'profile_data'

    def __str__(self):
        """Unicode representation of UsedSensors."""
        return f'{self.variable.name}, prof: ({self.depth_marker}), {self.variable.sensor.measurement.name}'

    def save(self, *args, **kwargs):
        """Save method for UsedSensors."""

        super().save(*args, **kwargs)