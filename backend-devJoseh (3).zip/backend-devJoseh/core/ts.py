import ctd
import gsw
import numpy as np
import matplotlib.pyplot as plt
import os
import glob

# Definir la carpeta donde están los archivos CNV
ruta_cnv = r'C:\Users\jhurtado\Documents\CPC'  # Cambia esta ruta a la ubicación de tus archivos CNV

# Obtener todos los archivos .cnv de la carpeta
archivos_cnv = glob.glob(os.path.join(ruta_cnv, '*.cnv'))

# Listas para almacenar los datos de todos los archivos
sal_list = []
temp_insitu_list = []
profundidad_list = []

# Iterar sobre cada archivo CNV para leer y almacenar los datos
for archivo in archivos_cnv:
    # Leer el archivo CNV
    cast = ctd.from_cnv(archivo)
    # Extraer las variables necesarias
    mitad = len(cast['sal00'].values) // 2  # Calcular la mitad del perfil
    sal_list.append(cast['sal00'].values[mitad:])  # Salinidad (PSU) - segunda mitad del perfil
    temp_insitu_list.append(cast['tv290C'].values[mitad:])  # Temperatura in situ (°C) - segunda mitad
    profundidad_list.append(cast.index.values[mitad:])  # Profundidad - segunda mitad

# Concatenar los datos de todos los archivos
sal = np.concatenate(sal_list)
temp_insitu = np.concatenate(temp_insitu_list)
profundidad = np.concatenate(profundidad_list)

# Calcular la temperatura potencial usando la salinidad, temperatura in situ y profundidad
tem_potencial = gsw.pt0_from_t(sal, temp_insitu, profundidad)

# Clasificación de las masas de agua según las condiciones de temperatura y salinidad
ACC = (tem_potencial > 25) & (tem_potencial < 28) & (sal < 28)
AST = (tem_potencial >= 25) & (tem_potencial < 28) & (sal > 28) & (sal < 35)
AES = (tem_potencial >= 16) & (tem_potencial <= 25) & (sal > 33.5) & (sal <= 36)
ASTSS = (tem_potencial >= 6) & (tem_potencial <= 16) & (sal >= 34) & (sal <= 36)
AAI = (tem_potencial < 6) & (sal > 34) & (sal <= 36)

# Crear una malla de salinidad y temperatura para calcular la densidad
smin = sal.min() - (0.01 * sal.min())
smax = sal.max() + (0.01 * sal.max())
tmin = tem_potencial.min() - (0.1 * tem_potencial.max())
tmax = tem_potencial.max() + (0.1 * tem_potencial.max())

salinity_grid = np.linspace(smin, smax, 100)
temperature_grid = np.linspace(tmin, tmax, 100)
S, T = np.meshgrid(salinity_grid, temperature_grid)
density = gsw.sigma0(S, T)  # Calcular la densidad a partir de la salinidad y temperatura

# Definir el rango mínimo y máximo para la barra de color
min_prof = 0   # Cambia esto al valor mínimo deseado
max_prof = 1000  # Cambia esto al valor máximo deseado
incremento = 100 # Cambia esto al incremento deseado

# Graficar las isolíneas de densidad con un zorder bajo
plt.figure(figsize=(10, 7))
CS = plt.contour(S, T, density, colors='k', linestyles='dashed', levels=np.arange(15, 30, 1), zorder=1)
plt.clabel(CS, fontsize=10, fmt='%1.0f')

# Graficar las masas de agua con diferentes colores (zorder alto para que estén sobre las isolíneas)
# Añadir la barra de color para la profundidad
scatter = plt.scatter(sal, tem_potencial, c=profundidad, cmap='jet_r', s=10, zorder=2)

# Establecer límites de la barra de color en el objeto scatter
scatter.set_clim(min_prof, max_prof)

cbar = plt.colorbar(scatter, label='Profundidad [m]', orientation='vertical')

# Configuración de la barra de color para que tenga ticks en el rango definido
cbar.set_ticks(np.arange(min_prof, max_prof + incremento, incremento))  # Ticks con incremento especificado

cbar.set_label('Profundidad [m]',weight='bold', fontsize=12)
cbar.ax.invert_yaxis()  # Invertir el eje de la barra de color para que las profundidades mayores estén abajo

# Añadir las etiquetas para cada masa de agua con cuadros negros de fondo
plt.text(33.2, 23, 'ATS', fontsize=15, color='black', weight='bold', bbox=dict(facecolor='white', edgecolor='none', boxstyle='round,pad=0.5'), zorder=3)
plt.text(33.5, 16.5, 'AES', fontsize=15, color='black', weight='bold', bbox=dict(facecolor='white', edgecolor='none', boxstyle='round,pad=0.5'), zorder=3)
plt.text(34, 15, 'ASTSS', fontsize=15, color='black', weight='bold', bbox=dict(facecolor='white', edgecolor='none', boxstyle='round,pad=0.5'), zorder=3)
plt.text(34.2, 8, 'AIA', fontsize=15, color='black', weight='bold', bbox=dict(facecolor='white', edgecolor='none', boxstyle='round,pad=0.5'), zorder=3)

# Configuración del gráfico
plt.xlabel('Salinidad (PSU)', fontsize=12, fontweight='bold')
plt.ylabel('Tpot (°C)', fontsize=12, fontweight='bold')
plt.show()



