import axios from "axios";
import { ChangeEvent, FormEvent, useState } from "react";
import ChartTimeSeries from "../utils/Chart";

interface FormData {
  variable_name: string;
  date: string;
  station_name: string;
}

interface FetchedData {
  [key: string]: any;
}

const FormDataChart: React.FC = () => {
  const [data, setData] = useState<FetchedData[] | null>(null);
  const [formData, setFormData] = useState<FormData>({
    variable_name: "",
    date: "",
    station_name: "",
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      const response = await axios.post<FetchedData[]>(
        "http://127.0.0.1:8000/core/time-series/filter-by-variable/",
        
        formData
      );
      const fetchedData = response.data;
      setData(fetchedData);
    } catch (error) {
      console.error("Error fetching data:", error);
      setData(null); // Reset data on error
    }
  };

  return (
    <>
      <div>
        <form onSubmit={handleSubmit}>
          <div>
            <label>Variable Name:</label>
            <input
              type="text"
              name="variable_name"
              value={formData.variable_name}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <label>Date (YYYY-MM-DD):</label>
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <label>Station Name:</label>
            <input
              type="text"
              name="station_name"
              value={formData.station_name}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit">Fetch Data</button>
        </form>
      </div>
      {data ? (
        <ChartTimeSeries time_series={data} />
      ) : (
        <p>No data available for the selected criteria.</p>
      )}
    </>
  );
};

export default FormDataChart;
