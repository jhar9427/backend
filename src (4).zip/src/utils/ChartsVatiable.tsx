import Chart from "chart.js/auto";
import "chartjs-adapter-date-fns";
import "chartjs-plugin-annotation";
import "chartjs-plugin-zoom";
import { registerables } from 'chart.js';
import zoomPlugin from 'chartjs-plugin-zoom';
import React, { useEffect, useRef, useState } from "react";

import { SketchPicker } from 'react-color';

Chart.register(...registerables, zoomPlugin);

interface ChartLogicProps {
  time_series: { [key: string]: any }[]; // Asegúrate de que este tipo de datos sea correcto
  dataUnits: { [key: string]: any }[]; // Asegúrate de que este tipo de datos sea correcto
  colorVariable1: string; // Color para la primera variable
  colorVariable2: string; // Color para la segunda variable
}

interface FormattedData {
  x: number | null; // Salinidad
  y: number | null; // Temperatura
  z: number | null; // Profundidad
}

interface FormattedDataUnits {
  nameVariable: string;
  unit: string;
}

const ChartTimeSeries: React.FC<ChartLogicProps> = ({ time_series, dataUnits }) => {
  const [myChart, setMyChart] = useState<Chart | null>(null);
  const chartRef = useRef<HTMLCanvasElement>(null);
  const [Datos, setDatos] = useState<FormattedData[]>([]);
  const [data, setData] = useState<FormattedDataUnits[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [initialDatos, setInitialDatos] = useState<FormattedData[]>([]);
  const [showPoints, setShowPoints] = useState<boolean>(false);


  const [colorVariable1, setColorVariable1] = useState("#000000"); // Color para Variable 1
  const [colorVariable2, setColorVariable2] = useState("#000000"); // Color para Variable 2
  const [colorPickerVisible, setColorPickerVisible] = useState(false);
  const [colorTarget, setColorTarget] = useState<"variable1" | "variable2">("variable1");



  const handleColorChange = (color: any) => {
    if (colorTarget === "variable1") {
      setColorVariable1(color.hex);
    } else {
      setColorVariable2(color.hex);
    }
  };

  const handleColorButtonClick = (target: "variable1" | "variable2") => {
    setColorTarget(target);
    setColorPickerVisible(!colorPickerVisible);
  };
  useEffect(() => {
    if (!time_series || time_series.length === 0) {
      setError("No hay datos disponibles");
      return;
    }

    const halfIndex = Math.floor(time_series.length / 2);

    const formattedData: FormattedData[] = time_series.slice(halfIndex).map(
      (entry: { [key: string]: any }) => {
        const y = entry[Object.keys(entry)[2]] || null; // Temperatura
        const x = entry[Object.keys(entry)[1]] || null; // Salinidad
        const z = entry[Object.keys(entry)[0]] || null; // Profundidad
        return { x, y, z };
      }
    );

    const formUnit: FormattedDataUnits[] = dataUnits && dataUnits.length > 0 ? dataUnits.map(
      (entry: { [key: string]: any }) => {
        const nameVariable = entry[Object.keys(entry)[0]];
        const unit = entry[Object.keys(entry)[1]];
        return { nameVariable, unit };
      }
    ) : []; // Verificar que dataUnits no sea nulo y tenga elementos

    setDatos(formattedData);
    setData(formUnit);
    setInitialDatos(formattedData);
    setError(null);
  }, [time_series, dataUnits]);

  useEffect(() => {
    if (Datos.length === 0 || !chartRef.current) return;

    const ctx = chartRef.current.getContext("2d");
    if (ctx) {
      if (myChart) {
        myChart.destroy();
      }

      const newChart = new Chart(ctx, {
        type: "line",
        data: {
          datasets: [
            {
              label: data[0]?.nameVariable || "Variable 1",
              data: Datos.map((item) => ({ x: item.x, y: item.z })), // Salinidad vs Profundidad
              backgroundColor: `${colorVariable1}33`, // Añade opacidad
              borderColor: colorVariable1,
              borderWidth: 1,
              pointRadius: showPoints ? 3 : 0,
              pointHoverRadius: showPoints ? 5 : 0,
              xAxisID: "x",
            },
            {
              label: data[1]?.nameVariable || "Variable 2",
              data: Datos.map((item) => ({ x: item.y, y: item.z })), // Temperatura vs Profundidad
              backgroundColor: `${colorVariable2}33`, // Añade opacidad
              borderColor: colorVariable2,
              borderWidth: 1,
              pointRadius: showPoints ? 3 : 0,
              pointHoverRadius: showPoints ? 5 : 0,
              xAxisID: "x1",
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              type: "linear",
              position: "bottom",
              title: {
                display: true,
                text: data[0]?.nameVariable + " " + "(" + data[0]?.unit + ")" || "Salinidad (PSU)",
                font: { weight: "bold" }
              },
              grid: {
                drawOnChartArea: true,
              },
            },
            x1: {
              type: "linear",
              position: "top",
              title: {
                display: true,
                text: data[1]?.nameVariable + " " + "(" + data[1]?.unit + ")" || "Temperatura (°C)",
                font:{ weight:"bold"}
              },
              grid: {
                drawOnChartArea: true,
              },
            },

            
            y: {
              title: {
                display: true,
                text: "Depth (m)",
                font:{ weight:"bold"}
              },
            },
          },
          plugins: {
            tooltip: {
              callbacks: {
                title: function () {
                  return ""; // Elimina el título del tooltip
                },
                label: function (tooltipItem) {
                  const datasetLabel = tooltipItem.dataset.label || "";
                  const xValue = tooltipItem.raw.x; // Salinidad o Temperatura
                  const yValue = tooltipItem.raw.y; // Profundidad
                  const zValue = Datos[tooltipItem.dataIndex].z; // Profundidad desde los datos

                  if (datasetLabel === data[0]?.nameVariable) {
                    return [`${datasetLabel}: ${xValue} ${data[0]?.unit}`, `Profundidad: ${yValue} m`];
                  } else if (datasetLabel === data[1]?.nameVariable) {
                    return [`${datasetLabel}: ${xValue} ${data[1]?.unit}`, `Profundidad: ${yValue} m`];
                  }
                  return `${datasetLabel}: ${xValue}`;
                },
              },
            },
            zoom: {
              pan: {
                enabled: true,
                mode: 'xy',
              },
              zoom: {
                wheel: {
                  enabled: true,
                },
                pinch: {
                  enabled: true,
                },
                drag: {
                  enabled: true,
                  modifierKey: 'ctrl', // Activates drag zoom with 'ctrl' key
                },
                mode: 'xy',
                limits: {
                  x: { min: 'original', max: 'original' }, // Set x-axis limits
                  y: { min: 'original', max: 'original' }, // Set y-axis limits
                },
                rangeMin: {
                  x: 1, // Minimum x-axis zoom limit
                  y: 0.5, // Minimum y-axis zoom limit
                },
                rangeMax: {
                  x: 10, // Maximum x-axis zoom limit
                  y: 5,  // Maximum y-axis zoom limit
                }
              },
            },



          },
        },
      });

      setMyChart(newChart);
    }
  }, [Datos, showPoints, colorVariable1, colorVariable2]);

  const resetChart = () => {
    setDatos(initialDatos);
    if (myChart) {
      myChart.resetZoom();
    }
  };

  const togglePoints = () => {
    setShowPoints(!showPoints);
  };

  return (
    <div>
      {error ? (
        <p className="text-red-500">{error}</p>
      ) : (
        <div>
          <div>
            <div className="m-3" style={{ backgroundColor: colorVariable1, width: "150px", height: "50px", display: "flex", justifyContent: "center", alignItems: "center" }}>
              <button
                onClick={() => handleColorButtonClick("variable1")}
                style={{ backgroundColor: "transparent", color: "black", border: "none", cursor: "pointer" }}
              >
                Change Color for Variable 1
              </button>
            </div>

            <div style={{ backgroundColor: colorVariable2, width: "150px", height: "50px", display: "flex", justifyContent: "center", alignItems: "center" }}>
              <button
                type="button"
                onClick={() => handleColorButtonClick("variable2")}
                style={{ backgroundColor: "transparent", color: "black", border: "none", cursor: "pointer" }}
              >
                Change Color for Variable 2
              </button>
            </div>
          </div>


          {colorPickerVisible && (
            <SketchPicker className="relative mt-3" color={colorTarget === "variable1" ? colorVariable1 : colorVariable2} onChange={handleColorChange} />
          )}

          <h2 className="text-center mb-4">
            Gráfico de Temperatura y Salinidad vs. Profundidad
          </h2>
          <div className="flex justify-center mb-4">
            <button
              className="transition delay-150 duration-300 ease-in-out bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2"
              onClick={resetChart}
            >
              Restablecer Zoom
            </button>
            <button
              className="transition delay-150 duration-300 ease-in-out bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
              onClick={togglePoints}
            >
              {showPoints ? "Ocultar Círculos" : "Mostrar Círculos"}
            </button>
          </div>

          <div className="relative">
            <canvas
              style={{ width: "760px", height: "800px" }}
              ref={chartRef}

            ></canvas>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChartTimeSeries;
