import './App.css'
import FormDataCharts from './components/form'
import FormDataChart from './components/formx'
import FormDataTeos from './components/formTeos'
import FormDataDepth from './components/formFilterDepth'
import SeccionOxigeno from './components/example'



function App() {
  

  return (
    <>
      <SeccionOxigeno />
    </>
  )
}

export default App
