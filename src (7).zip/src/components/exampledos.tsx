import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';

const OxygenHeatmap = () => {
  const svgRef = useRef<SVGSVGElement>(null);

  // Datos de ejemplo para latitud, profundidad y oxígeno disuelto
  const latitudes = [3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0];
  const profundidades = [0, 25, 50, 75, 100, 125, 150, 200, 250, 300]; // Profundidades variadas
  const oxigeno = [
    [6.5, 6.3, 6.0, 5.8, 5.5, 5.2, 5.0, 4.8, 4.5, 4.0],
    [6.0, 5.8, 5.5, 5.2, 5.0, 4.7, 4.5, 4.2, 4.0, 3.8],
    [5.5, 5.2, 5.0, 4.7, 4.5, 4.2, 4.0, 3.7, 3.5, 3.3],
    [5.0, 4.7, 4.5, 4.2, 4.0, 3.7, 3.5, 3.2, 3.0, 2.8],
    [4.5, 4.3, 4.0, 3.8, 3.5, 3.3, 3.0, 2.8, 2.5, 2.3],
    [4.0, 3.8, 3.5, 3.2, 3.0, 2.8, 2.5, 2.3, 2.0, 1.8],
    [3.5, 3.2, 3.0, 2.8, 2.5, 2.3, 2.0, 1.8, 1.6, 1.4]
  ];

  // Tamaño del gráfico
  const width = 800;
  const height = 600;
  const margin = { top: 50, right: 50, bottom: 50, left: 50 };

  useEffect(() => {
    if (svgRef.current) {
      const svg = d3.select(svgRef.current)
        .attr('width', width)
        .attr('height', height);

      // Crear escalas para latitudes, profundidades y oxígeno
      const xScale = d3.scaleBand()
        .domain(latitudes)
        .range([margin.left, width - margin.right])
        .padding(0.05);

      const yScale = d3.scaleBand()
        .domain(profundidades)
        .range([height - margin.bottom, margin.top])
        .padding(0.05);

      const colorScale = d3.scaleSequential(d3.interpolateYlGnBu) // Cambié la paleta para una escala más adecuada
        .domain([0, 6.5]); // Rango del oxígeno disuelto

      // Crear los rectángulos (celdas del mapa de calor)
      svg.selectAll('.cell')
        .data(oxigeno.flat())
        .enter()
        .append('rect')
        .attr('class', 'cell')
        .attr('x', (d, i) => xScale(latitudes[i % latitudes.length]))
        .attr('y', (d, i) => yScale(profundidades[Math.floor(i / latitudes.length)]))
        .attr('width', xScale.bandwidth())
        .attr('height', yScale.bandwidth())
        .attr('fill', d => colorScale(d))
        .attr('stroke', '#ddd')  // Borde suave para las celdas
        .attr('stroke-width', 1); // Grosor del borde

      // Crear las etiquetas de los ejes
      svg.selectAll('.x-axis')
        .data(latitudes)
        .enter()
        .append('text')
        .attr('class', 'x-axis')
        .attr('x', d => xScale(d) + xScale.bandwidth() / 2)
        .attr('y', height - margin.bottom + 20)
        .attr('text-anchor', 'middle')
        .text(d => d)
        .style('font-size', '12px')
        .style('fill', '#333');  // Color de las etiquetas del eje X

      svg.selectAll('.y-axis')
        .data(profundidades)
        .enter()
        .append('text')
        .attr('class', 'y-axis')
        .attr('x', margin.left - 10)
        .attr('y', d => yScale(d) + yScale.bandwidth() / 2)
        .attr('text-anchor', 'middle')
        .text(d => d + ' m')
        .style('font-size', '12px')
        .style('fill', '#333') // Color de las etiquetas del eje Y
        .style('transform', 'rotate(-90deg)')
        .style('transform-origin', '50% 50%');
    }
  }, [latitudes, profundidades, oxigeno]);

  return (
    <div>
      <h2>Estructura vertical de oxígeno disuelto</h2>
      <svg ref={svgRef}></svg>
    </div>
  );
};

export default OxygenHeatmap;
