import axios from "axios";
import { useState, useEffect } from "react";
import ChartTimeSeries from "../utils/ChartsVatiable";
import ChartSelectDepth from "../utils/chartSelectDepth";

// Interfaces para el formato de datos
interface SensorData {
    valor: number[]; // Valores (temperatura o salinidad)
    profundidad: number[]; // Profundidades
}

interface SensorUnits {
    variable: string[];
    unit: string[];
}

interface ApiResponse {
    temperature: SensorData;
    salinity: SensorData;
}

interface VariableOption {
    name: string;
}

const FormDataDepth = () => {
    const [data, setData] = useState<ApiResponse | null>(null);
    const [dataUnits, setDataUnits] = useState<SensorUnits | null>(null);
    const [variableOptions, setVariableOptions] = useState<VariableOption[]>([]);
    const [valueDepth, setValueDepth] = useState<number[]>([]);
    const [inputData, setInputData] = useState<string>("");

    const [formData, setFormData] = useState({
        variable_name1: "",
        variable_name2: "",
        date: "",
        station_name: "",
        value_depth: ""
    });

    const [colorVariable1, setColorVariable1] = useState("#000000");
    const [colorVariable2, setColorVariable2] = useState("#000000");
    const [colorPickerVisible, setColorPickerVisible] = useState(false);
    const [colorTarget, setColorTarget] = useState<"variable1" | "variable2">("variable1");

    useEffect(() => {
        const fetchVariableOptions = async () => {
            try {
                const response = await axios.get<VariableOption[]>(
                    "http://127.0.0.1:8000/core/variables_names/name/"
                );
                setVariableOptions(response.data);
            } catch (error) {
                console.error("Error fetching variable options:", error);
            }
        };

        fetchVariableOptions();
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleVariableChange = (e: React.ChangeEvent<HTMLSelectElement>, variable: "variable_name1" | "variable_name2") => {
        setFormData({
            ...formData,
            [variable]: e.target.value,
        });
    };

    const handleColorChange = (color: any) => {
        if (colorTarget === "variable1") {
            setColorVariable1(color.hex || "#000000");
        } else {
            setColorVariable2(color.hex || "#000000");
        }
    };

    const handleColorButtonClick = (target: "variable1" | "variable2") => {
        setColorTarget(target);
        setColorPickerVisible(!colorPickerVisible);
    };

    const addDepth = (e: React.MouseEvent<HTMLButtonElement>) => {
        e.preventDefault(); // Evita el comportamiento por defecto del botón
        const parsedDepth = parseFloat(inputData);
        if (!isNaN(parsedDepth)) {
            setValueDepth((prev) => [...prev, parsedDepth]);
            setInputData("");
        }
    };

    const emptyDepth =(e:React.MouseEvent<HTMLButtonElement>)=>{
        e.preventDefault()
        setInputData("")
        setValueDepth([])
    }

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        try {
            const response = await axios.post<ApiResponse>(
                "http://127.0.0.1:8000/core/filter/data-depth/",
                {
                    variable_names: [formData.variable_name1.trim(), formData.variable_name2.trim()],
                    date: formData.date,
                    station_name: formData.station_name,
                    value_depth: valueDepth
                }
            );
            setData(response.data);
        } catch (error) {
            console.error("Error fetching data:", error);
        }

        try {
            const responseUnits = await axios.post<SensorUnits>(
                "http://127.0.0.1:8000/core/filter/var-name-unit/",
                {
                    variable_names: [formData.variable_name1.trim(), formData.variable_name2.trim()],
                    station_name: formData.station_name,
                }
            );
            setDataUnits(responseUnits.data);
        } catch (error) {
            console.error("Error fetching data units:", error);
        }
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="variable1">Select Variable 1:</label>
                    <select
                        id="variable1"
                        name="variable_name1"
                        value={formData.variable_name1}
                        onChange={(e) => handleVariableChange(e, "variable_name1")}
                        required
                    >
                        <option value="">Select a variable</option>
                        {variableOptions.map((variable) => (
                            <option key={variable.name} value={variable.name}>
                                {variable.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label htmlFor="variable2">Select Variable 2:</label>
                    <select
                        id="variable2"
                        name="variable_name2"
                        value={formData.variable_name2}
                        onChange={(e) => handleVariableChange(e, "variable_name2")}
                        required
                    >
                        <option value="">Select a variable</option>
                        {variableOptions.map((variable) => (
                            <option key={variable.name} value={variable.name}>
                                {variable.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label htmlFor="date">Date (YYYY-MM-DD):</label>
                    <input
                        id="date"
                        type="date"
                        name="date"
                        value={formData.date}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label htmlFor="stationName">Station Name:</label>
                    <input
                        id="stationName"
                        type="text"
                        name="station_name"
                        value={formData.station_name}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label htmlFor="depth">Value depth:</label>
                    <input
                        id="depth"
                        type="number"
                        value={inputData}
                        onChange={(e) => setInputData(e.target.value)}
                    />
                    <button onClick={addDepth}>Add Depth</button>
                    <button onClick={emptyDepth}>Empty Depth</button>

                    <ul>
                        {valueDepth.map((depth, index) => (
                            <li key={index}>{depth} meters</li>
                        ))}
                    </ul>
                </div>

                <button type="submit">Fetch Data</button>
            </form>

            {data ? (
                <ChartSelectDepth time_series={data} dataUnits={dataUnits} />
            ) : (
                <p>No data available for the selected criteria.</p>
            )}
        </div>
    );
};

export default FormDataDepth;
