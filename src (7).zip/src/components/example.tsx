import React, { useEffect, useState } from 'react';
import Plot from 'react-plotly.js';

const SeccionOxigeno = () => {
  const [plotData, setPlotData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://127.0.0.1:8000/core/filter/profiles_datas/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            variables_names: ['Temperature'],
            year: '2024',
            stations_names: ['Est_31_CPC', 'Est_27_CPC'],
          }),
        });

        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }

        const data = await response.json();

        // Check if the expected properties are available in the response
        if (data && data.length > 0) {
          const latitudes = data[0].latitudes || []; // Ensure latitudes exists
          const depths = data[0].depths || []; // Ensure depths exists
          const oxygen = data[0].variable || []; // Ensure oxygen exists

          console.log(depths)

          // Set the plot data state
          setPlotData({ latitudes, depths, oxygen });

        } else {
          throw new Error('No data available');
        }

        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Loading and error states
  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  // If plotData is available, render the plot
  if (!plotData) {
    return <div>No data available</div>;
  }

  const { latitudes, depths, oxygen } = plotData;

  return (
    <Plot
      data={[
        {
          z: oxygen, // Oxygen data from the API
          x: latitudes, // Latitudes
          y: depths, // Depths
          type: 'contour', // Contour plot
          colorscale: 'Jet', // Color scale
          contours: {
            coloring: 'heatmap', // Heatmap coloring
            showlabels: true, // Show labels
            labelfont: {
              size: 12,
              color: 'white',
            },
          },
          colorbar: {
            title: 'Oxygen [mg/L]',
          },
        },
      ]}
      layout={{
        title: 'Vertical Oxygen Structure',
        xaxis: {
          title: 'Latitude (°)',
        },
        yaxis: {
          title: 'Depth [m]',
          
        },
      }}
      style={{ width: '100%', height: '100%' }}
    />
  );
};

export default SeccionOxigeno;
