import axios from "axios";
import { ChangeEvent, FormEvent, useEffect, useState } from "react";
import ChartTimeSeries from "../utils/Chart";



interface FetchedData {
    [key: string]: any;
}

interface VariableOption {
    name: string; // Propiedad que contiene el nombre de la variable
}

interface StationOption {
    name: string;
}

const FormDataSeccion: React.FC = () => {
    const [data, setData] = useState<FetchedData[] | null>(null);
    const [variableOptions, setVariableOptions] = useState<VariableOption[]>([]);
    const [stationsOptions, setStationOptions] = useState<StationOption[]>([])
    const [formData, setFormData] = useState({
        variable_name1: "",
        variable_name2: "",
        stations_names: "",
        year: ""
    });


    useEffect(() => {
        const fetchVariableOptions = async () => {
            try {
                const response = await axios.get<VariableOption[]>(
                    "http://127.0.0.1:8000/core/variables_names/name/"
                );
                setVariableOptions(response.data);
            } catch (error) {
                console.error("Error fetching variable options:", error);
            }
        };

        fetchVariableOptions();
    }, []);
    useEffect(() => {
        const fecthSationsOptions = async () => {
            try {
                const response = await axios.get<StationOption[]>(
                    "http://127.0.0.1:8000/core/stations_names/name/"
                );
                setStationOptions(response.data);
            } catch (error) {
                console.log("Error fetching staitions names", error)
            }
        }

        fecthSationsOptions()
    }, [])

    const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleVariableChange1 = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setFormData({
            ...formData,
            variable_name1: e.target.value,
        });
    };

    const handleVariableChange2 = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setFormData({
            ...formData,
            variable_name2: e.target.value,
        });
    };

    const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        try {
            const response = await axios.post<FetchedData[]>(
                "http://127.0.0.1:8000/core/filter/profile_data/",

                {
                    variables_names: [formData.variable_name1.trim(), formData.variable_name2.trim()],
                    stations_names: [formData.stations_names.trim()],
                    year: formData.year
                }
            );
            const fetchedData = response.data;
            setData(fetchedData);
        } catch (error) {
            console.error("Error fetching data:", error);
            setData(null); // Reset data on error
        }
    };

    function handleStationChange(event: ChangeEvent<HTMLSelectElement>): void {
        throw new Error("Function not implemented.");
    }

    return (
        <>
            <div>
                <form onSubmit={handleSubmit}>
                    <div>
                        <label>Select Variable 1:</label>
                        <select
                            name="variable_name1"
                            value={formData.variable_name1}
                            onChange={handleVariableChange1}
                            required
                        >
                            <option value="">Select a variable</option>
                            {variableOptions.map((variable) => (
                                <option key={variable.name} value={variable.name}>
                                    {variable.name}
                                </option>
                            ))}
                        </select>

                    </div>

                    <div>
                        <label>Select Variable 2:</label>
                        <select
                            name="variable_name2"
                            value={formData.variable_name2}
                            onChange={handleVariableChange2}
                            required
                        >
                            <option value="">Select a variable</option>
                            {variableOptions.map((variable) => (
                                <option key={variable.name} value={variable.name}>
                                    {variable.name}
                                </option>
                            ))}
                        </select>

                    </div>
                    <div>
                        <label>Date (YYYY-MM-DD):</label>
                        <input
                            type="date"
                            name="date"
                            value={formData.year}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div>
                        <label>Select Station:</label>
                        <select
                            name="station name"
                            value={formData.stations_names}
                            onChange={handleStationChange}
                            required
                        >
                            <option value="">Select a station</option>
                            {stationsOptions.map((station) => (
                                <option key={station.name} value={station.name}>
                                    {station.name}
                                </option>
                            ))}
                        </select>
                    </div>
                    <button type="submit">Fetch Data</button>
                </form>
            </div>

        </>
    );
};

export default FormDataSeccion;
