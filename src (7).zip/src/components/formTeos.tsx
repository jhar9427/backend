import axios from "axios";
import { useState, useEffect } from "react";
import ChartTimeSeries from "../utils/ChartsVatiable";

import React from "react";
import ChartSeries from "../utils/Chart";


// Interfaz para el formato de los datos de sensores
interface SensorData {
    valor: number[]; // Valores (temperatura o salinidad)
    profundidad: number[]; // Profundidades
}

interface SensorUnits {
    variable: string[];
    unit: string[];
}

// Respuesta esperada desde la API
interface ApiResponse {
    stations: SensorData;
    vairables: SensorData;
}

// Estructura esperada para las opciones de variables
interface VariableOption {
    name: string; // Propiedad que contiene el nombre de la variable
}

const FormDataTeos = () => {
    const [data, setData] = useState<ApiResponse | null>(null);
    const [dataUnits, setDataUnits] = useState<SensorUnits | null>(null);
    const [variableOptions, setVariableOptions] = useState<VariableOption[]>([]);
    const [formData, setFormData] = useState({
        variable_name1: "",
        variable_name2: "",
        
    });

    // Estados para los colores de las gráficas
    const [colorVariable1, setColorVariable1] = useState("#000000"); // Color para Variable 1
    const [colorVariable2, setColorVariable2] = useState("#000000"); // Color para Variable 2
    const [colorPickerVisible, setColorPickerVisible] = useState(false);
    const [colorTarget, setColorTarget] = useState<"variable1" | "variable2">("variable1");

    useEffect(() => {
        const fetchVariableOptions = async () => {
            try {
                const response = await axios.get<VariableOption[]>(
                    "http://127.0.0.1:8000/core/variables_names/name/"
                );
                setVariableOptions(response.data);
            } catch (error) {
                console.error("Error fetching variable options:", error);
            }
        };

        fetchVariableOptions();
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleVariableChange1 = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setFormData({
            ...formData,
            variable_name1: e.target.value,
        });
    };

    const handleVariableChange2 = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setFormData({
            ...formData,
            variable_name2: e.target.value,
        });
    };

    
    const handleColorChange = (color: any) => {
        if (colorTarget === "variable1") {
            setColorVariable1(color.hex);
        } else {
            setColorVariable2(color.hex);
        }
    };

    const handleColorButtonClick = (target: "variable1" | "variable2") => {
        setColorTarget(target);
        setColorPickerVisible(!colorPickerVisible);
    };

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        try {
            const response = await axios.post<ApiResponse>(
                "http://127.0.0.1:8000/core/filter/data-teos/",
                {
                    variable_names: [formData.variable_name1.trim(), formData.variable_name2.trim()],
                    
                }
            );
            setData(response.data);
        } catch (error) {
            console.error("Error fetching data:", error);
        }

        
    };

   console.log(data?.stations)

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Select Variable 1:</label>
                    <select
                        name="variable_name1"
                        value={formData.variable_name1}
                        onChange={handleVariableChange1}
                        required
                    >
                        <option value="">Select a variable</option>
                        {variableOptions.map((variable) => (
                            <option key={variable.name} value={variable.name}>
                                {variable.name}
                            </option>
                        ))}
                    </select>

                </div>

                <div>
                    <label>Select Variable 2:</label>
                    <select
                        name="variable_name2"
                        value={formData.variable_name2}
                        onChange={handleVariableChange2}
                        required
                    >
                        <option value="">Select a variable</option>
                        {variableOptions.map((variable) => (
                            <option key={variable.name} value={variable.name}>
                                {variable.name}
                            </option>
                        ))}
                    </select>

                </div>
                <button type="submit">Fetch Data</button>
            </form>

          <ChartSeries  time_series={data} />

            
        </div>
    );
};

export default FormDataTeos;
