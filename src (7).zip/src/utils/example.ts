import Chart from "chart.js/auto";
import "chartjs-adapter-date-fns";
import zoomPlugin from "chartjs-plugin-zoom";
import { Colors } from "chart.js";
import * as d3 from "d3";
import React, { useEffect, useRef, useState } from "react";

Chart.register(Colors, zoomPlugin);

interface ChartLogicProps {
  time_series: { variables: any[] }[];
}

interface FormattedData {
  salinity: number | null;
  potential_Temperature: number | null;
  depth: number | null;
}

const ChartSeries: React.FC<ChartLogicProps> = ({ time_series }) => {
  const [myChart, setMyChart] = useState<Chart | null>(null);
  const chartRef = useRef<HTMLCanvasElement>(null);
  const [Datos, setDatos] = useState<FormattedData[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [initialDatos, setInitialDatos] = useState<FormattedData[]>([]);
  const [showPoints, setShowPoints] = useState<boolean>(false);

  useEffect(() => {
    if (!time_series || time_series.length === 0) {
      setError("No hay datos disponibles");
      return;
    }

    // Formatear los datos
    const formattedData = time_series.flatMap((entry) =>
      entry.variables.map((variable) => ({
        salinity: variable.salinity || null,
        potential_Temperature: variable.potential_Temperature || null,
        depth: variable.depth || null,
      }))
    );

    setDatos(formattedData);
    setError(null);
  }, [time_series]);

  useEffect(() => {
    if (Datos.length === 0 || !chartRef.current) return;

    const middleIndex = Math.floor(Datos.length / 2);
    const firstHalf = Datos.slice(0, middleIndex);
    const secondHalf = Datos.slice(middleIndex);

    const ctx = chartRef.current.getContext("2d");
    if (ctx) {
      if (myChart) {
        myChart.destroy();
      }
      
      // Escala de colores con D3 (e.g., según profundidad)
      const colorScale = d3
        .scaleSequential(d3.interpolateTurbo) // Paleta de colores
        .domain(d3.extent(Datos, (d) => d.depth) as [number, number]); // Mín y máx de profundidad

      const newChart = new Chart(ctx, {
        type: "scatter",
        data: {
          datasets: [
            {
              label: "Datos del gráfico",
              data: firstHalf.map((item) => ({
                x: item.salinity,
                y: item.potential_Temperature,
                backgroundColor: item.depth ? colorScale(item.depth) : "gray", // Color dinámico
              })),
              pointRadius: 3,
              pointBackgroundColor: firstHalf.map((item) =>
                item.depth ? colorScale(item.depth) : "gray"
              ), // Color para cada punto
              borderColor: "rgba(0, 0, 0, 0.2)",
              borderWidth: 0.3,
            },
            {
              data: firstHalf.map((item) => ({y:item.depth})),
              yAxisID:"y1",
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              type: "linear",
              position: "bottom",
              title: {
                display: true,
                text: "Salinidad (PSU)",
              },
            },
            y: {
              type: "linear",
              title: {
                display: true,
                text: "Temperatura Potencial (°C)",
              },
            },
            y1:{
              title:{
                display:true,
                text:"Profundidad (m)",
              },
              position:"right",
              grid:{
                drawOnChartArea:false,
              }
            }
          },
          plugins: {
            zoom: {
              pan: {
                enabled: true,
                mode: "xy",
              },
              zoom: {
                wheel: {
                  enabled: true,
                },
                mode: "xy",
                drag: {
                  enabled: true,
                  modifierKey: "ctrl",
                },
              },
            },
          },
        },
      });

      setMyChart(newChart);
    }
  }, [Datos]);

  const resetChart = () => {
    setDatos(initialDatos);
    if (myChart) {
      myChart.resetZoom();
    }
  };

  const togglePoints = () => {
    setShowPoints(!showPoints);
  };


  return (
    <div>
    {error ? (
      <p>{error}</p>
    ) : (
      <div className="">
        <h2 className="text-center mb-4">
          Gráfico de Temperatura vs. Profundidad
        </h2>
        <button
          className="transition delay-150 duration-300 ease-in-out"
          onClick={resetChart}
        >
          Restablecer Zoom
        </button>
        <button
          className="transition delay-150 duration-300 ease-in-out ml-2"
          onClick={togglePoints}
        >
          {showPoints ? "Ocultar Círculos" : "Mostrar Círculos"}
        </button>
        <div>
          <canvas
            style={{ width: "1200px", height: "380px" }}
            ref={chartRef}
          ></canvas>
        </div>
      </div>
    )}
  </div>
  );
};

export default ChartSeries;
