import os
import re

import ctd
import matplotlib.pyplot as plt
import numpy as np
import scipy.io
from scipy.interpolate import griddata


# Función para leer datos de la línea de costa desde un archivo .mat
def leer_linea_costa(archivo_mat):
    mat_data = scipy.io.loadmat(archivo_mat)
    longitud_costa = mat_data['XX'].flatten()
    latitud_costa = mat_data['YY'].flatten()
    return longitud_costa, latitud_costa

# Función para leer latitud y longitud del encabezado de un archivo CNV
def extraer_lat_long(archivo_cnv):
    with open(archivo_cnv, 'r') as f:
        lines = f.readlines()
        
    latitud = None
    longitud = None
    
    for line in lines:
        if 'Latitud' in line:
            latitud = re.search(r'Latitud:\s*([\d.-]+)', line).group(1)
        if 'Longitud' in line:
            longitud = re.search(r'Longitud:\s*([\d.-]+)', line).group(1)
        
        if latitud and longitud:
            break
    
    latitud = float(latitud)
    longitud = float(longitud)
    
    if longitud > 0:
        longitud = -longitud
    
    return latitud, longitud

# Función para procesar el archivo CNV y obtener el valor de oxígeno a 2 metros de profundidad
def procesar_cnv(archivo_cnv, profundidad_objetivo):
    cast = ctd.from_cnv(archivo_cnv)
    depth_values = cast.index.values
    mask = depth_values == profundidad_objetivo
    depth_cercana = cast[mask]
    
    if not depth_cercana.empty:
        if 'sbeox0Mg/L' in cast.columns:  # Oxígeno en mg/L
            return depth_cercana['sbeox0Mg/L'].values[0] 
        elif 'sbeox0ML/L' in cast.columns:  # Convertir mg/L a ml/L
            oxigeno_mg_l = depth_cercana['sbeox0ML/L'].values[0]*1.42
            return oxigeno_mg_l  # Factor de conversión
    else:
        return None

# Función para generar un gráfico suavizado con isoterma y línea de costa
def generar_grafico_completo(archivos_cnv, archivo_mat, paleta_colores, profundidad_objetivo):
    latitudes = []
    longitudes = []
    oxigenos = []
    
    for archivo in archivos_cnv:
        lat, lon = extraer_lat_long(archivo)
        oxigeno = procesar_cnv(archivo, profundidad_objetivo)
        
        if oxigeno is not None:
            latitudes.append(lat)
            longitudes.append(lon)
            oxigenos.append(oxigeno)
    
    if len(oxigenos) == 0:
        print("No se encontraron valores de oxígeno a la profundidad deseada.")
        return
    
    # Calcular promedio y mediana de los valores de oxígeno
    promedio_oxigeno = np.mean(oxigenos)
    mediana_oxigeno = np.median(oxigenos)
    
    print(f"Promedio de oxígeno: {promedio_oxigeno:.1f} ml/L")
    print(f"Mediana de oxígeno: {mediana_oxigeno:.1f} ml/L")
    
    xi = np.linspace(min(longitudes), max(longitudes), 800)  # Aumentar la resolución para suavidad
    yi = np.linspace(min(latitudes), max(latitudes), 800)
    xi, yi = np.meshgrid(xi, yi)
    
    # Interpolación cúbica para una transición de color suave
    zi = griddata((longitudes, latitudes), oxigenos, (xi, yi), method='cubic')

    # Reemplazar valores fuera del rango [0, 8] por los límites
    zi = np.clip(zi, 0, 8)

    plt.figure(figsize=(12, 12))
    
    # Crear gráfico con transición de color suave utilizando la paleta elegida
    contour = plt.contourf(xi, yi, zi, levels=100, cmap=paleta_colores, extend='both', vmin=0, vmax=8)
    
    # Barra de color con etiqueta formateada
    cbar = plt.colorbar(contour, format='%.1f')
    cbar.set_label('Oxígeno [mg/L]', fontsize=12)
    
    # Mostrar ticks (incluyendo min, max y valores intermedios)
    ticks = np.linspace(0, 8, 6)  # Establecer 5 marcas de tick entre 0 y 8
    cbar.set_ticks(ticks)
    
    # Establecer etiquetas de ticks con precisión de 1 decimal
    cbar.ax.set_yticklabels([f'{tick:.1f}' for tick in ticks])
    
    # Añadir contornos negros para resaltar algunas áreas
    contornos = plt.contour(xi, yi, zi, levels=6, colors='black', linewidths=0.5)
    plt.clabel(contornos, inline=True, fontsize=10, fmt='%1.1f')
    
    plt.title(f'Oxígeno disuelto a {profundidad_objetivo} m de profundidad', fontsize=14, weight='bold')
    plt.xlabel('Longitud (°)', fontsize=12)
    plt.ylabel('Latitud (°)', fontsize=12)
    
    plt.xticks(fontsize=10)
    plt.yticks(fontsize=10)
    
    # Establecer ticks en intervalos de 1 grado
    plt.xticks(np.arange(np.floor(min(longitudes)), np.ceil(max(longitudes)) + 1, 1), fontsize=10)
    plt.yticks(np.arange(np.floor(min(latitudes)), np.ceil(max(latitudes)) + 1, 1), fontsize=10)
    
    # Añadir cuadrícula en intervalos de 2 grados
    plt.grid(True, which='both', linestyle='--', linewidth=0.5, color='gray')
    
    # Dibujar línea de costa
    longitud_costa, latitud_costa = leer_linea_costa(archivo_mat)
    longitud_costa = np.where(longitud_costa > 0, -longitud_costa, longitud_costa)
    
    plt.fill(longitud_costa, latitud_costa, 'k')
    
    plt.show()


# Carpeta donde se encuentran los archivos CNV
carpeta_cnv = r'C:\Users\jhurtado\Documents\CPC'

# Lista de archivos CNV
archivos_cnv = [os.path.join(carpeta_cnv, f) for f in os.listdir(carpeta_cnv) if f.endswith('.cnv')]

# Ruta al archivo .mat que contiene datos de la línea de costa
archivo_mat = r'C:\Users\jhurtado\OneDrive - dimar.mil.co\Masas de agua\costa2.mat'

# Elegir una paleta de colores (ejemplo: 'viridis', 'plasma', 'inferno', 'magma')
paleta_colores = 'RdYlBu_r'

profundidad_objetivo = 1

# Generar el gráfico suavizado con los valores promedio y mediana de oxígeno
generar_grafico_completo(archivos_cnv, archivo_mat, paleta_colores, profundidad_objetivo)
