import os
import re
import ctd
import numpy as np

# Ruta del directorio que contiene los archivos CNV
directorio_cnvs = r'C:\Users\jhurtado\Documents\Estaciones erfen'

# Lista para almacenar los valores máximos de profundidad de cada archivo
max_profundidades = []

# Iterar sobre cada archivo CNV y extraer la profundidad
for archivo in os.listdir(directorio_cnvs):
    if archivo.endswith('.cnv'):
        ruta_archivo = os.path.join(directorio_cnvs, archivo)
        print(f"Cargando {ruta_archivo}...")

        # Leer el archivo CNV
        data = ctd.from_cnv(ruta_archivo)

        # Extraer profundidad
        profundidad = data.index.values

        # Verificar que haya datos válidos
        if len(profundidad) == 0:
            print(f"Datos vacíos en el archivo {archivo}.")
            continue
        
        # Calcular el valor máximo de profundidad
        max_prof = np.max(profundidad)
        max_profundidades.append(max_prof)

# Convertir a un array de numpy para facilitar el análisis
all_max_profundidades = np.array(max_profundidades)

# Contar cuántos máximos están en cada rango
count_200_300 = np.sum((all_max_profundidades >= 200) & (all_max_profundidades < 300))
count_300_800 = np.sum((all_max_profundidades >= 500) & (all_max_profundidades < 800))
count_900_1300 = np.sum((all_max_profundidades >= 900) & (all_max_profundidades < 1300))

# Imprimir los resultados
print(f"Conteo de profundidades máximas en el rango 200-300: {count_200_300}")
print(f"Conteo de profundidades máximas en el rango 300-800: {count_300_800}")
print(f"Conteo de profundidades máximas en el rango 900-1300: {count_900_1300}")
