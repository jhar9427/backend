try:
            variables_names = request.data.get('variable_names') 
            
            print(variables_names)
            #variables_names = ['Temperature', 'Salinity']
            variables = Variables.objects.filter(name__in=variables_names)
            
            data = []
            variable_data = {name: [] for name in variables_names}
            
           # Obtener los datos de cada variable
            for variable_name in variables_names:
                variable_queryset = variables.filter(name=variable_name)
                for variable in variable_queryset:
                    profile_data = ProfileData.objects.filter(
                        variable=variable
                    ).values('depth_marker', 'variable_value')
                    
                    for entry in profile_data:
                        depth = entry['depth_marker']
                        value = entry['variable_value']
                        # Usamos setdefault para inicializar la lista si no existe
                        variable_data.setdefault(variable_name, []).append({'depth_marker': depth, 'value': value})
            
            # Iterar usando la longitud mínima de 'Temperature' y 'Salinity'
            min_length = min(len(variable_data.get('Temperature', [])), len(variable_data.get('Salinity', [])))
            for i in range(min_length):
                depth = variable_data['Temperature'][i]['depth_marker']
                temp = variable_data['Temperature'][i]['value']
                sal = variable_data['Salinity'][i]['value']
                
                if sal is not None:
                    # Calcular temperatura potencial y densidad
                    tem_potencial = gsw.pt0_from_t(sal, temp, depth)
                    density = gsw.sigma0(sal, temp)
                    
                    # Agregar al resultado final
                    data.append({
                        'depth': depth,
                        'potential_Temperature': tem_potencial,
                        'salinity': sal,
                        'density': density
                        })

           
            serializer=CombinedDataSerializer(data,many=True)  