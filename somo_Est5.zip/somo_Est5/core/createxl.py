import pandas as pd

# Create a DataFrame with the provided data
data = {
    "Latitud": [3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 
                3, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6],
    "Longitud": [-79] * 28,
    "Profundidad": [1, 30, 50, 75, 100, 250, 500, 
                    1, 30, 50, 75, 100, 250, 500,
                    1, 30, 50, 75, 100, 250, 500,
                    1, 30, 50, 75, 100, 250, 500],
    "Oxigeno": [6.37, 6.20, 2.18, 2.03, 1.48, 0.64, 0.47,
                6.270259459, 6.238021622, 2.554848649, 2.006805405,
                1.918151351, 0.604459459, 0.515805405,
                6.450859459, 6.054754054, 3.265848649, 2.522140541,
                1.778432432, 0.476943243, 0.404189189,
                6.450859459, 6.054754054, 3.265848649, 2.522140541,
                1.778432432, 0.476943243, 0.404189189]
}

df = pd.DataFrame(data)

# Save the DataFrame to an Excel file
excel_file_path = r'C:\Users\jhurtado\Downloads\datos\data.xlsx'
df.to_excel(excel_file_path, index=False)

excel_file_path
