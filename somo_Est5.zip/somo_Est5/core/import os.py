from netCDF4 import Dataset

# Cargar el archivo NetCDF (reemplaza 'archivo.nc' con el nombre de tu archivo)
archivo = Dataset(r'C:\Users\jhurtado\Downloads\Clorofila m\clorofila mensual\AQUA_MODIS.20230301_20230331.L3m.MO.CHL.x_chlor_a.nc', 'r')
print(archivo.variables.keys())