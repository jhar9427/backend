import requests
import json

# Define NASA Giovanni endpoint and Earthdata credentials
url = "https://giovanni.gsfc.nasa.gov/giovanni/"
username = " jharym021994"
password = "Jhurtado94#27"

# Giovanni API parameters for MODIS Aqua SST data
params = {
    "service": "TSPlot",                # Time series plot service
    "starttime": "2024-01-01",          # Start date of the time range
    "endtime": "2024-01-31",            # End date of the time range
    "bbox": "-180,-90,180,90",          # Global bounding box (west, south, east, north)
    "data": "MODIS_Aqua_L3_SST_Monthly", # MODIS Aqua monthly SST data product
}

# Make the request to NASA Giovanni
response = requests.get(url, params=params, auth=(username, password))

# Check the response
if response.status_code == 200:
    data = response.json()
    print(json.dumps(data, indent=2))   # Display or process the data as needed
else:
    print("Failed to retrieve data:", response.status_code, response.text)
