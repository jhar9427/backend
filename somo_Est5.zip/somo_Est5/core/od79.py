import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import griddata
import scipy.io

# Función para leer datos de la línea de costa desde un archivo .mat
def leer_linea_costa(archivo_mat):
    mat_data = scipy.io.loadmat(archivo_mat)
    longitud_costa = mat_data['XX'].flatten()
    latitud_costa = mat_data['YY'].flatten()
    return longitud_costa, latitud_costa

# Función para procesar el archivo Excel y obtener las latitudes, longitudes, y valores de oxígeno a 1 metro de profundidad
def procesar_excel(archivo_excel, profundidad_objetivo=1):
    # Leer archivo Excel
    df = pd.read_excel(archivo_excel)
    print(df.columns)

    # Verificar si las columnas necesarias existen en el archivo Excel
    required_columns = ['Latidud', 'Longitud', 'Profundidad', 'OD [mg/L]']
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"La columna '{col}' no se encuentra en el archivo Excel.")
    
    # Filtrar solo los datos donde la profundidad sea 1 metro
    df_filtrado = df[df['Profundidad'] == profundidad_objetivo]
    
    if df_filtrado.empty:
        print(f"No se encontraron datos para la profundidad de {profundidad_objetivo} metros.")
        return None, None, None

    # Extraer latitudes, longitudes y valores de oxígeno (OD [mg/L])
    latitudes = df_filtrado['Latidud'].values
    longitudes = df_filtrado['Longitud'].values
    oxigenos = df_filtrado['OD [mg/L]'].values
    
    # Reemplazar NaNs por 0 o cualquier otro valor si es necesario
    latitudes = np.nan_to_num(latitudes)
    longitudes = np.nan_to_num(longitudes)
    oxigenos = np.nan_to_num(oxigenos)
    
    return latitudes, longitudes, oxigenos

def generar_grafico_completo_excel(archivo_excel, archivo_mat, paleta_colores):
    latitudes, longitudes, oxigenos = procesar_excel(archivo_excel)

    # Verificar si los datos se procesaron correctamente
    if latitudes is None or longitudes is None or oxigenos is None:
        print("No se pudieron procesar los datos. Verifique el archivo Excel.")
        return
    
    # Verificar si hay valores de oxígeno válidos
    if len(oxigenos) == 0:
        print("No se encontraron valores de oxígeno a 1 metro en el archivo Excel.")
        return
    
    # Generar grid usando todos los datos
    xi = np.linspace(min(longitudes), max(longitudes), 800)
    yi = np.linspace(min(latitudes), max(latitudes), 800)
    xi, yi = np.meshgrid(xi, yi)
    
    # Interpolación cúbica para una transición de color suave
    zi = griddata((longitudes, latitudes), oxigenos, (xi, yi), method='cubic')

    # Comprobar si zi tiene valores válidos antes de proceder
    if np.all(np.isnan(zi)):
        print("No se generaron valores válidos en la interpolación.")
        return

    # Filtrar los valores interpolados para longitud >= 79
    zi_filtered = np.where(xi >= 79, zi, np.nan)  # Reemplaza los valores fuera de longitud >= 79 por NaN

    plt.figure(figsize=(12, 12))
    
    # Mínimo y máximo para la escala
    min_val = np.nanmin(zi_filtered) if np.any(~np.isnan(zi_filtered)) else 0  # Valor por defecto si todos son NaN
    max_val = np.nanmax(zi_filtered) if np.any(~np.isnan(zi_filtered)) else 1  # Valor por defecto si todos son NaN
    
    # Crear gráfico con transición de color suave utilizando la paleta elegida
    contour = plt.contourf(xi, yi, zi_filtered, levels=100, cmap=paleta_colores, extend='both', vmin=min_val, vmax=max_val)
    
    # Barra de color con etiqueta formateada
    cbar = plt.colorbar(contour, format='%.1f')
    cbar.set_label('Oxígeno [mg/L]', fontsize=12)

    # Modificar los ticks de la barra de color
    ticks = np.linspace(min_val, max_val, num=6)  # Seis ticks en la barra de color
    cbar.set_ticks(ticks)
    cbar.ax.set_yticklabels([f'{tick:.1f}' for tick in ticks])  # Rotar las etiquetas

    # Añadir contornos negros para resaltar algunas áreas
    contornos = plt.contour(xi, yi, zi_filtered, levels=6, colors='black', linewidths=0.5)
    plt.clabel(contornos, inline=True, fontsize=10, fmt='%1.1f')
    
    plt.title('Oxígeno a 1 metro de profundidad', fontsize=14, weight='bold')
    plt.xlabel('Longitud', fontsize=12)
    plt.ylabel('Latitud', fontsize=12)
    
    plt.xticks(fontsize=10)
    plt.yticks(fontsize=10)
    plt.xticks(np.arange(79, np.ceil(max(longitudes)) + 1, 1), fontsize=10)  # Empezar desde 79
    plt.yticks(np.arange(np.floor(min(latitudes)), np.ceil(max(latitudes)) + 1, 1), fontsize=10)
    
    # Añadir cuadrícula en intervalos de 1 grado
    plt.grid(True, which='both', linestyle='--', linewidth=0.5, color='gray')
    
    # Dibujar línea de costa
    longitud_costa, latitud_costa = leer_linea_costa(archivo_mat)
    longitud_costa = np.where(longitud_costa > 0, -longitud_costa, longitud_costa)
    
    plt.plot(longitud_costa, latitud_costa, color='k', linewidth=0.4, label='Línea de Costa')
    plt.fill(longitud_costa, latitud_costa, 'k')
    
    plt.legend(loc='upper right', fontsize=12)
    plt.show()

# Ruta al archivo Excel que contiene Latitud, Longitud, Profundidad y OD [mg/L]
archivo_excel = r'C:\Users\jhurtado\Documents\Masas de agua\Masas de agua\Datos de oxigeno CPC quimica.xlsx'

# Ruta al archivo .mat que contiene datos de la línea de costa
archivo_mat = r'C:\Users\jhurtado\Documents\Masas de agua\Masas de agua\costa2.mat'

# Elegir una paleta de colores (ejemplo: 'viridis', 'plasma', 'inferno', 'magma')
paleta_colores = 'RdYlBu_r'

# Generar el gráfico suavizado con los valores filtrados por longitud >= 79
generar_grafico_completo_excel(archivo_excel, archivo_mat, paleta_colores)
