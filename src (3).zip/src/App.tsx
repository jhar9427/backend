import './App.css'
import FormDataCharts from './components/form'
import FormDataChart from './components/formx'



function App() {
  

  return (
    <>
      <FormDataCharts />
    </>
  )
}

export default App
