import Chart from "chart.js/auto";
import "chartjs-adapter-date-fns";
import "chartjs-plugin-annotation";
import "chartjs-plugin-zoom";
import React, { useEffect, useRef, useState } from "react";

interface ChartLogicProps {
  time_series: { [key: string]: any }[];
}

interface FormattedData {
  x: number | null; // Temperatura
  y: number | null; // Profundidad
}

const ChartTimeSeries: React.FC<ChartLogicProps> = ({ time_series }) => {
  const [myChart, setMyChart] = useState<Chart | null>(null);
  const chartRef = useRef<HTMLCanvasElement>(null);
  const [Datos, setDatos] = useState<FormattedData[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [initialDatos, setInitialDatos] = useState<FormattedData[]>([]);
  const [showPoints, setShowPoints] = useState<boolean>(false);

  useEffect(() => {
    if (!time_series || time_series.length === 0) {
      setError("No hay datos disponibles");
      return;
    }

    const formattedData: FormattedData[] = time_series.map(
      (entry: { [key: string]: any }) => {
        const y = entry[Object.keys(entry)[0]]; // Profundidad
        const x = entry[Object.keys(entry)[1]]; // Temperatura
        return { x, y };
      }
    );

    setDatos(formattedData);
    setInitialDatos(formattedData);
    setError(null);
  }, [time_series]);

  useEffect(() => {
    if (Datos.length === 0 || !chartRef.current) return;

    const middleIndex = Math.floor(Datos.length / 2);
    const firstHalf = Datos.slice(0, middleIndex);
    const secondHalf = Datos.slice(middleIndex);

    const ctx = chartRef.current.getContext("2d");
    if (ctx) {
      if (myChart) {
        myChart.destroy();
      }

      const newChart = new Chart(ctx, {
        type: "line",
        data: {
          labels: Datos.map((item) => item.y), // Profundidad como etiquetas
          datasets: [
            {
              label: "Bajada",
              data: firstHalf.map((item) => ({ x: item.x, y: item.y })),
              backgroundColor: "rgba(255, 99, 132, 0.2)", // Rojo
              borderColor: "rgba(255, 99, 132, 1)",
              borderWidth: 1,
              pointRadius: showPoints ? 3 : 0, // Círculos visibles si showPoints es true
              pointHoverRadius: showPoints ? 5 : 0, // Efecto hover en los círculos si showPoints es true
            },
            {
              label: "Subida",
              data: secondHalf.map((item) => ({ x: item.x, y: item.y })),
              backgroundColor: "rgba(54, 162, 235, 0.2)", // Azul
              borderColor: "rgba(54, 162, 235, 1)",
              borderWidth: 1,
              pointRadius: showPoints ? 3 : 0, // Círculos visibles si showPoints es true
              pointHoverRadius: showPoints ? 5 : 0, // Efecto hover en los círculos si showPoints es true
            },
          ],
        },

        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              type: "linear",
              position: "bottom",
              title: {
                display: true,
                text: "Temperatura (°C)",
              },
            },
            y: {
              title: {
                display: true,
                text: "Profundidad (m)",
              },
            },
          },
          plugins: {
            zoom: {
              pan: {
                enabled: true,
                mode: "xy",
              },
              zoom: {
                wheel: {
                  enabled: true,
                },
                pinch: {
                  enabled: true,
                },
                drag: {
                  enabled: true,
                  modifierKey: "ctrl",
                },
                mode: "xy",
                onZoomComplete: function ({ chart }) {
                  chart.update("none");
                },
              },
            },
          },
        },
      });

      setMyChart(newChart);
    }
  }, [Datos, showPoints]);

  const resetChart = () => {
    setDatos(initialDatos);
    if (myChart) {
      myChart.resetZoom();
    }
  };

  const togglePoints = () => {
    setShowPoints(!showPoints);
  };

  return (
    <div>
      {error ? (
        <p>{error}</p>
      ) : (
        <div className="">
          <h2 className="text-center mb-4">
            Gráfico de Temperatura vs. Profundidad
          </h2>
          <button
            className="transition delay-150 duration-300 ease-in-out"
            onClick={resetChart}
          >
            Restablecer Zoom
          </button>
          <button
            className="transition delay-150 duration-300 ease-in-out ml-2"
            onClick={togglePoints}
          >
            {showPoints ? "Ocultar Círculos" : "Mostrar Círculos"}
          </button>
          <div>
            <canvas
              style={{ width: "1200px", height: "380px" }}
              ref={chartRef}
            ></canvas>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChartTimeSeries;
