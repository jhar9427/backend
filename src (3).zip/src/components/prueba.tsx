import Chart from "chart.js/auto";
import zoomPlugin from "chartjs-plugin-zoom";
import { useEffect, useRef } from "react";

Chart.register(zoomPlugin);

const TestChart = () => {
  const chartRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (chartRef.current) {
      const ctx = chartRef.current.getContext("2d");
      if (ctx) {
        new Chart(ctx, {
          type: "line",
          data: {
            labels: [1, 2, 3, 4, 5],
            datasets: [
              {
                label: "Test Data",
                data: [1, 2, 3, 4, 5],
                borderColor: "rgba(75, 192, 192, 1)",
                borderWidth: 1,
                fill: false,
              },
            ],
          },
          options: {
            plugins: {
              zoom: {
                pan: {
                  enabled: true,
                  mode: "xy",
                },
                zoom: {
                  wheel: {
                    enabled: true,
                  },
                  pinch: {
                    enabled: true,
                  },
                  mode: "xy",
                },
              },
            },
            scales: {
              x: {
                type: "linear",
                position: "bottom",
              },
              y: {
                beginAtZero: true,
              },
            },
          },
        });
      }
    }
  }, []);

  return <canvas ref={chartRef}></canvas>;
};

export default TestChart;
