class getDataInTeos(viewsets.ViewSet):
    @action(detail=False, methods=['post'], url_path='data-teos')
    def getDataInTeos(self, request):
        try:
            # Extraer nombres de variables desde los datos de la solicitud
            variable_names = request.data.get('variable_names')
            if not variable_names:
                return Response(
                    {"error": "Variable names are required."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            station_data = {}
            
            # Filtrar las estaciones relacionadas con la primera variable
            filter_station_names = Variables.objects.filter(
                name=variable_names[0]
            ).values_list('sensor__measurement__name', flat=True)
            station_names = list(filter_station_names)
            
            # Verificar si hay estaciones asociadas
            if not station_names:
                return Response(
                    {"error": "No stations found for the provided variables."},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Inicializar la estructura de datos
            variable_data = {name: [] for name in variable_names}
            for station_name in station_names:
                station_data[station_name] = []

                # Procesar cada variable
                for variable_name in variable_names:
                    variable_queryset = Variables.objects.filter(name=variable_name, sensor__measurement__name=station_name)
                    
                    for variable in variable_queryset:
                        profile_data = ProfileData.objects.filter(variable=variable).values(
                            'depth_marker', 'variable_value'
                        )
                        
                        def process_entry(entry):
                            return {
                                'depth': -entry['depth_marker'],
                                'value': entry['variable_value']
                            }
                        
                        variable_data[variable.name] = list(map(process_entry, profile_data))

                # Realizar cálculos y agregar datos por estación
                for i in range(len(variable_data['Temperature'])):
                    depth = round(variable_data['Temperature'][i]['depth'], 4)
                    salinity = round(variable_data['Salinity'][i]['value'], 4)
                    temperature = variable_data['Temperature'][i]['value']
                    
                    potential_temperature = round(gsw.pt0_from_t(salinity, temperature, depth), 4)
                    density = round(gsw.sigma0(salinity, temperature), 4)
                    
                    station_data[station_name].append({
                        'depth': depth,
                        'potential_Temperature': potential_temperature,
                        'salinity': salinity,
                        'density': density
                    })

            # Formatear la salida
            data = [
                {'station': station_name, 'variables': variables}
                for station_name, variables in station_data.items()
            ]

            serializer = DataTeosSerializer(data, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Variables.DoesNotExist:
            return Response(
                {"error": "One or more variables not found."},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": f"An unexpected error occurred: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )