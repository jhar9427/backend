from rest_framework import serializers

from .models import ProfileData, QualityFactors


class ProfileDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProfileData
        fields = ['depth_marker', 'variable_value'] 

class QualityFactorsSerializer(serializers.ModelSerializer):
    class Meta:
        model=QualityFactors
        fields='__all__'
        
from rest_framework import serializers

from .models import CecoldoCodes


class CecoldoCodesSerializer(serializers.ModelSerializer):
    class Meta:
        model = CecoldoCodes
        fields = '__all__'

from rest_framework import serializers

from .models import Disciplines


class DisciplinesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Disciplines
        fields = '__all__'
from rest_framework import serializers

from .models import Coasts


class CoastsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Coasts
        fields = '__all__'
from rest_framework import serializers

from .models import SamplingRates


class SamplingRatesSerializer(serializers.ModelSerializer):
    class Meta:
        model = SamplingRates
        fields = '__all__'
from rest_framework import serializers

from .models import Departments


class DepartmentsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Departments
        fields = '__all__'
from rest_framework import serializers

from .models import ProcessingLevels


class ProcessingLevelsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProcessingLevels
        fields = '__all__'
from rest_framework import serializers

from .models import MeasurementUnits


class MeasurementUnitsSerializer(serializers.ModelSerializer):
    class Meta:
        model = MeasurementUnits
        fields = '__all__'
from rest_framework import serializers

from .models import Measurements


class MeasurementsSerializer(serializers.ModelSerializer):
    cecoldo_codes = serializers.PrimaryKeyRelatedField(many=True, queryset=CecoldoCodes.objects.all())

    class Meta:
        model = Measurements
        fields = '__all__'
from rest_framework import serializers

from .models import Equipments


class EquipmentsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Equipments
        fields = '__all__'
from rest_framework import serializers

from .models import MaintenancesDates


class MaintenancesDatesSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaintenancesDates
        fields = '__all__'
from rest_framework import serializers

from .models import Settings


class SettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Settings
        fields = '__all__'
from rest_framework import serializers

from .models import Variables


class VariablesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Variables
        fields = '__all__'


class CombinedDataSerializer(serializers.Serializer):
    depth = serializers.FloatField()  # El campo 'depth' sigue siendo fijo, ya que siempre se espera
    # Las variables dinámicas se generarán a partir de los datos que se proporcionen

    def to_representation(self, instance):
        # Utiliza la representación original para el depth y luego itera sobre las variables restantes
        representation = {'depth': instance['depth']}
        
        # Añadir dinámicamente los otros valores variables (p. ej., temperatura, salinidad, etc.)
        for key, value in instance.items():
            if key != 'depth':  # Excluir 'depth' ya que se maneja por separado
                representation[key] = value
                
        return representation

class VarNameUnitSerializer(serializers.Serializer):
    variable_name = serializers.CharField(max_length=50)
    unit = serializers.CharField(max_length=20)
    
    
from rest_framework import serializers
from .models import Variables

class VariableNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = Variables
        fields = ['name']  # Solo incluimos el campo 'name'
        
class StationNameSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=255)      

class SeasonsDateSerialiizer(serializers.ModelSerializer):
    class Meta:
        model=Measurements
        fields=['date_time'] 
        
       
class VariableSerializer(serializers.Serializer):
    depth = serializers.FloatField()
    potential_Temperature = serializers.FloatField()
    salinity = serializers.FloatField()
    density = serializers.FloatField()

class DataTeosSerializer(serializers.Serializer):
    station = serializers.CharField()
    variables = VariableSerializer(many=True)
    
class DataProfileSerializer(serializers.Serializer):
    station=serializers.CharField()
    coordinate=serializers.ListField(
        child=serializers.FloatField(),allow_empty=False
    )
    variables=CombinedDataSerializer(many=True)
    
class ProfileDataSerializer(serializers.Serializer):
    latitudes = serializers.ListField(child=serializers.FloatField())
    depths = serializers.ListField(child=serializers.FloatField())
    variable = serializers.ListField(child=serializers.FloatField(), required=False)

    def validate(self, data):
        # Ensure there are no invalid float values like NaN, Infinity, -Infinity
        def sanitize_list(value_list):
            return [None if (not isinstance(x, (int, float)) or not (x == x) or x == float('inf') or x == float('-inf')) else x for x in value_list]
        
        # Sanitize the fields before returning the data
        data['latitudes'] = sanitize_list(data['latitudes'])
        data['depths'] = sanitize_list(data['depths'])
        data['variable'] = sanitize_list(data['variable']) if 'variable' in data else []

        return data
    