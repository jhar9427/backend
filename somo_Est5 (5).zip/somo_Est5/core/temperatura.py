import os
import re

import ctd
import matplotlib.pyplot as plt
import numpy as np
import scipy.io
from scipy.interpolate import griddata


# Function to read coastline data from .mat file
def leer_linea_costa(archivo_mat):
    mat_data = scipy.io.loadmat(archivo_mat)
    longitud_costa = mat_data['XX'].flatten()
    latitud_costa = mat_data['YY'].flatten()
    
    # Recortar latitud y longitud al rango deseado
    longitud_costa_recortada = np.clip(longitud_costa, -84, -77)
    latitud_costa_recortada = np.clip(latitud_costa, 1, 10)
    
    return longitud_costa_recortada, latitud_costa_recortada
# Function to read latitude and longitude from CNV file header
def extraer_lat_long(archivo_cnv):
    with open(archivo_cnv, 'r') as f:
        lines = f.readlines()
        
    latitud = None
    longitud = None
    
    for line in lines:
        if 'Latitud' in line:
            latitud = re.search(r'Latitud:\s*([\d.-]+)', line).group(1)
        if 'Longitud' in line:
            longitud = re.search(r'Longitud:\s*([\d.-]+)', line).group(1)
        
        if latitud and longitud:
            break
    
    latitud = float(latitud)
    longitud = float(longitud)
    
    if longitud > 0:
        longitud = -longitud
    
    return latitud, longitud

# Function to process the CNV file and get temperature value at 2 meters depth
def procesar_cnv(archivo_cnv, profundidad_objetivo=2):
    cast = ctd.from_cnv(archivo_cnv)
    depth_values = cast.index.values
    mask = depth_values == profundidad_objetivo
    depth_cercana = cast[mask]
    
    if not depth_cercana.empty:
        if 'sal00' in cast.columns:  # Temperature in Celsius (as an example)
            return depth_cercana['sal00'].values[1]
    return None

def generar_grafico_completo(archivos_cnv, archivo_mat, paleta_colores):
    latitudes = []
    longitudes = []
    temperaturas = []
    
    for archivo in archivos_cnv:
        lat, lon = extraer_lat_long(archivo)
        temperatura = procesar_cnv(archivo)
        
        if temperatura is not None:
            latitudes.append(lat)
            longitudes.append(lon)
            temperaturas.append(temperatura)
    
    if len(temperaturas) == 0:
        print("No se encontraron valores de temperatura a 2 metros en los archivos.")
        return
    
    xi = np.linspace(min(longitudes), max(longitudes), 500)  # Increase resolution for smoothness
    yi = np.linspace(min(latitudes), max(latitudes), 500)
    xi, yi = np.meshgrid(xi, yi)
    
    # Cubic interpolation for smooth color transition
    zi = griddata((longitudes, latitudes), temperaturas, (xi, yi), method='cubic')
    
    plt.figure(figsize=(12, 8))
    
    # Find the minimum and maximum values for the colorbar
    min_val = np.nanmin(zi)
    max_val = np.nanmax(zi)
    
    # Dynamic scale based on temperature range
    levels = np.linspace(min_val, max_val, 100)
    
    # Create plot with smooth color transition using the chosen palette
    contour = plt.contourf(xi, yi, zi, levels=levels, cmap=paleta_colores, extend='both', vmin=min_val, vmax=max_val)
    
    # Color bar with formatted label
    cbar = plt.colorbar(contour, format='%.1f')
    cbar.set_label('Salinidad [UPS]', fontsize=12)
    
    # Show ticks (including min, max and intermediates)
    ticks = np.linspace(min_val, max_val, 6)  # Set 5 tick marks evenly spaced
    cbar.set_ticks(ticks)
    
    # Set tick labels with 2 decimal precision
    cbar.ax.set_yticklabels([f'{tick:.1f}' for tick in ticks])
    
    # Add black contours to highlight some areas
    contornos = plt.contour(xi, yi, zi, levels=6, colors='black', linewidths=0.5)
    plt.clabel(contornos, inline=True, fontsize=10, fmt='%1.1f')
    
    plt.title('Salinidad a 2 metros de profundidad', fontsize=14, weight='bold')
    plt.xlabel('Longitud', fontsize=12)
    plt.ylabel('Latitud', fontsize=12)
    
    # Modify axis ticks to include integers only
    lat_ticks = np.arange(int(np.floor(min(latitudes))), 10 + 1, 1)
    lon_ticks = np.arange(int(np.floor(min(longitudes))), int(np.ceil(max(longitudes))) + 1, 1)
    
    lat_labels = [f"{int(abs(tick))}°{'N' if tick >= 0 else 'S'}" for tick in lat_ticks]
    lon_labels = [f"{int(abs(tick))}°{'E' if tick >= 0 else 'W'}" for tick in lon_ticks]
    
    plt.xticks(lon_ticks, lon_labels, fontsize=10)
    plt.yticks(lat_ticks, lat_labels, fontsize=10)
    
    # Add grid at 1-degree intervals
    #plt.grid(True, which='both', linestyle='--', linewidth=0.5, color='gray')
    
    # Draw coastline
    longitud_costa, latitud_costa = leer_linea_costa(archivo_mat)
    plt.fill(longitud_costa, latitud_costa, 'k')
    
    plt.savefig('grafico_salinidad_alta_calidad.tiff', dpi=200, bbox_inches='tight')
    plt.show()


    # Guardar la imagen en alta calidad
    
 

# Folder where CNV files are located
carpeta_cnv = r'C:\Users\jhurtado\Documents\CPC'

# List of CNV files
archivos_cnv = [os.path.join(carpeta_cnv, f) for f in os.listdir(carpeta_cnv) if f.endswith('.cnv')]

# Path to the .mat file containing coastline data
archivo_mat = r'C:\Users\jhurtado\OneDrive - dimar.mil.co\Masas de agua\costa2.mat'

# Choose a color palette (e.g., 'viridis', 'plasma', 'inferno', 'magma') RdYlBu_r
paleta_colores = 'viridis'

# Generate the smoothed plot with temperature min, max, and intermediate values shown
generar_grafico_completo(archivos_cnv, archivo_mat, paleta_colores)
