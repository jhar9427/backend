import requests

# Nombre del archivo de texto que contiene los enlaces
filename = r'C:\Users\jhurtado\Downloads\links.txt'

# Leer los enlaces desde el archivo de texto
with open(filename, 'r') as file:
    links = file.readlines()

# Descargar cada archivo
for link in links:
    link = link.strip()  # Eliminar espacios en blanco y saltos de línea
    if link:  # Asegurarse de que el enlace no esté vacío
        try:
            response = requests.get(link, allow_redirects=True)
            response.raise_for_status()  # Lanzar un error para respuestas no exitosas

            # Extraer el nombre del archivo de la URL
            file_name = link.split('/')[-1]

            # Guardar el archivo en el disco
            with open(file_name, 'wb') as output_file:
                output_file.write(response.content)

            print(f'Descargado: {file_name}')

        except requests.exceptions.RequestException as e:
            print(f'Error al descargar {link}: {e}')
