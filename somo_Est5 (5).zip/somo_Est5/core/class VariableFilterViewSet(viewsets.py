class VariableFilterViewSet(viewsets.ViewSet):

    @action(detail=False, methods=['post'], url_path='filter_names')
    def filter_variable(self, request):
        variable_name1 = request.data.get('variable_name1')
        variable_name2 = request.data.get('variable_name2')
        date_str = request.data.get('date')
        station_name = request.data.get('station_name')

        if not variable_name1 or not variable_name2 or not station_name or not date_str:
            return Response({'error': 'Falta una o más variables necesarias'}, status=400)

        try:
            date = datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            return Response({'error': 'Invalid date format, should be YYYY-MM-DD'}, status=status.HTTP_400_BAD_REQUEST)

        # Filtrar variables por nombres y estación usando __in para buscar ambos nombres en un solo paso
        variables = Variables.objects.filter(
            name__in=[variable_name1, variable_name2], 
            sensor__measurement__name=station_name
        )
        
        #print(variables)

        if variables.count() != 2:
            return Response({'error': 'No se encontraron las dos variables proporcionadas con los nombres y estación indicados'}, status=404)

        # Asignar las variables correspondientes
        variable1 = variables.get(name=variable_name1)
        variable2 = variables.get(name=variable_name2)

        # Filtrar ProfileData para ambas variables en un solo paso
        profile_data = ProfileData.objects.filter(
            variable__in=[variable1, variable2], 
            timestamp__date=date.date()
        ).values('variable', 'depth_marker', 'variable_value')
        #print(profile_data)
    
        # Organizar los datos por 'depth_marker'
        data_by_depth = {}
        for entry in profile_data:
            depth = entry['depth_marker']
            if depth not in data_by_depth:
                data_by_depth[depth] = {}
                
            #print(data_by_depth)     

            # Asignar valores según la variable (dinámicamente por nombre de la variable)
            if entry['variable'] == variable1.id:
                data_by_depth[depth][variable_name1.lower()] = entry['variable_value']
            elif entry['variable'] == variable2.id:
                data_by_depth[depth][variable_name2.lower()] = entry['variable_value']
                

        # Formar el array de datos combinados
        combined_data = [
            {'depth': depth, 'temperature': values.get('temperature'), 'salinity': values.get('salinity')}
            for depth, values in data_by_depth.items()
        ]

        # Serializar y devolver la respuesta
        serializer = CombinedDataSerializer(combined_data, many=True)
        return Response(serializer.data)
