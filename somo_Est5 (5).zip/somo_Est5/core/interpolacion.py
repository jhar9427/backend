import os
import re
import ctd
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.interpolate import griddata

# Ruta del directorio que contiene los archivos CNV
directorio_cnvs = r'C:\Users\jhurtado\Downloads\datos\datos 79'

# Listas para almacenar los datos de cada archivo
profundidades = []
oxigenos = []
latitudes = []

# Función para extraer información del archivo CNV
def extract_information(file_path):
    info = {
        'latitude': ''
    }

    with open(file_path, 'r') as file:
        content = file.read()

        # Regex para extraer latitud
        pattern = r"\*\* Latitud:\s*([0-9\.\-]+)"
        match = re.search(pattern, content)
        if match:
            info['latitude'] = match.group(1).strip()

    return info

# Extraer latitudes de los archivos y determinar el rango
lat = []
for archivo in os.listdir(directorio_cnvs):
    if archivo.endswith('.cnv'):
        ruta_archivo = os.path.join(directorio_cnvs, archivo)
        print(f"Cargando {ruta_archivo}...")

        info = extract_information(ruta_archivo)
        if info['latitude']:
            lat.append(float(info['latitude']))

# Verificar que se haya extraído al menos una latitud
if not lat:
    raise ValueError("No se encontraron latitudes en los archivos CNV.")

# Determinar los límites de latitudes
latmin = min(lat)
latmax = max(lat)

# Iterar sobre cada archivo CNV y extraer la profundidad y oxígeno
for i, archivo in enumerate(os.listdir(directorio_cnvs)):
    if archivo.endswith('.cnv'):
        ruta_archivo = os.path.join(directorio_cnvs, archivo)
        print(f"Cargando {ruta_archivo}...")

        # Leer el archivo CNV
        data = ctd.from_cnv(ruta_archivo)

        # Extraer profundidad
        profundidad = data.index.values

        # Buscar columnas de oxígeno en mg/L o mL/L
        if 'sbeox0Mg/L' in data.columns:
            oxigeno = data['sbeox0Mg/L'].values
        elif 'sbeox0ML/L' in data.columns:
            oxigeno = data['sbeox0ML/L'].values * 1.429  # Conversión de mL/L a mg/L
        else:
            print(f"No se encontró oxígeno en {archivo}")
            continue

        # Verificar que haya datos válidos
        if len(profundidad) == 0 or len(oxigeno) == 0:
            print(f"Datos vacíos en el archivo {archivo}.")
            continue
        
        mitad_len = len(profundidad) // 2
        profundidad = profundidad[mitad_len:]
        oxigeno = oxigeno[mitad_len:]

        # Ajustar latitudes fijas
        latitudes_fijas = np.linspace(latmax, latmin, len(lat))

        # Comprobar el tamaño de latitudes_fijas
        if i < len(latitudes_fijas):
            latitud_actual = latitudes_fijas[i]
            latitudes.extend([latitud_actual] * len(profundidad))
        else:
            print(f"Índice fuera de límites para latitudes_fijas en el archivo {archivo}.")
            continue

        # Agregar los datos a las listas
        profundidades.append(profundidad)
        oxigenos.append(oxigeno)

# Concatenar los datos
all_profundidades = np.concatenate(profundidades)
all_oxigenos = np.concatenate(oxigenos)
all_latitudes = np.array(latitudes)

# Verificar que los arrays concatenados no estén vacíos
if all_profundidades.size == 0 or all_oxigenos.size == 0:
    raise ValueError("No se encontraron datos para la interpolación.")



archivo_excel = r'C:\Users\jhurtado\Downloads\datos\data.xlsx'  # Especifica la ruta de tu archivo Excel
df_ajuste = pd.read_excel(archivo_excel)

# Convertir a DataFrame
df_ajuste = pd.DataFrame(df_ajuste)
print(df_ajuste.columns)

print(df_ajuste.head())

# Función para ajustar los valores de oxígeno
def ajustar_oxigeno(row):
    # Filtrar los valores de referencia para la latitud y profundidad dadas
    matches = df_ajuste[(df_ajuste['Latitud'] == row['Latitud']) & (df_ajuste['Profundidad'] == row['Profundidad'])]
    if not matches.empty:
        return matches['Oxigeno'].values[0]  # Retornar el valor ajustado
    return row['Oxigeno']  # Si no hay coincidencia, devolver el original

# Crear un nuevo DataFrame con los datos extraídos
df_extraidos = pd.DataFrame({
    'Latitud': all_latitudes,
    'Profundidad': all_profundidades,
    'Oxigeno': all_oxigenos
})

# Aplicar la función a cada fila para ajustar los valores de oxígeno
df_extraidos['Oxigeno_Ajustado'] = df_extraidos.apply(ajustar_oxigeno, axis=1)

# Crear una cuadrícula regular de latitud y profundidad
grid_latitudes, grid_profundidades = np.meshgrid(
    np.linspace(min(latitudes), max(latitudes), 400),
    np.linspace(np.min(all_profundidades), np.max(all_profundidades), 2000)
)

# Ajustar los valores de oxígeno en 1 metro si son inferiores a un umbral
def ajustar_valores(df):
    # Definir el umbral
    umbral = 6.5
    # Ajustar los valores de oxígeno a 1 metro
    df.loc[(df['Profundidad'] == 1) & (df['Oxigeno_Ajustado'] < umbral), 'Oxigeno_Ajustado'] = umbral
    return df

# Aplicar el ajuste de valores
df_extraidos = ajustar_valores(df_extraidos)

# Inspeccionar los valores ajustados a 1 metro
valores_1_metro_ajustados = df_extraidos[df_extraidos['Profundidad'] == 1]
print("Valores de oxígeno a 1 metro ajustados:", valores_1_metro_ajustados)

# Crear una cuadrícula regular de latitud y profundidad
grid_latitudes, grid_profundidades = np.meshgrid(
    np.linspace(min(latitudes), max(latitudes), 400),
    np.linspace(np.min(all_profundidades), np.max(all_profundidades), 2000)
)

# Interpolar los datos de oxígeno ajustados en la cuadrícula
oxigeno_grid = griddata(
    (df_extraidos['Latitud'], df_extraidos['Profundidad']),
    df_extraidos['Oxigeno_Ajustado'],
    (grid_latitudes, grid_profundidades),
    method='cubic'  # Interpolación cúbica
)

# Determinar el rango para la barra de colores
vmin = np.min(df_extraidos['Oxigeno_Ajustado'])
vmax = np.max(df_extraidos['Oxigeno_Ajustado'])
print("Valor mínimo de oxígeno ajustado:", vmin)
print("Valor máximo de oxígeno ajustado:", vmax)

# Crear el gráfico combinado
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 6), sharex=True, gridspec_kw={'height_ratios': [1, 1]})

# Crear la sección de oxígeno total (0-1000 m) con colores cálidos
contour1 = ax1.contourf(grid_latitudes, grid_profundidades, oxigeno_grid, cmap='plasma', levels=500, vmin=vmin, vmax=vmax)

# Invertir el eje Y para que la profundidad vaya de 0 a 1000 m
ax1.set_ylim(ax1.get_ylim()[::-1])
ax1.set_title('Estructura vertical de oxígeno disuelto en 79W')

# Añadir contornos de líneas para los valores de oxígeno
contour_lines1 = ax1.contour(grid_latitudes, grid_profundidades, oxigeno_grid, colors='white', linewidths=1, levels=5)
ax1.clabel(contour_lines1, inline=True, fontsize=8, fmt='%1.1f')

# Limitar la gráfica a profundidades de 0 a 200 metros
ax2.set_ylim(200, 0)  # Profundidad de 0 a 200 metros
contour2 = ax2.contourf(grid_latitudes, grid_profundidades, oxigeno_grid, cmap='plasma', levels=500, vmin=vmin, vmax=vmax)

# Añadir contornos de líneas para los valores de oxígeno en la sección de 0-200 m
contour_lines2 = ax2.contour(grid_latitudes, grid_profundidades, oxigeno_grid, colors='white', linewidths=1, levels=5)
ax2.clabel(contour_lines2, inline=True, fontsize=9.5, fmt='%1.1f')

# Etiquetas de los ejes
ax1.set_ylabel('Profundidad [m]')
ax2.set_ylabel('Profundidad [m]')
ax2.set_xlabel('Latitud')

# Crear la barra de colores
cbar1 = fig.colorbar(contour1, ax=ax1, location='right', extend='both', pad=0.04, shrink=0.8, format='%.1f')
cbar1.set_label('Oxígeno [mg/L]')

# Crear la segunda barra de colores
cbar2 = fig.colorbar(contour2, ax=ax2, location='right', pad=0.04, shrink=0.8, format='%.1f')
cbar2.set_label('Oxígeno [mg/L]')

# Ajustar el espacio entre los gráficos
plt.subplots_adjust(hspace=0.4)  # Aumentar el espacio vertical entre los gráficos

plt.tight_layout()
plt.show()
