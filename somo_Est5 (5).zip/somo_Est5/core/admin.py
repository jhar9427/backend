from django.contrib import admin
from .models import Disciplines, Coasts, SamplingRates, MaintenancesDates, ProcessingLevels
from .models import Departments, CecoldoCodes, QualityFactors, ProfileData
from .models import Variables, MeasurementUnits, Measurements, Equipments, Settings

# Register your models here.
admin.site.register(Disciplines)
admin.site.register(Coasts)
admin.site.register(SamplingRates)
admin.site.register(MaintenancesDates)
admin.site.register(ProcessingLevels)
admin.site.register(Departments)
admin.site.register(CecoldoCodes)
admin.site.register(QualityFactors)
admin.site.register(Variables)
admin.site.register(MeasurementUnits)
admin.site.register(Measurements)
admin.site.register(Equipments)
admin.site.register(Settings)
admin.site.register(ProfileData)