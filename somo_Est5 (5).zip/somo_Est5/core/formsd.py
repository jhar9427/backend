from django import forms


class ProfileDataForm(forms.Form):
    temperature = forms.FloatField(required=True)
    depth_marker = forms.FloatField(required=True)
