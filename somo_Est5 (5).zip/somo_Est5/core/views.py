import tempfile
from datetime import datetime
import ctd  
from scipy.interpolate import griddata
import numpy as np
from django.http import JsonResponse
import gsw
import pandas as pd
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Coasts, Disciplines, Measurements, ProfileData, QualityFactors
from .serializers import (CombinedDataSerializer,DataProfileSerializer, DataTeosSerializer, ProfileDataSerializer,
                          QualityFactorsSerializer, SeasonsDateSerialiizer, StationNameSerializer, VarNameUnitSerializer, VariableNameSerializer)
from .utils import extract_information


class ProfileDataViewSet(viewsets.ViewSet):

    @action(detail=False, methods=['post'], url_path='filter-by-variable')
    def filter_by_variable(self, request):
        try:
            data = request.data
            variable_name = data.get('variable_name')
            date_str = data.get('date')
            station_name = data.get('station_name')

            if not variable_name or not date_str or not station_name:
                return Response({'error': 'Missing required fields'}, status=status.HTTP_400_BAD_REQUEST)

            try:
                date = datetime.strptime(date_str, "%Y-%m-%d")
            except ValueError:
                return Response({'error': 'Invalid date format, should be YYYY-MM-DD'}, status=status.HTTP_400_BAD_REQUEST)

            variable = Variables.objects.filter(name=variable_name, sensor__measurement__name=station_name).first()
            if not variable:
                return Response({'error': 'Variable does not exist'}, status=status.HTTP_404_NOT_FOUND)

            profile_data = ProfileData.objects.filter(variable=variable, timestamp__date=date.date()).values('depth_marker', 'variable_value')
            serializer = ProfileDataSerializer(profile_data, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Exception as e:
            print(f'Unexpected error: {e}')
            return Response({'error': 'Internal server error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        

class DataForStationView(viewsets.ViewSet):

    @action(detail=False, methods=['post'], url_path='data-station')
    def getDataForStation(self, request):
        try:
            variable_names = request.data.get('variable_names')
            date_str = request.data.get('date')
            station_name = request.data.get('station_name')

            if not variable_names or not station_name or not date_str:
                return Response({'error': 'Falta una o más variables necesarias'}, status=status.HTTP_400_BAD_REQUEST)

            try:
                date = datetime.strptime(date_str, "%Y-%m-%d").date()
            except ValueError:
                return Response({'error': 'Invalid date format, should be YYYY-MM-DD'}, status=status.HTTP_400_BAD_REQUEST)

            variables = Variables.objects.filter(name__in=variable_names,sensor__measurement__name=station_name)

            if variables.count() < len(variable_names):
                return Response({'error': 'No se encontraron todas las variables con los nombres y estación proporcionados'}, status=status.HTTP_404_NOT_FOUND)

            variable_data = {name: [] for name in variable_names}
        
            for variable in variables:
                profile_data = ProfileData.objects.filter(
                    variable=variable,
                    timestamp__date=date
                    ).values('depth_marker', 'variable_value')
                
                process_entry = lambda entry: {'depth': -entry['depth_marker'], 
                                               'value': entry['variable_value']}
                variable_data[variable.name] = list(map(process_entry, profile_data))
            
            combined_data = []
            max_length = max(len(data) for data in variable_data.values())
            
            for i in range(max_length):
                depth_entry = {'depth': variable_data[variable_names[0]][i]['depth']}
                get_value = lambda var_name: variable_data[var_name][i]['value'] if i < len(variable_data[var_name]) else None
                depth_entry.update({var_name: get_value(var_name) for var_name in variable_names})
                combined_data.append(depth_entry)
        
            serializer = CombinedDataSerializer(combined_data, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Exception as e:
            print(f'Unexpected error: {e}')
            return Response({"error": "An error occurred while retrieving variable data."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
           
class VarNameUnitView(viewsets.ViewSet):

    @action(detail=False, methods=['post'], url_path='var-name-unit')
    def getNameUnit(self, request):
        try:
            variable_names = request.data.get('variable_names')
            station_name = request.data.get('station_name')

            if not variable_names or not station_name:
                return Response({'error': 'Falta una o más variables necesarias'}, status=status.HTTP_400_BAD_REQUEST)

            variables = Variables.objects.filter(name__in=variable_names, sensor__measurement__name=station_name)
            if not variables.exists():
                return Response({'error': 'No se encontraron variables filtradas'}, status=status.HTTP_404_NOT_FOUND)

            units_data = [{'variable_name': variable.name,'unit': variable.measurement_unit.symbol}for variable in variables]

            serializer = VarNameUnitSerializer(units_data, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Exception as e:
            print(f"Error occurred: {e}")
            return Response(
                {"error": "An error occurred while retrieving variable units."},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    
class VariableNameView(viewsets.ViewSet):
    @action(detail=False, methods=['get'], url_path='name')
    def get(self, request):
        try:
            variable_name = MeasurementUnits.objects.all()
            serializer = VariableNameSerializer(variable_name, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        
        except Exception as e:
            print(f"An error occurred: {e}")
            return Response({"error": "An error occurred while retrieving variable names."}, 
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
class StationNameView(viewsets.ViewSet):
    @action(detail=False, methods=['get'], url_path='name')
    def get(self, request):
        try:
            station_names = Measurements.objects.values_list('name', flat=True).distinct()
            station_list = [{"name": name} for name in station_names] 
            serializer = StationNameSerializer(station_list, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        
        except Exception as e:
            return Response(
                {"Error": f"Error attempting to retrieve station names: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                

class SeasonsDateView(viewsets.ViewSet):
    @action(detail=False, methods=['post'], url_path='date')   
    def post(self,request):
        try:
            station_name=request.data.get('station_name')
            seasons_date=Measurements.objects.filter(name=station_name,)
            serializer=SeasonsDateSerialiizer(seasons_date,many=True)
            return Response(serializer.data,status=status.HTTP_200_OK)
            
        except Exception as e:
            return Response({f"Error intenttando obtener las fechas de muestreo de las estaciones"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)        
    
    
class DataTeosView(viewsets.ViewSet):
    @action(detail=False, methods=['post'], url_path='data-teos')
    def getDataInTeos(self, request):
        try:
          
            variable_names = request.data.get('variable_names')
            if not variable_names:
                return Response({"error": "Variable names are required."},status=status.HTTP_400_BAD_REQUEST)
                
            station_data = {}
            
            filter_station_names = Variables.objects.filter(
                name=variable_names[0]
            ).values_list('sensor__measurement__name', flat=True)
            station_names = list(filter_station_names)
           
            
            variable_data = {name: [] for name in variable_names}
            for station_name in station_names:
                
                station_data[station_name]=[]
                
         
                for variable_name in variable_names:
                 variable_queryset = Variables.objects.filter(name=variable_name,sensor__measurement__name=station_name)
                 
                 for variable in variable_queryset:
                     profile_data = ProfileData.objects.filter(variable=variable).values(
                         'depth_marker', 'variable_value'
                     )
                     process_entry = lambda entry: {
                         'depth': -entry['depth_marker'],
                         'value': entry['variable_value']
                     }
                     
                     print(process_entry)
                     variable_data[variable.name] = list(map(process_entry, profile_data))

                print(variable_data)
                for i in range(len(variable_data['Temperature'])):
                    depth = round(variable_data['Temperature'][i]['depth'], 4)
                    salinity = round(variable_data['Salinity'][i]['value'], 4)
                    temperature = variable_data['Temperature'][i]['value']
    
                    potential_temperature = round(gsw.pt0_from_t(salinity, temperature, depth), 4)
                    density = round(gsw.sigma0(salinity, temperature), 4)
                    
                    station_data[station_name].append({
                            'depth': depth,
                            'potential_Temperature': potential_temperature,
                            'salinity': salinity,
                            'density': density
                        })
                            
            data=[{ 'station': station_name, 'variables':variables} for station_name, variables in station_data.items()]
           
            serializer = DataTeosSerializer(data, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Variables.DoesNotExist:
            return Response({"error": "One or more variables not found."},status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"error": f"An unexpected error occurred: {str(e)}"},status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            
    
class DataSelectDepthView(viewsets.ViewSet):
    @action(detail=False, methods=['post'],url_path='data-depth')
    def filterVariableDepth(self,request):
        try:
            variable_names = request.data.get('variable_names')  # Recibir múltiples nombres de variables
            date_str = request.data.get('date')
            station_name = request.data.get('station_name')
            values_depths=request.data.get('value_depth')
    

            if not variable_names or not station_name or not date_str:
                return Response({'error': 'Falta una o más variables necesarias'}, status=400)
    
            try:
                date = datetime.strptime(date_str, "%Y-%m-%d")
            except ValueError:
                return Response({'error': 'Invalid date format, should be YYYY-MM-DD'}, status=status.HTTP_400_BAD_REQUEST)
    
            variables = Variables.objects.filter(name__in=variable_names,sensor__measurement__name=station_name)
    
            if variables.count() < len(variable_names):
                return Response({'error': 'No se encontraron todas las variables con los nombres y estación proporcionados'}, status=404)
            
            combined_data = []
            variable_data = {name: [] for name in variable_names}
        
            for variable_name in variable_names:
                variable = variables.filter(name=variable_name).first()
                
                if variable:
                  for value_depth in values_depths:  
                    # Obtener los datos de ProfileData
                    profile_data = ProfileData.objects.filter(
                        variable=variable,
                        timestamp__date=date.date(),
                        depth_marker=value_depth,
                    ).values('depth_marker', 'variable_value')
 
                    process_data = lambda entry: {'depth':-entry['depth_marker'],'value':entry['variable_value']} 
                    variable_data[variable_name].extend(list(map(process_data,profile_data)))
            
            for i in range(len(variable_data[variable_names[0]])):
                depth_entry = {'depth': variable_data[variable_names[0]][i]['depth']}
    
                for variable_name in variable_names:
                    get_value=lambda var_name:variable_data[var_name][i]['value'] if i < len(variable_data[var_name]) else None
                    depth_entry.update({var_name:get_value(var_name) for var_name in variable_names})
                    
                combined_data.append(depth_entry)
                
            serializer = CombinedDataSerializer(combined_data, many=True)
            return Response(serializer.data)
            
        except Exception as e:
            print(f'Ha ocurrido un error:{e}')   
            return Response({"error": "An error occurred while retrieving variable names."}, 
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)
           
class DataProfileLonView(viewsets.ViewSet):

    @action(detail=False, methods=['post'], url_path='profile_data')
    def getDataForStation(self, request):
        try:
            variables_names = request.data.get('variables_names')
            date_str = request.data.get('year')
            stations_names = request.data.get('stations_names')
            
            try:
                year= datetime.strptime(date_str, "%Y").year
            except ValueError:
                return Response({'error': 'Invalid date format, should be YYYY'}, 
                                status=status.HTTP_400_BAD_REQUEST)
            station_data={}
            variable_data = {name: [] for name in variables_names}
            
            for station_name  in stations_names:
                station_data[station_name]=[]
                coordinate_value=Measurements.objects.filter(name=station_name).values('latitude','longitude').first()
                if not coordinate_value:
                    return Response({'error': f'No se encontraron coordenadas para la estación {station_name}'}, 
                                    status=status.HTTP_404_NOT_FOUND)
                coordinate = [coordinate_value['latitude'], coordinate_value['longitude']]
                
                variables = Variables.objects.filter(name__in=variables_names,sensor__measurement__name=station_name)
    
                if variables.count() < len(variables_names):
                   return Response({'error': 'No se encontraron todas las variables con los nombres y estación proporcionados'}, 
                                   status=status.HTTP_404_NOT_FOUND)

                for variable in variables:
                    profile_data = ProfileData.objects.filter(
                        variable=variable,
                        timestamp__year=year,
                        ).values('depth_marker', 'variable_value')
                    
                    process_entry = lambda entry: {'depth': -entry['depth_marker'], 
                                                   'value': entry['variable_value']}
                    variable_data[variable.name] = list(map(process_entry, profile_data))
                    
                max_length = max(len(data) for data in variable_data.values())
                
                for i in range(max_length):
                    data_entry = {'depth': variable_data[variables_names[0]][i]['depth']}
                    get_value = lambda var_name: variable_data[var_name][i]['value'] if i < len(variable_data[var_name]) else None
                    data_entry.update({var_name: get_value(var_name) for var_name in variables_names})
                    station_data[station_name].append(data_entry)
                
            combined_data = [{'station':station_name,
                              'coordinate':coordinate, 
                              'variables':variables} 
                              for station_name, variables in station_data.items()]
            
            serializer =DataProfileSerializer(combined_data, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Exception as e:
            print(f'Unexpected error: {e}')
            return Response(
                {"error": "An error occurred while retrieving variable data."}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR) 
            

class DataProfileView(viewsets.ViewSet):

    @action(detail=False, methods=['post'], url_path='profiles_datas')
    def getDataForStation(self, request):
        try:
            variables_names = request.data.get('variables_names')
            date_str = request.data.get('year')
            stations_names = request.data.get('stations_names')
            
            try:
                year = datetime.strptime(date_str, "%Y").year
            except ValueError:
                return Response({'error': 'Invalid date format, should be YYYY'}, 
                                status=status.HTTP_400_BAD_REQUEST)
            all_latitudes = []
            all_depths = []
            allDataVariables = []

            for station_name in stations_names:
                
                coordinate_value = Measurements.objects.filter(name=station_name).values('latitude', 'longitude').first()
                
                if not coordinate_value:
                    print(f'Estación no encontrada: {station_name}')  # Log de depuración
                    return Response({'error': f'No se encontraron coordenadas para la estación {station_name}'}, 
                                    status=status.HTTP_404_NOT_FOUND)
                
                coordinate = [coordinate_value['latitude'], coordinate_value['longitude']]
                variables = Variables.objects.filter(name__in=variables_names, 
                                                     sensor__measurement__name=station_name)
                
                if variables.count() < len(variables_names):
                    print(f'Variables faltantes en estación: {station_name}')  # Log de depuración
                    return Response({'error': f'La estación {station_name} no tiene todas las variables necesarias.'}, 
                                     status=status.HTTP_404_NOT_FOUND)

                for variable in variables:
                    profile_data = ProfileData.objects.filter(
                        variable=variable,
                        timestamp__year=year,
                    ).values('depth_marker', 'variable_value')
                    
                    for entry in profile_data:
                        value = entry['variable_value']
                        
                        all_latitudes.append(coordinate_value['latitude'])
                        all_depths.append(depth)
                        allDataVariables.append(value)
                        
            all_latitudes = np.array(all_latitudes)
            all_depths = np.array(all_depths)
            allDataVariables = np.array(allDataVariables)

            if len(all_latitudes) != len(all_depths) or len(all_latitudes) != len(allDataVariables):
                return Response(
                    {'error': 'Los datos de latitudes, profundidades y oxígeno no coinciden en tamaño.'},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )

            grid_latitudes, grid_depths = np.meshgrid(
                np.linspace(min(all_latitudes), max(all_latitudes), 50),
                np.linspace(min(all_depths), max(all_depths), 50)
            )

            oxygen_grid = griddata(
                points=(all_latitudes, all_depths),
                values=allDataVariables,
                xi=(grid_latitudes, grid_depths),
                method='linear'
            )
            def sanitize_array(arr):
                arr = np.where(np.isfinite(arr), arr, None)
                return arr

            grid_latitudes = sanitize_array(grid_latitudes).flatten().tolist()
            grid_depths = sanitize_array(grid_depths).flatten().tolist()
            oxygen_grid = sanitize_array(oxygen_grid).flatten().tolist() if oxygen_grid is not None else None
            print(oxygen_grid)
            # Combine data into a dictionary
            combined_data = [{
                'latitudes': grid_latitudes,
                'depths': grid_depths,
                'variable': oxygen_grid
            }]

            serializer = ProfileDataSerializer(combined_data, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Exception as e:
            print(f'Unexpected error: {e}')
            return Response(
                {"error": "An error occurred while retrieving and interpolating data."}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR)         



def get_temperature_and_depth_marker(request):
    if request.method == 'POST':
        form = ProfileDataForm(request.POST)
        if form.is_valid():
            temperature = form.cleaned_data['temperature']
            depth_marker = form.cleaned_data['depth_marker']
            try:
                profile_data = ProfileData.objects.get(variable__name='temperature', depth_marker=depth_marker, variable_value=temperature)
                response = {
                    'temperature': profile_data.variable_value,
                    'depth_marker': profile_data.depth_marker
                }
            except ProfileData.DoesNotExist:
                response = {'error': 'Data not found'}
            return JsonResponse(response)
        else:
            return JsonResponse({'error': 'Invalid form data'}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)




class UploadView(viewsets.ViewSet):
    @action(detail=False, methods=['post'], url_path='upload_cnv')
    def post(self, request):
        file = request.FILES.get('file')
        
        if not file or not file.name.endswith('.cnv'):
            return Response({"error": "Este no es un archivo CNV"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            
            with tempfile.NamedTemporaryFile(delete=False, suffix='.cnv') as temp_file:
                for chunk in file.chunks():
                    temp_file.write(chunk)
                temp_file.seek(0)
                temp_file_path = temp_file.name
            
            print("Iniciando el proceso de carga del CNV...")
            data = extract_information(temp_file_path)
            cast = ctd.from_cnv(temp_file_path)
            dataTime = data['system_upload_time']
            station_name=data['station_number']
            print(dataTime)
            print(station_name)
            temperature = cast.get('tv290C')
            print(temperature.head())
            time = cast.get('timeM')
            salinity = cast.get('sal00')
            conductivity = cast.get('c0mS/cm')
            #oxygen = cast.get('sbeox0Mg/L')
            oxygen = cast.get('sbeox0ML/L') 
            pH=cast.get('ph')
            
            #fluorescence = cast.get('flSP')flECO-AFL
            fluorescence = cast.get('flECO-AFL')
            nitrogen_saturation = cast.get('n2satMg/L')
            density = cast.get('density00')
            descent_rate = cast.get('dz/dtM')
            sound_velocity = cast.get('svCM')
            flag = cast.get('flag')
            pressure = cast.index
            pressure = pressure
          

            #print(f"Datos extraídos del CNV: Temperature: {len(temperature)}, Time: {len(time)}, Salinity: {len(salinity)}, Conductivity: {len(conductivity)}, Oxygen: {len(oxygen)}, Fluorescence: {len(fluorescence)}, Nitrogen Saturation: {len(nitrogen_saturation)}, Density: {len(density)}, Descent Rate: {len(descent_rate)}, Sound Velocity: {len(sound_velocity)}, Flag: {len(flag)}, Pressure: {len(pressure)}")

            variables_dict = {
                'Temperature': temperature,
                'Salinity': salinity,
                'Conductivity': conductivity,
                'Oxygen': oxygen,
                'pH':pH,
                'Fluorescence': fluorescence,
                'Nitrogen Saturation': nitrogen_saturation,
                'Density': density,
                'Descent Rate': descent_rate,
                'Sound Velocity': sound_velocity,
                'Flag': flag
            }

            try:
                quality_factor = QualityFactors.objects.get(id=1)  # Ajusta según sea necesario
            except QualityFactors.DoesNotExist:
                return Response({"error": "El factor de calidad con ID 1 no existe."}, status=status.HTTP_400_BAD_REQUEST)

            for variable_name, data in variables_dict.items():
                try:
                    variable = Variables.objects.get(sensor__measurement__name=station_name, name=variable_name)
                    
                    for i, value in enumerate(data):
                        if pd.isna(value):
                            print(f"El valor en la fila {i} para {variable_name} es NaN o None")
                            continue
                        
                        try:
                            timestamp = datetime.fromtimestamp(time[i] / 1000) if i < len(time) else datetime.now()
                        except Exception as e:
                            print(f"Error al convertir timestamp: {str(e)}")
                            timestamp = datetime.now()  # Valor por defecto

                        print(f"Creando ProfileData con: process_descriptor=0.0, quality_factor={quality_factor}, depth_marker={pressure[i] if i < len(pressure) else 0.0}, variable={variable}, variable_value={float(value)}, timestamp={timestamp}")
                        
                        try:
                            profile_data = ProfileData(
                                process_descriptor=0.0,
                                quality_factor=quality_factor,
                                depth_marker=pressure[i] if i < len(pressure) else 0.0,
                                variable=variable,
                                variable_value=float(value),
                                timestamp=dataTime
                            )
                            profile_data.full_clean()  # Valida el objeto antes de guardarlo
                            profile_data.save()
                            print(f"ProfileData para la variable '{variable_name}' guardado exitosamente.")
                        except Exception as e:
                            print(f"Error al guardar ProfileData para la variable '{variable_name}': {str(e)}")
                except Variables.DoesNotExist:
                    print(f"Variable '{variable_name}' no existe.")
                except Exception as e:
                    print(f"Error al procesar variable '{variable_name}': {str(e)}")
            
            return Response({"status": "Archivo procesado exitosamente."}, status=status.HTTP_200_OK)
        
        except Exception as e:
            print(f"Error al procesar el archivo: {str(e)}")
            return Response({"error": f"Ocurrió un error al procesar el archivo: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class UploadCSVView(APIView):
    def post(self, request, *args, **kwargs):
        # Obtén el archivo del request
        file = request.FILES.get('file')
        
        # Verifica si el archivo existe y es del tipo esperado
        if not file or not file.name.endswith('.cnv'):
            return Response({"error": "This is not a CNV file"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Guarda el archivo en un archivo temporal
            with tempfile.NamedTemporaryFile(delete=False, suffix='.cnv') as temp_file:
                for chunk in file.chunks():
                    temp_file.write(chunk)
                temp_file.seek(0)
                temp_file_path = temp_file.name
            
            print("Iniciando el proceso de carga del CNV...")
            # Procesa el archivo temporal
            cast = ctd.from_cnv(temp_file_path)
            
            # Acceder a datos específicos
            temperature = cast.get('tv290C')
            time = cast.get('timeM')
            salinity = cast.get('sal00')
            conductivity = cast.get('c0mS/cm')
            oxygen = cast.get('sbeox0Mg/L')
            fluorescence = cast.get('flSP')
            nitrogen_saturation = cast.get('n2satMg/L')
            density = cast.get('density00')
            descent_rate = cast.get('dz/dtM')
            sound_velocity = cast.get('svCM')
            flag = cast.get('flag')
            pressure = cast.index
            pressure = -pressure
            
            
            print(f"Variables extraídas del CNV exitosamente: Temperature: {len(temperature)} Time: {len(time)} Salinity: {len(salinity)} Conductivity: {len(conductivity)}, Oxygen: {len(oxygen)}, Fluorescence: {len(fluorescence)}, Nitrogen Saturation: {len(nitrogen_saturation)}, Density: {len(density)}, Descent Rate: {len(descent_rate)}, Sound Velocity: {len(sound_velocity)}, Flag: {len(flag)}, Pressure: {len(pressure)}")


            # Opcionalmente, guarda 'cast' en la base de datos o realiza otras acciones aquí

            return Response({"status": "File processed successfully."}, status=status.HTTP_200_OK)
        
        except Exception as e:
            # Maneja cualquier excepción que ocurra durante el procesamiento
            print(f"Error processing file: {e}")
            return Response({"error": "An error occurred while processing the file."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class QualityFactorsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                quality_factor = QualityFactors.objects.get(pk=pk)
                serializer = QualityFactorsSerializer(quality_factor)
                return Response(serializer.data)
            except QualityFactors.DoesNotExist:
                return Response({"error": "Quality Factor not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            quality_factors = QualityFactors.objects.all()
            serializer = QualityFactorsSerializer(quality_factors, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = QualityFactorsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            quality_factor = QualityFactors.objects.get(pk=pk)
        except QualityFactors.DoesNotExist:
            return Response({"error": "Quality Factor not found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = QualityFactorsSerializer(quality_factor, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            quality_factor = QualityFactors.objects.get(pk=pk)
        except QualityFactors.DoesNotExist:
            return Response({"error": "Quality Factor not found"}, status=status.HTTP_404_NOT_FOUND)
        
        quality_factor.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    

from .models import Disciplines
from .serializers import DisciplinesSerializer


class DisciplinesView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                discipline = Disciplines.objects.get(pk=pk)
                serializer = DisciplinesSerializer(discipline)
                return Response(serializer.data)
            except Disciplines.DoesNotExist:
                return Response({"error": "Discipline not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            disciplines = Disciplines.objects.all()
            serializer = DisciplinesSerializer(disciplines, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = DisciplinesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    from .models import Coasts

from .serializers import CoastsSerializer


class CoastsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                coast = Coasts.objects.get(pk=pk)
                serializer = CoastsSerializer(coast)
                return Response(serializer.data)
            except Coasts.DoesNotExist:
                return Response({"error": "Coast not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            coasts = Coasts.objects.all()
            serializer = CoastsSerializer(coasts, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = CoastsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
from .models import SamplingRates
from .serializers import SamplingRatesSerializer


class SamplingRatesView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                sampling_rate = SamplingRates.objects.get(pk=pk)
                serializer = SamplingRatesSerializer(sampling_rate)
                return Response(serializer.data)
            except SamplingRates.DoesNotExist:
                return Response({"error": "Sampling Rate not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            sampling_rates = SamplingRates.objects.all()
            serializer = SamplingRatesSerializer(sampling_rates, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = SamplingRatesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            sampling_rate = SamplingRates.objects.get(pk=pk)
        except SamplingRates.DoesNotExist:
            return Response({"error": "Sampling Rate not found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = SamplingRatesSerializer(sampling_rate, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            sampling_rate = SamplingRates.objects.get(pk=pk)
        except SamplingRates.DoesNotExist:
            return Response({"error": "Sampling Rate not found"}, status=status.HTTP_404_NOT_FOUND)
        
        sampling_rate.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    
from .models import CecoldoCodes
from .serializers import CecoldoCodesSerializer


class CecoldoCodesView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                sampling_rate = CecoldoCodes.objects.get(pk=pk)
                serializer = CecoldoCodesSerializer(sampling_rate)
                return Response(serializer.data)
            except CecoldoCodes.DoesNotExist:
                return Response({"error": "Sampling Rate not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            sampling_rates = SamplingRates.objects.all()
            serializer = SamplingRatesSerializer(sampling_rates, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = CecoldoCodesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)    

from .models import Departments
from .serializers import DepartmentsSerializer


class DepartmentsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                department = Departments.objects.get(pk=pk)
                serializer = DepartmentsSerializer(department)
                return Response(serializer.data)
            except Departments.DoesNotExist:
                return Response({"error": "Department not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            departments = Departments.objects.all()
            serializer = DepartmentsSerializer(departments, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = DepartmentsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from .models import ProcessingLevels
from .serializers import ProcessingLevelsSerializer


class ProcessingLevelsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                processing_level = ProcessingLevels.objects.get(pk=pk)
                serializer = ProcessingLevelsSerializer(processing_level)
                return Response(serializer.data)
            except ProcessingLevels.DoesNotExist:
                return Response({"error": "Processing Level not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            processing_levels = ProcessingLevels.objects.all()
            serializer = ProcessingLevelsSerializer(processing_levels, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = ProcessingLevelsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            processing_level = ProcessingLevels.objects.get(pk=pk)
        except ProcessingLevels.DoesNotExist:
            return Response({"error": "Processing Level not found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = ProcessingLevelsSerializer(processing_level, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            processing_level = ProcessingLevels.objects.get(pk=pk)
        except ProcessingLevels.DoesNotExist:
            return Response({"error": "Processing Level not found"}, status=status.HTTP_404_NOT_FOUND)
        
        processing_level.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

# views.py
from .models import MeasurementUnits
from .serializers import MeasurementUnitsSerializer


class MeasurementUnitsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                measurement_unit = MeasurementUnits.objects.get(pk=pk)
                serializer = MeasurementUnitsSerializer(measurement_unit)
                return Response(serializer.data)
            except MeasurementUnits.DoesNotExist:
                return Response({"error": "Measurement Unit not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            measurement_units = MeasurementUnits.objects.all()
            serializer = MeasurementUnitsSerializer(measurement_units, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = MeasurementUnitsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)    
from .models import Measurements
from .serializers import MeasurementsSerializer


class MeasurementsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                measurement = Measurements.objects.get(pk=pk)
                serializer = MeasurementsSerializer(measurement)
                return Response(serializer.data)
            except Measurements.DoesNotExist:
                return Response({"error": "Measurement not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            measurements = Measurements.objects.all()
            serializer = MeasurementsSerializer(measurements, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = MeasurementsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from .models import Measurements
from .serializers import MeasurementsSerializer


class MeasurementsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                measurement = Measurements.objects.get(pk=pk)
                serializer = MeasurementsSerializer(measurement)
                return Response(serializer.data)
            except Measurements.DoesNotExist:
                return Response({"error": "Measurement not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            measurements = Measurements.objects.all()
            serializer = MeasurementsSerializer(measurements, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = MeasurementsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from .models import Equipments
from .serializers import EquipmentsSerializer


class EquipmentsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                equipment = Equipments.objects.get(pk=pk)
                serializer = EquipmentsSerializer(equipment)
                return Response(serializer.data)
            except Equipments.DoesNotExist:
                return Response({"error": "Equipment not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            equipments = Equipments.objects.all()
            serializer = EquipmentsSerializer(equipments, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = EquipmentsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            equipment = Equipments.objects.get(pk=pk)
        except Equipments.DoesNotExist:
            return Response({"error": "Equipment not found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = EquipmentsSerializer(equipment, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            equipment = Equipments.objects.get(pk=pk)
        except Equipments.DoesNotExist:
            return Response({"error": "Equipment not found"}, status=status.HTTP_404_NOT_FOUND)
        
        equipment.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

# views.py
from .models import MaintenancesDates
from .serializers import MaintenancesDatesSerializer


class MaintenancesDatesView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                maintenance_date = MaintenancesDates.objects.get(pk=pk)
                serializer = MaintenancesDatesSerializer(maintenance_date)
                return Response(serializer.data)
            except MaintenancesDates.DoesNotExist:
                return Response({"error": "Maintenance Date not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            maintenance_dates = MaintenancesDates.objects.all()
            serializer = MaintenancesDatesSerializer(maintenance_dates, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = MaintenancesDatesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from .models import Settings
from .serializers import SettingsSerializer


class SettingsView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                setting = Settings.objects.get(pk=pk)
                serializer = SettingsSerializer(setting)
                return Response(serializer.data)
            except Settings.DoesNotExist:
                return Response({"error": "Setting not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            settings = Settings.objects.all()
            serializer = SettingsSerializer(settings, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = SettingsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

from .models import Variables
from .serializers import VariablesSerializer


class VariablesView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                variable = Variables.objects.get(pk=pk)
                serializer = VariablesSerializer(variable)
                return Response(serializer.data)
            except Variables.DoesNotExist:
                return Response({"error": "Variable not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            variables = Variables.objects.all()
            serializer = VariablesSerializer(variables, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = VariablesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from .models import ProfileData
from .serializers import ProfileDataSerializer


class ProfileDataView(APIView):
    def get(self, request, pk=None):
        if pk:
            try:
                profile_data = ProfileData.objects.get(pk=pk)
                serializer = ProfileDataSerializer(profile_data)
                return Response(serializer.data)
            except ProfileData.DoesNotExist:
                return Response({"error": "Profile Data not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            profile_data = ProfileData.objects.all()
            serializer = ProfileDataSerializer(profile_data, many=True)
            return Response(serializer.data)

    def post(self, request):
        serializer = ProfileDataSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)                   
