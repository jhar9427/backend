import os
import re
import ctd
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import griddata
import matplotlib.patheffects as path_effects

# Ruta del directorio que contiene los archivos CNV
directorio_cnvs = r'C:\Users\jhurtado\Downloads\datos\datos 5N'

colors = ['#8B4513', '#D2B48C', '#F5F5DC', '#008080', '#AFEEEE']
custom_cmap = 'RdYlBu_r'
# Listas para almacenar los datos de cada archivo
profundidades = []
oxigenos = []
latitudes = []

def extract_information(file_path):
    info = {
        #'latitude': ''
        'longitud':''
    }

    with open(file_path, 'r') as file:
        content = file.read()

        # Regex para extraer latitud
        #pattern = r"\*\* Latitud:\s*([0-9\.\-]+)"
        pattern = r"\*\* Longitud:\s*([0-9\.\-]+)"
        match = re.search(pattern, content)
        if match:
            info['longitud'] = match.group(1).strip()

    return info

# Extraer latitudes de los archivos y determinar el rango
lat = []
for archivo in os.listdir(directorio_cnvs):
    if archivo.endswith('.cnv'):
        ruta_archivo = os.path.join(directorio_cnvs, archivo)
        print(f"Cargando {ruta_archivo}...")

        info = extract_information(ruta_archivo)
        if info['longitud']:
            lat.append(float(info['longitud']))

# Verificar que se haya extraído al menos una latitud
if not lat:
    raise ValueError("No se encontraron latitudes en los archivos CNV.")

# Determinar los límites de latitudes
latmin = min(lat)
latmax = max(lat)

# Iterar sobre cada archivo CNV y extraer la profundidad y oxígeno
for i, archivo in enumerate(os.listdir(directorio_cnvs)):
    if archivo.endswith('.cnv'):
        ruta_archivo = os.path.join(directorio_cnvs, archivo)
        print(f"Cargando {ruta_archivo}...")

        # Leer el archivo CNV
        data = ctd.from_cnv(ruta_archivo)

        # Extraer profundidad
        profundidad = data.index.values

        # Buscar columnas de oxígeno en mg/L o mL/L
        if 'sbeox0Mg/L' in data.columns:
            oxigeno = data['sbeox0Mg/L'].values *1.429
        elif 'sbeox0ML/L' in data.columns:
            oxigeno = data['sbeox0ML/L'].values * 1.429  # Conversión de mL/L a mg/L
        else:
            print(f"No se encontró oxígeno en {archivo}")
            continue

        # Verificar que haya datos válidos
        if len(profundidad) == 0 or len(oxigeno) == 0:
            print(f"Datos vacíos en el archivo {archivo}.")
            continue
        
        mitad_len = len(profundidad) // 2
        profundidad = profundidad[:mitad_len]
        oxigeno = oxigeno[:mitad_len]

        # Ajustar latitudes fijas
        latitudes_fijas = np.linspace(latmax, latmin, len(lat))

        # Comprobar el tamaño de latitudes_fijas
        if i < len(latitudes_fijas):
            latitud_actual = latitudes_fijas[i]
            latitudes.extend([latitud_actual] * len(profundidad))
        else:
            print(f"Índice fuera de límites para latitudes_fijas en el archivo {archivo}.")
            continue

        # Agregar los datos a las listas
        profundidades.append(profundidad)
        oxigenos.append(oxigeno)

# Concatenar los datos
all_profundidades = np.concatenate(profundidades)
all_oxigenos = np.concatenate(oxigenos)
all_latitudes = np.array(latitudes)

# Verificar que los arrays concatenados no estén vacíos
if all_profundidades.size == 0 or all_oxigenos.size == 0:
    raise ValueError("No se encontraron datos para la interpolación.")

# Crear una cuadrícula regular de latitud y profundidad
grid_latitudes, grid_profundidades = np.meshgrid(
    np.linspace(min(latitudes_fijas), max(latitudes_fijas), 400),
    np.linspace(np.min(all_profundidades), np.max(all_profundidades), 2000)
)

# Interpolar los datos de oxígeno en la cuadrícula
oxigeno_grid = griddata(
    (all_latitudes, all_profundidades),
    all_oxigenos,
    (grid_latitudes, grid_profundidades),
    method='linear'
)



# Crear el gráfico combinado
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 6), sharex=True, gridspec_kw={'height_ratios': [1, 1]})

# Crear la escala de color personalizada desde 0 a 8
vmin = 0
vmax = 8

# Establecer niveles para los contornos que incluyan 0 y 8 de forma clara
levels = np.linspace(vmin, vmax, 500)  # Más niveles para suavizar la interpolación

# Ajustar los contornos
contour1 = ax1.contourf(grid_latitudes, grid_profundidades, oxigeno_grid, cmap=custom_cmap, levels=levels, vmin=vmin, vmax=vmax)
contour2 = ax2.contourf(grid_latitudes, grid_profundidades, oxigeno_grid, cmap=custom_cmap, levels=levels, vmin=vmin, vmax=vmax)
ax1.set_ylim(ax1.get_ylim()[::-1])
ax2.set_ylim(200, 0)  # Profundidad de 0 a 200 metros

# Añadir contornos de líneas para los valores de oxígeno
contour_lines1 = ax1.contour(grid_latitudes, grid_profundidades, oxigeno_grid, colors='black', linewidths=0.3, levels=np.arange(vmin, vmax+0.1, 1))
contour_lines2 = ax2.contour(grid_latitudes, grid_profundidades, oxigeno_grid, colors='black', linewidths=0.3, levels=np.arange(vmin, vmax+0.1, 1))

# Añadir etiquetas a los contornos de líneas
ax1.clabel(contour_lines1, inline=True, colors='black', fontsize=10, fmt='%1.1f')
ax2.clabel(contour_lines2, inline=True, colors='black', fontsize=10, fmt='%1.1f')

# Establecer el rango de la barra de colores de 0 a 8
contour1.set_clim(vmin, vmax)
contour2.set_clim(vmin, vmax)

# Crear la barra de colores para ambos gráficos
cbar1 = fig.colorbar(contour1, ax=ax1, location='right', extend='both', pad=0.04, shrink=0.9, aspect=10, format='%.1f')
cbar2 = fig.colorbar(contour2, ax=ax2, location='right', pad=0.04, shrink=0.9, aspect=10, format='%.1f')

# Etiquetas de la barra de colores
cbar1.set_label('Oxígeno (mg/L)', fontweight='bold')
cbar2.set_label('Oxígeno (mg/L)', fontweight='bold')

# Asegurarte de que los valores de 0 y 8 aparezcan en la barra de colores
cbar1.set_ticks(np.arange(vmin, vmax+0.1, 1))
cbar2.set_ticks(np.arange(vmin, vmax+0.1, 1))




plt.xticks(fontsize=10)
plt.yticks(fontsize=10)

ax1.set_ylabel('Profundidad (m)',fontweight='bold')
ax2.set_ylabel('Profundidad (m)',fontweight='bold')
ax2.set_xlabel('Latitud(°)',fontweight='bold')

# Ajustar el espacio entre los gráficos
plt.subplots_adjust(hspace=0.4)  # Aumentar el espacio vertical entre los gráficos

plt.tight_layout()
plt.savefig('oxigeno_vertical_5N.tiff', dpi=300, bbox_inches='tight')
plt.show()