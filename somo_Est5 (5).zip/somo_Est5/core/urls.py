from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import ( CoastsView, DataProfileView, DepartmentsView,
                    DisciplinesView, EquipmentsView, MaintenancesDatesView,
                    MeasurementsView, MeasurementUnitsView,
                    ProcessingLevelsView, ProfileDataViewSet,DataProfileLonView,
                    QualityFactorsView, SamplingRatesView, SeasonsDateView, SettingsView, StationNameView,
                    UploadCSVView, UploadView, DataForStationView, VariableNameView, DataTeosView,VarNameUnitView,
                    VariablesView, DataSelectDepthView, get_temperature_and_depth_marker)

# Configuración del router para DRF
router = DefaultRouter()

router.register(r'time-series', ProfileDataViewSet, basename='time-series')
router.register(r'filter',DataForStationView, basename='data_station')
router.register(r'filter',VarNameUnitView, basename='name_unit')
router.register(r'file',UploadView,basename='file')
router.register(r'variables_names',VariableNameView, basename='variables_names')
router.register(r'filter',DataTeosView,basename='data_teos')
router.register(r'filter',DataSelectDepthView,basename='depth')
router.register(r'stations_names',StationNameView,basename='stations_names')
router.register(r'seasons_date',SeasonsDateView,basename='seasons_date')
router.register(r'filter',DataProfileLonView,basename='profile_data')
router.register(r'filter',DataProfileView,basename='profiles_datas')
urlpatterns = [
    # Endpoints para ProfileData
    path('profile/', ProfileDataViewSet.as_view({'get': 'list', 'post': 'create'}), name='profile_data_list_create'),
    
   
    # Endpoints para Departments
    path('departments/', DepartmentsView.as_view(), name='departments_list_create'),
    
    # Endpoints para Coasts
    path('coasts/', CoastsView.as_view(), name='coasts_list_create'),
    
    # Endpoint para obtener temperatura y profundidad
    path('get-profile-data/', get_temperature_and_depth_marker, name='get_profile_data'),
    
    # Endpoint para filtrar por variable
    #path('filter-variable-names/', filter_variable, name='filter_variable'),
    
    # Endpoints para QualityFactors
    path('disciplines/', DisciplinesView.as_view(), name='disciplines_list_create'),
    path('quality_factors/', QualityFactorsView.as_view(), name='quality_factors_list_create'),
    path('sampling_rates/', SamplingRatesView.as_view(), name='sampling_rates_list_create'),
    
    # Endpoints para ProcessingLevels
    path('processing_levels/', ProcessingLevelsView.as_view(), name='processing_levels_list_create'),
    path('processing_levels/<int:pk>/', ProcessingLevelsView.as_view(), name='processing_levels_retrieve_update_destroy'),
    
    # Endpoints para MeasurementUnits
    path('measurement_units/', MeasurementUnitsView.as_view(), name='measurement_units_list_create'),
    path('measurement_units/<int:pk>/', MeasurementUnitsView.as_view(), name='measurement_units_retrieve_update_destroy'),
    
    # Endpoints para Measurements
    path('measurements/', MeasurementsView.as_view(), name='measurements_list_create'),
    path('measurements/<int:pk>/', MeasurementsView.as_view(), name='measurements_retrieve_update_destroy'),
    
    # Endpoints para Equipments
    path('equipments/', EquipmentsView.as_view(), name='equipments_list_create'),
    path('equipments/<int:pk>/', EquipmentsView.as_view(), name='equipments_retrieve_update_destroy'),
    
    # Endpoints para MaintenancesDates
    path('maintenances_dates/', MaintenancesDatesView.as_view(), name='maintenances_dates_list_create'),
    path('maintenances_dates/<int:pk>/', MaintenancesDatesView.as_view(), name='maintenances_dates_retrieve_update_destroy'),
    
    # Endpoints para Settings
    path('settings/', SettingsView.as_view(), name='settings_list_create'),
    path('settings/<int:pk>/', SettingsView.as_view(), name='settings_retrieve_update_destroy'),
    
    # Endpoints para Variables
    path('variables/', VariablesView.as_view(), name='variables_list_create'),
    path('variables/<int:pk>/', VariablesView.as_view(), name='variables_retrieve_update_destroy'),
    
    # Endpoint para UploadCSV
    path('upload_csv/', UploadCSVView.as_view(), name='upload_csv'),
    
    # Endpoint para UploadCNV
    #path('upload_cnv/', UploadView.as_view(), name='upload_cnv'),
    
    # Rutas para DRF Router
   path('', include(router.urls)), 
]
