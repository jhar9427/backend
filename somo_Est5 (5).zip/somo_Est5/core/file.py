import ctd
import re
import matplotlib.pyplot as plt

# Ruta del archivo .cnv
file_path = 'SBE19plus_01907890_2024_08_01.cnv'

# Leer el archivo .cnv
cast = ctd.from_cnv(file_path)
 
print(cast)
# Acceder a datos específicos
temperature = cast.get('tv290C')
temperature1=cast['tv290C']
time = cast.get('timeM')
salinity = cast.get('sal00')
conductivity = cast.get('c0mS/cm')
oxygen = cast.get('sbeox0Mg/L')
fluorescence = cast.get('flSP')
nitrogen_saturation = cast.get('n2satMg/L')
density = cast.get('density00')
descent_rate = cast.get('dz/dtM')
sound_velocity = cast.get('svCM')
flag = cast.get('flag')
pressure = cast.index
pressure = -pressure

metadata=cast._metadata


print(metadata.keys()
)
# Crear subplots


def extract_information(file_path):
    info = {
        'station_name': '',
        'cruise_name': '',
        'vessel_name': '',
        'station_number': '',
        'launch_date_time': '',
        'latitude': '',
        'longitude': '',
        'depth': '',
        'operator_name': '',
        'chief_of_departure': ''
    }

    with open(file_path, 'r') as file:
        content = file.read()

        # Regex patterns for each piece of information
        patterns = {
            'station_name': r"Nombre del archivo:\s*(.*)",
            'cruise_name': r"\*\* Nombre del crucero:\s*(.*)",
            'vessel_name': r"\*\* Nombre de la embarcación y su indicativo:\s*(.*)",
            'station_number': r"\*\* Estacíon:\s*(.*)",
            'launch_date_time': r"\*\* Fecha y hora de lanzamiento:\s*(.*)",
            'latitude': r"\*\* Latitud:\s*([0-9\.\-]+)",
            'longitude': r"\*\* Longitud:\s*([0-9\.\-]+)",
            'depth': r"\*\* Profundidad de la zona \[ m\] :\s*(.*)",
            'operator_name': r"\*\* Nombre del operador:\s*(.*)",
            'chief_of_departure': r"\*\* Jefe de salida:\s*(.*)"
        }

        # Extract data using regex
        for key, pattern in patterns.items():
            match = re.search(pattern, content)
            if match:
                info[key] = match.group(1).strip()

    return info

# Path to your .cnv file
file_path='SBE19plus_01907890_2024_08_01.cnv'
data = extract_information(file_path)
print(data)

print(f"Nombre de la estación: {data['station_name']}")
print(f"Nombre del crucero: {data['cruise_name']}")
print(f"Nombre de la embarcación y su indicativo: {data['vessel_name']}")
print(f"Estación: {data['station_number']}")
print(f"Fecha y hora de lanzamiento: {data['launch_date_time']}")
print(f"Latitud: {data['latitude']}")
print(f"Longitud: {data['longitude']}")
print(f"Profundidad de la zona: {data['depth']}")
print(f"Nombre del operador: {data['operator_name']}")
print(f"Jefe de salida: {data['chief_of_departure']}")