class StationNameView(viewsets.ViewSet):
    @action(detail=False, methods=['get'], url_path='name')
    def get(self, request):
        try:
            # Get distinct station names
            station_names = Measurements.objects.values_list('name', flat=True).distinct()
            station_list = [{"name": name} for name in station_names]  # Wrap each station name in a dictionary

            # Serialize the data
            serializer = StationNameSerializer(station_list, many=True)

            # Return the serialized data
            return Response(serializer.data, status=status.HTTP_200_OK)
        
        except Exception as e:
            # Log the exception and return a more informative error message
            return Response(
                {"Error": f"Error attempting to retrieve station names: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
                
                
                
                class StationNameSerializer(serializers.ListSerializer):
    def to_representation(self, data):
        # The data here is a list of strings, so just return it as is
        return data    
    
class StationNameSerializer(serializers.Serializer):
    name = serializers.CharField()