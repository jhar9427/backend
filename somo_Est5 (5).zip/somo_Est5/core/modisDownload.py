import netCDF4 as nc
import numpy as np
import pandas as pd
import os
import re

# Ruta de la carpeta donde están los archivos NetCDF diarios
ruta_archivos = r'C:\Users\jhurtado\Downloads\modis\requested_files_1 (10)\requested_files'

# Expresión regular para extraer la fecha del nombre del archivo
regex_fecha = re.compile(r'AQUA_MODIS\.(\d{8})\.L3m\.DAY\.SST\.x_sst')

# Diccionario para almacenar datos agrupados por año y mes
datos_mensuales = {}

# Obtener lista de archivos NetCDF en la ruta
archivos = [archivo for archivo in os.listdir(ruta_archivos) if archivo.endswith('.nc')]
if not archivos:
    print("No se encontraron archivos NetCDF en la ruta especificada.")
else:
    print(f"Se encontraron {len(archivos)} archivos para procesar.")

# Procesar cada archivo
for archivo in archivos:
    # Extraer la fecha del nombre del archivo
    match = regex_fecha.search(archivo)
    if match:
        fecha_str = match.group(1)
        fecha = pd.to_datetime(fecha_str, format='%Y%m%d')
        año_mes = fecha.strftime('%Y-%m')  # Agrupación por año-mes

        # Abrir el archivo NetCDF
        try:
            ruta_completa = os.path.join(ruta_archivos, archivo)
            with nc.Dataset(ruta_completa) as ds:
                # Cambia 'sst' por el nombre correcto de la variable si es diferente
                if 'sst' not in ds.variables:
                    print(f"La variable 'sst' no se encontró en el archivo {archivo}.")
                    continue

                sst_data = ds.variables['sst'][:].filled(np.nan)  # Convertir máscaras a NaN

            # Agregar los datos al diccionario por año-mes
            if año_mes not in datos_mensuales:
                datos_mensuales[año_mes] = []
            datos_mensuales[año_mes].append(sst_data)
        except Exception as e:
            print(f"Error al procesar el archivo {archivo}: {e}")

# Calcular estadísticas mensuales y almacenar resultados
estadisticas_mensuales = {
    'Año-Mes': [],
    'Minimo': [],
    'Maximo': [],
    'Media': [],
    'Mediana': [],
    'Desviacion Estandar': []
}

for año_mes, datos in datos_mensuales.items():
    if datos:
        # Convertir todos los arrays en uno solo, aplanado
        datos_array = np.concatenate([d.flatten() for d in datos])  # Convertir en una lista plana
        datos_array = datos_array[~np.isnan(datos_array)]  # Ignorar NaN

        # Calcular estadísticas
        minimo = np.min(datos_array)
        maximo = np.max(datos_array)
        media = np.mean(datos_array)
        mediana = np.median(datos_array)
        desviacion_std = np.std(datos_array)

        # Guardar en el diccionario de estadísticas
        estadisticas_mensuales['Año-Mes'].append(año_mes)
        estadisticas_mensuales['Minimo'].append(minimo)
        estadisticas_mensuales['Maximo'].append(maximo)
        estadisticas_mensuales['Media'].append(media)
        estadisticas_mensuales['Mediana'].append(mediana)
        estadisticas_mensuales['Desviacion Estandar'].append(desviacion_std)
        print(f"Estadísticas para {año_mes}: Min={minimo}, Max={maximo}, Media={media}, Mediana={mediana}, Desviación estándar={desviacion_std}")
    else:
        print(f"No se encontraron datos para el mes {año_mes}.")

# Crear DataFrame y guardar en Excel
df_estadisticas = pd.DataFrame(estadisticas_mensuales)
if not df_estadisticas.empty:
    nombre_archivo = 'estadisticas_mensuales_todos_los_archivos.xlsx'
    df_estadisticas.to_excel(nombre_archivo, index=False)
    print(f"Estadísticas mensuales guardadas en '{nombre_archivo}'.")
else:
    print("No se generaron estadísticas para guardar.")
