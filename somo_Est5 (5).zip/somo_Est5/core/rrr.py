class StationNameView(viewsets.ViewSet):
    @action(detail=False, methods=['get'], url_path='name')
    def get(self, request):
        try:
            # Retrieve distinct station names
            station_name = Measurements.objects.values_list('name', flat=True).distinct()
            station_list = list(station_name)
            print(station_list)
            
            # Serialize the data
            serializer = StationNameSerializer(station_list, many=True)
            print(serializer.data)
            
            # Return the response
            return Response(serializer.data, status=status.HTTP_200_OK)
        
        except Exception as e:
            # Return a detailed error message for debugging
            return Response({"Error": f"Intentando obtener los nombres de las estaciones: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        
        router.register(r'filter',ProfileDataLonView,basename='profile_data')