# Configura tu usuario y contraseña de Earthdata aquí
EARTHDATA_USERNAME = 'jharym94@gmail.com'
EARTHDATA_PASSWORD = 'Jhurtado94#27'