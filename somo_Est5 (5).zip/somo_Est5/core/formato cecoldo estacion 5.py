import os
import ctd
import pandas as pd
import re

# Directorio que contiene los archivos CNV
#directorio_cnv = r'C:\Users\jhurtado\Documents\Fondo accion'
directorio_cnv = r'D:\backend-devJoseh\SBE19plus_01907890_2024_10_30'

# Filtrar los archivos CNV en el directorio
archivos_cnv = [f for f in os.listdir(directorio_cnv) if f.endswith('.cnv')]
all_dataframe = []  # Lista para almacenar los DataFrames de todos los archivos

# Para cada archivo CNV, guardar la presión y otras variables
for archivo in archivos_cnv:
    
    # Ruta completa del archivo CNV
    ruta_archivo = os.path.join(directorio_cnv, archivo)

    # Cargar el archivo CNV
    cast = ctd.from_cnv(ruta_archivo)
    
    df = cast

    # Mostrar las primeras filas del DataFrame para verificar el contenido
    print(f"Primera fila de {archivo}:")
    print(cast.head())

    # Buscar metadatos de Latitud, Longitud, y System UTC
    with open(ruta_archivo, 'r') as f:
        contenido = f.readlines()

    latitud = None
    longitud = None
    system_utc = None

    # Buscar las líneas que contienen los metadatos
    for linea in contenido:
        if 'Latitud' in linea:
            latitud = linea.split(':')[1].strip()
        elif 'Longitud' in linea:
            longitud = linea.split(':')[1].strip()
        #elif 'System UTC' in linea:
        elif 'start_time' in linea:
            system_utc = linea.split('=')[1].strip()
        elif 'Estacion' in linea:
            estacion = linea.split(':')[1].strip()    
            print(estacion)
    # Asegurarse de que se encontró la información necesaria
    if not all([latitud, longitud, system_utc]):
        print(f"Metadatos faltantes en el archivo {archivo}.")
        continue

    # Limpiar y convertir el System UTC a datetime
    system_utc_clean = re.search(r'\b[A-Za-z]{3} \d{2} \d{4} \d{2}:\d{2}:\d{2}\b', system_utc)
    
    # Comprobar si se encontró una fecha válida
    if system_utc_clean:
        # Convertir la cadena limpia en datetime
        fecha_hora = pd.to_datetime(system_utc_clean.group(0), format='%b %d %Y %H:%M:%S')
    else:
        print(f"Formato de System UTC no válido en el archivo {archivo}.")
        continue

    # Filtrar las columnas de interés (Temperatura, Salinidad, etc.)
    columnas_interes = ['tv290C', 'sal00','c0mS/cm', 'sbeox0Mg/L','flSP','obs3+','n2satMg/L','density00','dz/dtM','svCM']

    # Verificar si las columnas existen en el DataFrame
    columnas_existentes = [col for col in columnas_interes if col in cast.columns]

    if columnas_existentes:
        # Crear DataFrame con las columnas de interés
        df_filtrado = cast[columnas_existentes].copy()
        
        if df.index.name:  # Verificar si el índice tiene nombre (en caso de ser profundidad)
            df_filtrado['profundidad'] = df.index.values
        else:
            # Si el índice no tiene nombre, asignar una columna de profundidad basada en el índice numérico
            df_filtrado['profundidad'] = df.reset_index().index.values

        # Crear la columna de tiempo basada en System UTC
        df_filtrado['Fecha[aaaa-mm-dd UT-5]'] = fecha_hora.strftime('%Y-%m-%d')
        df_filtrado['Hora[hh:mm:ss UT-5]'] = fecha_hora.strftime('%H:%M:%S')
        df_filtrado['Latitud'] = latitud
        df_filtrado['Longitud'] = longitud
        #df_filtrado['Estacion'] = estacion
        df_filtrado['ph'] = 'NAN'

        # Renombrar las columnas
        df_filtrado.rename(columns={
            'Fecha[aaaa-mm-dd UT-5]':'Fecha[aaaa-mm-dd UT-5]',
            'Hora[hh:mm:ss UT-5]':'Hora[hh:mm:ss UT-5]',
            'Latitud': 'Latitud[deg]',
            'Longitud':'Longitud[deg]',
            #'Estacion':'Estacion[#]',
            'profundidad':'Profundidad[m]',
            'tv290C':'Temperatura[degC]',
            'sal00': 'Salinidad[UPS]',
            'c0mS/cm':'Conductividad[mS/cm]',
            'sbeox0Mg/L':'Oxigeno[ml/L]',
            'flSP':'Fluorecencia[]',
            'obs3+':'Turbidez[NTU]',
            'n2satMg/L':'Saturacion de nitrogeno[mg/L]',
            'density00':'Densidad[Kg/m^3]',
            'dz/dtM':'Velocidad de descenso[m/s]',
            'svCM':'Velocidad del sonido[m/s]'
            #'flECO-AFL' :'Fluorecencia[mg/m^3]',
            #'ph': 'pH[Dmnless]'
        }, inplace=True)

        # Añadir el DataFrame filtrado a la lista
        all_dataframe.append(df_filtrado)

# Concatenar todos los DataFrames
df_final2 = pd.concat(all_dataframe, ignore_index=True)

# Crear una fila adicional con los nuevos nombres de los parámetros
nueva_fila = pd.Series({
    'Fecha[aaaa-mm-dd UT-5]': 'ADATAA01', 
    'Hora[hh:mm:ss UT-5]': 'AHMSSP01', 
    'Latitud[deg]': 'ALATGP01', 
    'Longitud[deg]': 'ALONGP01', 
    #'Estacion[#]': 'ACYCAA01', 
    'Profundidad[m]': 'ADEPZZ01', 
    'Temperatura[degC]': 'TEMPST01', 
    'Salinidad[UPS]': 'SSALST01',
    'Conductividad[mS/cm]':'N/A', 
    'Oxigeno[ml/L]': 'DOXYZZ01', 
    'Fluorecencia[]':'N/A',
    'Turbidez[NTU]':'N/A',
    'Saturacion de nitrogeno[mg/L]':'N/A',
    'Densidad[Kg/m^3]':'N/A',
    'Velocidad del sonido[m/s]':'N/A',
    #'Fluorecencia[mg/m^3]':'NA',
    #'pH[Dmnless]': 'PHXXPR01'
})

# Crear DataFrame para la nueva fila
nueva_fila_df = nueva_fila.to_frame().T

# Insertar la nueva fila después de los encabezados
df_final2 = pd.concat([nueva_fila_df, df_final2], ignore_index=True)





# Guardar los datos concatenados en un archivo Excel (opcional)
df_final2.to_excel('SBE19plus_01907890_2024_10_30.xlsx', index=False)

print("Proceso completado. Los datos han sido guardados.")
